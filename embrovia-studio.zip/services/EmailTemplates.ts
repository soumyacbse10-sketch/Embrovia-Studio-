
import { AdminSettings } from '../types.ts';

const BRAND_COLOR = '#5C4D3C';
const BG_COLOR = '#FDFBF7';
const TEXT_COLOR = '#7C6A58';

const getHeader = (settings: AdminSettings) => `
  <div style="text-align: center; padding: 40px 20px; background-color: ${BG_COLOR};">
    <img src="${settings.businessLogo || 'https://picsum.photos/seed/embrovia-logo/200/200'}" alt="${settings.businessName}" style="width: 80px; height: 80px; object-fit: contain; margin-bottom: 20px;">
    <h1 style="font-family: 'Playfair Display', serif; color: ${BRAND_COLOR}; margin: 0; font-size: 28px; letter-spacing: 1px;">${settings.businessName}</h1>
    <p style="font-family: 'Inter', sans-serif; color: ${TEXT_COLOR}; font-size: 12px; text-transform: uppercase; letter-spacing: 2px; margin-top: 5px;">Handcrafted Elegance</p>
  </div>
`;

const getFooter = (settings: AdminSettings) => `
  <div style="padding: 40px 20px; background-color: ${BRAND_COLOR}; color: #FDFBF7; text-align: center; font-family: 'Inter', sans-serif;">
    <h4 style="margin: 0 0 15px 0; font-size: 14px; text-transform: uppercase; letter-spacing: 1px;">Need Assistance?</h4>
    <p style="font-size: 13px; opacity: 0.8; margin: 5px 0;">Phone: ${settings.supportPhone}</p>
    <p style="font-size: 13px; opacity: 0.8; margin: 5px 0;">Email: ${settings.supportEmail}</p>
    <div style="margin-top: 30px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 20px;">
      <p style="font-size: 11px; opacity: 0.5; margin: 0;">&copy; ${new Date().getFullYear()} ${settings.businessName}. All rights reserved.</p>
      <p style="font-size: 11px; opacity: 0.5; margin: 5px 0;">${settings.businessAddress}</p>
    </div>
  </div>
`;

export const getBaseTemplate = (bodyContent: string, settings: AdminSettings) => `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body { margin: 0; padding: 0; background-color: #f4f4f4; -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
    .content-table { width: 100%; max-width: 600px; margin: 20px auto; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
    .body-padding { padding: 40px 30px; }
    p { font-family: 'Inter', sans-serif; line-height: 1.6; color: ${TEXT_COLOR}; font-size: 15px; }
    .highlight-box { background-color: ${BG_COLOR}; border: 1px solid #EBE3D5; border-radius: 12px; padding: 25px; margin: 25px 0; }
    .btn { display: inline-block; padding: 15px 35px; background-color: ${BRAND_COLOR}; color: #ffffff !important; text-decoration: none; border-radius: 50px; font-weight: 600; font-family: 'Inter', sans-serif; font-size: 14px; margin-top: 20px; }
    .divider { border-top: 1px solid #EBE3D5; margin: 30px 0; }
  </style>
</head>
<body>
  <table cellpadding="0" cellspacing="0" class="content-table">
    <tr><td>${getHeader(settings)}</td></tr>
    <tr>
      <td class="body-padding">
        ${bodyContent}
      </td>
    </tr>
    <tr><td>${getFooter(settings)}</td></tr>
  </table>
</body>
</html>
`;
