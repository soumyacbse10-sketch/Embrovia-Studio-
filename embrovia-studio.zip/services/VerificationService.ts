
import { GoogleGenAI } from "@google/genai";
import { Order } from "../types.ts";

export interface VerificationResult {
  verified: boolean;
  reason: string;
}

/**
 * READ-ONLY AI AUDITOR
 * This service provides verification text for customer certificates.
 * It strictly treats the order as customer-confirmed.
 */
export const runOrderAIVerification = async (order: Order): Promise<VerificationResult> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const context = `
      --- ORDER DATA ---
      Order ID: ${order.id}
      Customer: ${order.userName}
      Total: ₹${order.total}
      Status: ${order.status}
      Payment Method: ${order.paymentMethod || 'N/A'}
      Flag - Payment Verified: ${order.paymentVerified}
    `;

    const systemInstruction = `
      You are the "Embrovia Factual Auditor". 
      A customer has completed their payment and placed this order.
      Your task is to generate a short, professional confirmation message for their receipt.
      
      RULES:
      1. Never mention "Studio approval" or "Admin confirmation".
      2. Focus on "Payment received" and "Handover to artisans".
      3. Be warm but brief.
      
      RESPONSE FORMAT:
      You must return valid JSON only. 
      {
        "verified": true,
        "reason": "Artisanal audit summary text (max 100 chars). e.g. 'Payment confirmed. Your piece has been handed over for artisanal stitching.'"
      }
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        { role: 'user', parts: [{ text: context }] }
      ],
      config: { 
        systemInstruction,
        responseMimeType: 'application/json' 
      }
    });

    const text = response.text || '{"verified":true,"reason":"Payment verified. Stitching initiated."}';
    return JSON.parse(text);
  } catch (error) {
    console.error("AI Auditor offline:", error);
    return { 
      verified: true, 
      reason: "Payment verified. Handcrafted production secured." 
    };
  }
};
