
import { GoogleGenAI } from "@google/genai";
import { Order, AdminSettings } from "../types.ts";

export interface RiskCheckResult {
  hasRisk: boolean;
  warnings: string[];
}

export const runAIRiskCheck = async (
  order: Order,
  action: string,
  settings: AdminSettings
): Promise<RiskCheckResult> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const context = `
      Brand: ${settings.businessName}
      Action Attempted: ${action}
      Order State: ${order.status}
      
      ORDER DATA:
      - Total: ₹${order.total}
      - Subtotal: ₹${order.subtotal}
      - Artisan Charges: ₹${order.artisanCharges}
      - Packaging: ₹${order.packagingCharges}
      - Shipping: ₹${order.shippingCharge}
      - Discount: ₹${order.discount}
      - Items: ${order.items.map(i => `${i.name} (₹${i.price})`).join(', ')}
      
      CUSTOMER DATA:
      - Name: ${order.userName}
      - Phone: ${order.userPhone}
      - Address: ${order.deliveryAddress.houseFlat}, ${order.deliveryAddress.streetArea}, ${order.deliveryAddress.city}, ${order.deliveryAddress.state} - ${order.deliveryAddress.pinCode}
      
      DOCUMENT STATUS:
      - Invoice Locked: ${!!order.invoiceData?.lockedAt}
      - Label Final: ${!!order.labelData?.lockedAt}
      - Payment Method: ${order.paymentMethod || 'None'}
      - Payment Verified: ${order.paymentVerified}
    `;

    const prompt = `
      You are an AI Risk Auditor for "Embrovia Studio". Analyze the provided order data for pricing, operational, and consistency risks.
      
      STRICT AUDIT RULES:
      1. PRICING: Warn if discount > 40% of subtotal or if final total is less than (Artisan + Packaging + Shipping).
      2. CONSISTENCY: Mismatch if document data overrides don't match order amounts (if provided).
      3. DATA QUALITY: Check if phone number is valid (10 digits), if PIN code is 6 digits, if name is full (min 2 words).
      4. OPERATIONS: Warn if shipping while ON_HOLD. Warn if generating labels without locked invoice. Warn if dispatching without tracking.
      
      Return ONLY a JSON object:
      {
        "hasRisk": boolean,
        "warnings": ["detailed human-readable warning strings"]
      }
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        { role: 'system', parts: [{ text: prompt }] },
        { role: 'user', parts: [{ text: context }] }
      ],
      config: { responseMimeType: 'application/json' }
    });

    return JSON.parse(response.text || '{"hasRisk":false,"warnings":[]}');
  } catch (error) {
    console.error("AI Risk Check failed:", error);
    return { hasRisk: false, warnings: ["AI Risk service temporarily unavailable. Please proceed with manual caution."] };
  }
};
