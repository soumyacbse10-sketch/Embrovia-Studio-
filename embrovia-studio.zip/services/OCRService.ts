
import { GoogleGenAI } from "@google/genai";
import { VerifiedPaymentDetails } from "../types.ts";

/**
 * AI UPI EXTRACTION ENGINE
 * Analyzes payment proof screenshots to extract transaction meta-data.
 */
export const extractUPIDetails = async (base64Image: string): Promise<VerifiedPaymentDetails | null> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // Clean base64 string
    const data = base64Image.split(',')[1] || base64Image;

    const prompt = `
      Extract transaction details from this UPI payment screenshot.
      Look for:
      - Transaction ID / UTR / Reference Number
      - Amount (in INR)
      - Date of payment
      - Payee Name or UPI ID
      - Status (Success/Completed/Failed)
      
      Response MUST be valid JSON:
      {
        "transactionId": "string or empty",
        "amount": number,
        "date": "string or empty",
        "payee": "string or empty",
        "status": "Success | Failed | Unknown",
        "confidence": number (0-1)
      }
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        {
          role: 'user',
          parts: [
            { inlineData: { data, mimeType: 'image/png' } },
            { text: prompt }
          ]
        }
      ],
      config: { responseMimeType: 'application/json' }
    });

    const text = response.text || '{}';
    const raw = JSON.parse(text);

    return {
      transactionId: raw.transactionId || 'NOT_FOUND',
      amount: raw.amount || 0,
      date: raw.date || new Date().toISOString(),
      payee: raw.payee || 'Unknown',
      confidence: raw.confidence || 0.5,
      aiExtracted: true,
      adminLocked: false
    };
  } catch (error) {
    console.error("UPI AI Extraction failed:", error);
    return null;
  }
};
