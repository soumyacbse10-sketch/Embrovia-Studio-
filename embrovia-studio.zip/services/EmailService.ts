
import { GoogleGenAI } from "@google/genai";
import { User, AdminSettings, Order, EmailType, EmailTemplate } from '../types.ts';

export type { EmailType };

export interface EmailPayload {
  user?: Partial<User>;
  method?: 'Google' | 'Email';
  timestamp?: string;
  platform?: string;
  order?: Order;
}

export interface PreparedEmail {
  recipient: string;
  subject: string;
  body: string;
}

const replacePlaceholders = (template: string, payload: EmailPayload, settings: AdminSettings): string => {
  let result = template;
  
  const placeholders: Record<string, string> = {
    '{{customer_name}}': payload.user?.name || payload.order?.userName || 'Valued Customer',
    '{{order_id}}': payload.order?.id || 'N/A',
    '{{order_total}}': payload.order ? `₹${payload.order.total}` : 'N/A',
    '{{product_name}}': payload.order?.items.map(i => i.name).join(', ') || 'N/A',
    '{{payment_method}}': payload.order?.paymentMethod || 'N/A',
    '{{tracking_id}}': payload.order?.shipping?.awbNumber || 'N/A',
    '{{tracking_number}}': payload.order?.shipping?.awbNumber || 'N/A',
    '{{tracking_url}}': payload.order?.shipping?.trackingUrl || 'N/A',
    '{{courier_name}}': payload.order?.shipping?.courierName || 'N/A',
    '{{business_name}}': settings.businessName,
    '{{support_email}}': settings.supportEmail,
    '{{support_phone}}': settings.supportPhone,
  };

  Object.entries(placeholders).forEach(([key, value]) => {
    result = result.split(key).join(value);
  });

  return result;
};

export const prepareManualEmail = async (
  type: EmailType,
  payload: EmailPayload,
  settings: AdminSettings
): Promise<PreparedEmail | null> => {
  const template = settings.emailTemplates[type];
  if (!template || !template.isEnabled) {
    console.warn(`Template for ${type} is missing or disabled.`);
    return null;
  }

  const rawBody = replacePlaceholders(template.body, payload, settings);
  const rawSubject = replacePlaceholders(template.subject, payload, settings);

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const systemInstruction = `
      You are the Senior Communications Lead for "Embrovia Studio". 
      I have a base email message generated from a template. 
      Your task is to take this message and "polish" it to ensure it sounds professional, artisanal, and sophisticated.
      
      IMPORTANT: 
      - Keep all factual information (names, IDs, totals, addresses, tracking numbers, links) EXACTLY as provided.
      - Do not add fake information.
      - Improve the flow, grammar, and artisanal tone.
      - Use clean PLAIN TEXT formatting.
      
      Brand Details: ${settings.businessName}, Support: ${settings.supportPhone}, ${settings.supportEmail}.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Please polish this artisanal email body:\n\n${rawBody}`,
      config: { systemInstruction, temperature: 0.5 }
    });

    const polishedBody = response.text || rawBody;
    const recipient = payload.user?.email || payload.order?.userEmail || "";

    return { recipient, subject: rawSubject, body: polishedBody };
  } catch (error) {
    console.error("Email polishing failed, falling back to raw template:", error);
    const recipient = payload.user?.email || payload.order?.userEmail || "";
    return { recipient, subject: rawSubject, body: rawBody };
  }
};

export const dispatchToEmailApp = (email: PreparedEmail) => {
  const mailto = `mailto:${email.recipient}?subject=${encodeURIComponent(email.subject)}&body=${encodeURIComponent(email.body)}`;
  window.location.href = mailto;
};
