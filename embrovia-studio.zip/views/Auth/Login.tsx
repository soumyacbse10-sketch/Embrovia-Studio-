
import React, { useState } from 'react';
import { User, UserRole } from '../../types.ts';
import { INITIAL_USERS } from '../../data.ts';

interface LoginProps {
  onLogin: (user: User) => void;
}

const LoginView: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [activeTab, setActiveTab] = useState<'login' | 'signup' | 'admin'>('login');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    setTimeout(() => {
      const role = activeTab === 'admin' ? UserRole.ADMIN : UserRole.CUSTOMER;
      
      // In production, we'd verify against a backend. 
      // For this environment, we check against the initialized list + local storage.
      const storedUsersRaw = localStorage.getItem('embrovia_all_users');
      const allUsers: User[] = storedUsersRaw ? JSON.parse(storedUsersRaw) : INITIAL_USERS;
      
      const user = allUsers.find(u => u.email.toLowerCase() === email.toLowerCase() && u.role === role);

      // PRODUCTION RULE: Fixed password for initial admins as requested
      const isProductionAdmin = (email === 'soumya@embroviastudo.com' || email === 'sulagna@embroviastudo.com');
      const validPassword = isProductionAdmin ? 'PASSWORD' : password; // In a real app, this is handled via auth service

      if (user && (password === validPassword || !isProductionAdmin)) {
        onLogin(user);
      } else {
        setError('Invalid credentials. Please check your email and password.');
        setIsLoading(false);
      }
    }, 800);
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    const newUser: User = {
      id: `u-${Date.now()}`,
      name,
      email,
      phone: '',
      role: UserRole.CUSTOMER,
      addresses: []
    };

    setTimeout(() => {
      // Persist user for the session
      const storedUsersRaw = localStorage.getItem('embrovia_all_users');
      const allUsers: User[] = storedUsersRaw ? JSON.parse(storedUsersRaw) : [...INITIAL_USERS];
      localStorage.setItem('embrovia_all_users', JSON.stringify([...allUsers, newUser]));
      
      onLogin(newUser);
    }, 1200);
  };

  return (
    <div className="max-w-md mx-auto mt-20 p-8 bg-white rounded-[40px] shadow-2xl border border-[#EBE3D5]">
      <div className="text-center mb-10">
        <h1 className="text-4xl font-serif font-bold text-[#5C4D3C] italic">
          {activeTab === 'signup' ? 'Join the Studio' : 'Studio Access'}
        </h1>
        <p className="text-[#A68F7A] mt-2 text-sm uppercase tracking-[2px] font-bold">
          {activeTab === 'signup' ? 'Create your artisan profile' : 'Secure identification required'}
        </p>
      </div>

      <div className="flex mb-8 bg-[#FDFBF7] p-1 rounded-2xl border border-[#EBE3D5]">
        <button
          onClick={() => { setActiveTab('login'); setError(''); }}
          className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-widest rounded-xl transition-all ${activeTab === 'login' ? 'bg-[#5C4D3C] text-white shadow-lg' : 'text-[#7C6A58]'}`}
        >
          Customer
        </button>
        <button
          onClick={() => { setActiveTab('signup'); setError(''); }}
          className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-widest rounded-xl transition-all ${activeTab === 'signup' ? 'bg-[#5C4D3C] text-white shadow-lg' : 'text-[#7C6A58]'}`}
        >
          Register
        </button>
        <button
          onClick={() => { setActiveTab('admin'); setError(''); }}
          className={`flex-1 py-3 text-[10px] font-bold uppercase tracking-widest rounded-xl transition-all ${activeTab === 'admin' ? 'bg-[#5C4D3C] text-white shadow-lg' : 'text-[#7C6A58]'}`}
        >
          Admin
        </button>
      </div>

      <form onSubmit={activeTab === 'signup' ? handleSignup : handleLogin} className="space-y-6">
        {activeTab === 'signup' && (
          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest px-2">Full Legal Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-6 py-4 bg-[#FDFBF7] border border-[#EBE3D5] rounded-2xl focus:ring-2 focus:ring-[#5C4D3C]/10 outline-none transition-all text-sm"
              placeholder="e.g. Anjali Sharma"
              required
            />
          </div>
        )}
        <div className="space-y-1">
          <label className="block text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest px-2">Email Address</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-6 py-4 bg-[#FDFBF7] border border-[#EBE3D5] rounded-2xl focus:ring-2 focus:ring-[#5C4D3C]/10 outline-none transition-all text-sm"
            placeholder="name@example.com"
            required
          />
        </div>
        <div className="space-y-1">
          <label className="block text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest px-2">Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-6 py-4 bg-[#FDFBF7] border border-[#EBE3D5] rounded-2xl focus:ring-2 focus:ring-[#5C4D3C]/10 outline-none transition-all text-sm"
            placeholder="••••••••"
            required
          />
        </div>

        {error && (
          <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl text-rose-600 text-[10px] font-bold uppercase tracking-widest text-center">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-[#5C4D3C] text-white py-5 rounded-3xl font-bold hover:bg-black transition-all shadow-xl hover:shadow-2xl disabled:opacity-50 flex items-center justify-center uppercase tracking-[3px] text-[10px]"
        >
          {isLoading ? (
            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
          ) : (
            activeTab === 'signup' ? 'Finalize Registration' : 'Confirm Identity'
          )}
        </button>
      </form>
      
      <div className="mt-8 text-center">
        <p className="text-[10px] text-[#A68F7A] uppercase tracking-widest italic">
          Embrovia Studio Production Environment v1.0
        </p>
      </div>
    </div>
  );
};

export default LoginView;
