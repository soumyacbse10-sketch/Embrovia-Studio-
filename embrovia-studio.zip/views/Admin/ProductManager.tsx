
import React, { useState } from 'react';
import { Product, AdminSettings } from '../../types.ts';
import { GoogleGenAI } from "@google/genai";

interface ProductManagerProps {
  products: Product[];
  adminSettings: AdminSettings;
  onUpsert: (p: Product) => void;
  onDelete: (id: string) => void;
}

const ProductManager: React.FC<ProductManagerProps> = ({ products, adminSettings, onUpsert, onDelete }) => {
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [isAiSuggesting, setIsAiSuggesting] = useState(false);

  const calculateFinalPrice = (p: Partial<Product>) => {
    const base = p.basePrice || 0;
    const artisan = p.artisanCharges || 0;
    const packaging = p.packagingCharges || 0;
    const shipping = p.shippingFee || 0;
    const custom = p.customWorkCharges || 0;
    
    let subtotal = base + artisan + packaging + shipping + custom;
    
    // Admin decides discount priority: PERCENT if present, else FLAT
    if (p.discountPercent && p.discountPercent > 0) {
      subtotal = subtotal * (1 - p.discountPercent / 100);
    } else if (p.flatDiscount && p.flatDiscount > 0) {
      subtotal = subtotal - p.flatDiscount;
    }
    
    return Math.max(0, Math.round(subtotal));
  };

  const handlePriceUpdate = (updates: Partial<Product>) => {
    if (!editingProduct) return;
    const newProduct = { ...editingProduct, ...updates };
    const finalPrice = calculateFinalPrice(newProduct);
    setEditingProduct({ ...newProduct, price: finalPrice });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingProduct) {
      onUpsert(editingProduct as Product);
      setEditingProduct(null);
    }
  };

  const suggestPricingWithAI = async () => {
    if (!editingProduct?.name || isAiSuggesting) return;
    setIsAiSuggesting(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Suggest artisanal pricing components for a handmade embroidery product named "${editingProduct.name}". 
      Return JSON with: { "basePrice": number, "artisanCharges": number, "packagingCharges": number, "shippingFee": number, "customWorkCharges": number, "discountPercent": number, "reasoning": "string" }`;
      
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: { responseMimeType: 'application/json' }
      });
      
      const data = JSON.parse(response.text || '{}');
      if (data.basePrice !== undefined) {
        handlePriceUpdate({ 
          basePrice: data.basePrice, 
          artisanCharges: data.artisanCharges || 0,
          packagingCharges: data.packagingCharges || 0,
          shippingFee: data.shippingFee || 0,
          customWorkCharges: data.customWorkCharges || 0,
          discountPercent: data.discountPercent || 0 
        });
        alert(`AI Suggestion:\nBase: ₹${data.basePrice}\nArtisan: ₹${data.artisanCharges}\nDiscount: ${data.discountPercent}%\n\nReason: ${data.reasoning}`);
      }
    } catch (e) {
      alert("AI pricing desk is unavailable. Please set components manually.");
    } finally {
      setIsAiSuggesting(false);
    }
  };

  return (
    <div className="space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-4xl font-serif font-bold text-[#5C4D3C]">Artisanal Inventory</h1>
          <p className="text-[#A68F7A] mt-1 italic">Manual control over every stitch and price component.</p>
        </div>
        <button 
          onClick={() => setEditingProduct({
            id: Date.now().toString(),
            name: '',
            basePrice: 0,
            artisanCharges: 0,
            packagingCharges: 0,
            shippingFee: 0,
            customWorkCharges: 0,
            discountPercent: 0,
            flatDiscount: 0,
            price: 0,
            unit: 'Piece',
            description: '',
            categoryId: adminSettings.categories[0]?.id || '',
            category: adminSettings.categories[0]?.name || '',
            images: ['https://picsum.photos/seed/new-art/600/600'],
            careInstructions: 'Handle with artisanal care.',
            stock: 1,
            isVisible: true,
            isFeatured: false
          })}
          className="bg-[#5C4D3C] text-white px-8 py-3 rounded-full font-bold shadow-lg hover:bg-black transition-all flex items-center gap-2"
        >
          <span>✨</span> New Creation
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {products.map(p => (
          <div key={p.id} className="bg-white p-6 rounded-[32px] border border-[#EBE3D5] shadow-sm hover:shadow-lg transition-all group">
            <div className="aspect-square rounded-2xl overflow-hidden bg-[#FDFBF7] relative mb-6">
              <img src={p.images[0]} alt={p.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
              {p.discountPercent > 0 && (
                <div className="absolute top-4 right-4 bg-emerald-600 text-white px-3 py-1 rounded-full text-[10px] font-bold tracking-widest uppercase shadow-lg">
                  {p.discountPercent}% Studio Off
                </div>
              )}
            </div>
            <div className="flex justify-between items-start mb-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-[#A68F7A]">{p.category}</span>
                <h3 className="text-xl font-serif font-bold text-[#5C4D3C] mt-1">{p.name}</h3>
              </div>
              <div className="text-right">
                <p className="text-lg font-bold text-[#5C4D3C]">₹{p.price.toLocaleString()}</p>
                <p className="text-[10px] text-[#A68F7A] uppercase font-bold tracking-widest">per {p.unit}</p>
              </div>
            </div>
            <div className="flex items-center justify-between pt-6 border-t border-[#EBE3D5]">
               <div className="flex items-center gap-2 text-[10px] font-bold text-[#A68F7A] uppercase">
                 <span className={`w-2 h-2 rounded-full ${p.stock > 0 ? 'bg-emerald-500' : 'bg-rose-500'}`}></span>
                 {p.stock} units
               </div>
               <div className="flex gap-2">
                 <button onClick={() => setEditingProduct(p)} className="px-4 py-2 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-[10px] font-bold uppercase tracking-widest text-[#5C4D3C] hover:bg-[#EBE3D5]">Edit</button>
                 <button onClick={() => onDelete(p.id)} className="px-4 py-2 text-rose-600 hover:bg-rose-50 rounded-xl text-[10px] font-bold uppercase tracking-widest">Delete</button>
               </div>
            </div>
          </div>
        ))}
      </div>

      {editingProduct && (
        <div className="fixed inset-0 bg-[#5C4D3C]/60 backdrop-blur-md z-[200] flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-4xl rounded-[40px] shadow-2xl overflow-hidden animate-in zoom-in duration-300">
            <div className="px-10 py-8 border-b border-[#EBE3D5] flex justify-between items-center bg-[#FDFBF7]">
              <div>
                <h2 className="text-3xl font-serif font-bold text-[#5C4D3C]">Creation Studio</h2>
                <p className="text-[10px] text-[#A68F7A] mt-1 uppercase tracking-widest font-bold">Manual Component Pricing</p>
              </div>
              <button onClick={() => setEditingProduct(null)} className="text-3xl text-[#A68F7A]">&times;</button>
            </div>
            <form onSubmit={handleSubmit} className="p-10 space-y-10 max-h-[75vh] overflow-y-auto">
              <div className="grid lg:grid-cols-2 gap-12">
                <div className="space-y-8">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-[2px] text-[#A68F7A]">Piece Title</label>
                    <input required value={editingProduct.name} onChange={(e) => setEditingProduct({...editingProduct, name: e.target.value})} className="w-full px-5 py-4 bg-[#FDFBF7] border border-[#EBE3D5] rounded-2xl text-lg font-serif outline-none focus:ring-2 focus:ring-[#5C4D3C]/10" />
                  </div>
                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase tracking-[2px] text-[#A68F7A]">Category</label>
                      <select value={editingProduct.categoryId} onChange={(e) => {
                        const cat = adminSettings.categories.find(c => c.id === e.target.value);
                        setEditingProduct({...editingProduct, categoryId: e.target.value, category: cat?.name || ''});
                      }} className="w-full px-4 py-4 bg-[#FDFBF7] border border-[#EBE3D5] rounded-2xl text-xs outline-none cursor-pointer">
                        {adminSettings.categories.filter(c => c.isEnabled).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase tracking-[2px] text-[#A68F7A]">Stock Units</label>
                      <input type="number" value={editingProduct.stock} onChange={(e) => setEditingProduct({...editingProduct, stock: parseInt(e.target.value) || 0})} className="w-full px-4 py-4 bg-[#FDFBF7] border border-[#EBE3D5] rounded-2xl text-sm outline-none" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-[2px] text-[#A68F7A]">Description</label>
                    <textarea rows={4} value={editingProduct.description} onChange={(e) => setEditingProduct({...editingProduct, description: e.target.value})} className="w-full px-6 py-5 bg-[#FDFBF7] border border-[#EBE3D5] rounded-[32px] text-sm leading-relaxed outline-none" placeholder="The story behind this piece..." />
                  </div>
                </div>

                <div className="bg-[#5C4D3C] p-10 rounded-[40px] text-white shadow-2xl space-y-8 relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-8 opacity-5 text-9xl italic font-serif pointer-events-none">₹</div>
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold uppercase tracking-[3px] opacity-70">Pricing Desk</h4>
                    <button type="button" onClick={suggestPricingWithAI} disabled={isAiSuggesting} className="text-[9px] font-bold bg-white/10 hover:bg-white/20 px-3 py-1 rounded-full uppercase tracking-widest border border-white/20 transition-all">
                      {isAiSuggesting ? '⌛ Analyzing...' : '✨ AI Suggest'}
                    </button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-x-8 gap-y-6">
                    <PricingField label="Base Price" value={editingProduct.basePrice} onChange={(v) => handlePriceUpdate({ basePrice: v })} />
                    <PricingField label="Artisan Charges" value={editingProduct.artisanCharges} onChange={(v) => handlePriceUpdate({ artisanCharges: v })} />
                    <PricingField label="Packaging" value={editingProduct.packagingCharges} onChange={(v) => handlePriceUpdate({ packagingCharges: v })} />
                    <PricingField label="Shipping Fee" value={editingProduct.shippingFee} onChange={(v) => handlePriceUpdate({ shippingFee: v })} />
                    <PricingField label="Custom Work" value={editingProduct.customWorkCharges} onChange={(v) => handlePriceUpdate({ customWorkCharges: v })} />
                    <PricingField label="Discount (%)" value={editingProduct.discountPercent} onChange={(v) => handlePriceUpdate({ discountPercent: v, flatDiscount: 0 })} />
                    <PricingField label="Flat Off (₹)" value={editingProduct.flatDiscount} onChange={(v) => handlePriceUpdate({ flatDiscount: v, discountPercent: 0 })} />
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold uppercase tracking-widest opacity-60">Unit</label>
                      <input value={editingProduct.unit} onChange={(e) => setEditingProduct({...editingProduct, unit: e.target.value})} className="w-full bg-white/5 border border-white/20 rounded-xl px-4 py-3 text-xs outline-none focus:bg-white/10" />
                    </div>
                  </div>

                  <div className="pt-8 border-t border-white/10 flex justify-between items-end">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-widest opacity-60">Final Studio Price</span>
                      <p className="text-5xl font-serif font-bold mt-1">₹{editingProduct.price?.toLocaleString()}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-8 py-6 border-y border-[#EBE3D5]">
                <ToggleButton label="Visible to Public" active={editingProduct.isVisible} onToggle={() => setEditingProduct({...editingProduct, isVisible: !editingProduct.isVisible})} />
                <ToggleButton label="Featured Masterpiece" active={editingProduct.isFeatured} onToggle={() => setEditingProduct({...editingProduct, isFeatured: !editingProduct.isFeatured})} />
              </div>

              <div className="flex gap-6">
                <button type="button" onClick={() => setEditingProduct(null)} className="flex-1 py-5 border border-[#EBE3D5] rounded-3xl font-bold text-[#A68F7A] hover:bg-gray-50 uppercase tracking-widest text-[10px]">Discard Changes</button>
                <button type="submit" className="flex-1 py-5 bg-[#5C4D3C] text-white rounded-3xl font-bold shadow-2xl hover:bg-black uppercase tracking-widest text-[10px]">Confirm & Save Piece</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

const PricingField: React.FC<{ label: string, value?: number, onChange: (v: number) => void }> = ({ label, value, onChange }) => (
  <div className="space-y-1">
    <label className="text-[9px] font-bold uppercase tracking-widest opacity-60">{label}</label>
    <div className="relative">
      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[10px] opacity-40">₹</span>
      <input 
        type="number" value={value} onChange={(e) => onChange(parseFloat(e.target.value) || 0)} 
        className="w-full pl-7 pr-3 py-3 bg-white/5 border border-white/20 rounded-xl text-xs outline-none focus:bg-white/10" 
      />
    </div>
  </div>
);

const ToggleButton: React.FC<{ label: string, active?: boolean, onToggle: () => void }> = ({ label, active, onToggle }) => (
  <button type="button" onClick={onToggle} className="flex items-center gap-3 group">
    <div className={`w-12 h-6 rounded-full transition-all relative ${active ? 'bg-[#5C4D3C]' : 'bg-gray-200'}`}>
      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${active ? 'right-1' : 'left-1'}`} />
    </div>
    <span className="text-[10px] font-bold uppercase tracking-widest text-[#7C6A58] group-hover:text-[#5C4D3C]">{label}</span>
  </button>
);

export default ProductManager;
