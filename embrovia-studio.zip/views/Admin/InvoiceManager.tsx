
import React, { useState } from 'react';
import { Order, OrderStatus, AdminSettings, DocData } from '../../types.ts';
import DocumentViewer from '../Shared/DocumentViewer.tsx';
import { runAIRiskCheck } from '../../services/RiskService.ts';

interface InvoiceManagerProps {
  orders: Order[];
  adminSettings: AdminSettings;
  onUpdateOrder: (id: string, updates: Partial<Order>, log?: string) => void;
}

const InvoiceManager: React.FC<InvoiceManagerProps> = ({ orders, adminSettings, onUpdateOrder }) => {
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [editData, setEditData] = useState<Partial<DocData>>({});
  const [isAuditing, setIsAuditing] = useState(false);
  const [previewDoc, setPreviewDoc] = useState<Order | null>(null);
  const [riskWarnings, setRiskWarnings] = useState<string[] | null>(null);

  const startEdit = (order: Order) => {
    const isPaid = order.status === OrderStatus.PAYMENT_SUCCESS || order.status === OrderStatus.COD_CONFIRMED;
    if (!isPaid) {
        alert("Action Blocked: Invoice can only be generated after payment is confirmed or COD is verified.");
        return;
    }
    setSelectedOrder(order);
    setEditData({
      title: order.invoiceData?.title || 'Tax Invoice',
      note: order.invoiceData?.note || 'Thank you for supporting handcrafted Indian art.',
      nameOverride: order.invoiceData?.nameOverride || order.deliveryAddress.fullName || order.userName,
      addressOverride: order.invoiceData?.addressOverride || `${order.deliveryAddress.houseFlat}, ${order.deliveryAddress.streetArea}`
    });
  };

  const attemptFinalize = async () => {
    if (!selectedOrder) return;
    setIsAuditing(true);
    
    // Simulate AI audit before confirmation
    const result = await runAIRiskCheck(selectedOrder, "Finalize Invoice", adminSettings);
    setIsAuditing(false);

    if (result.hasRisk) {
      setRiskWarnings(result.warnings);
    } else {
      finalize();
    }
  };

  const finalize = () => {
    if (!selectedOrder) return;
    if (confirm("Mark invoice FINAL? This action cannot be undone.")) {
        const finalizedData: DocData = {
          title: editData.title || 'Tax Invoice',
          note: editData.note || '',
          lockedAt: new Date().toISOString(),
          nameOverride: editData.nameOverride,
          addressOverride: editData.addressOverride
        };
        onUpdateOrder(selectedOrder.id, { 
            invoiceData: finalizedData, 
            status: OrderStatus.INVOICE_FINAL,
            checklist: { ...selectedOrder.checklist, invoiceLocked: true }
        }, "Invoice finalized and locked");
        setSelectedOrder(null);
        setRiskWarnings(null);
    }
  };

  return (
    <div className="space-y-10">
      <div>
        <h1 className="text-4xl font-serif font-bold text-[#5C4D3C]">Studio Invoices</h1>
        <p className="text-[#A68F7A] mt-1 italic">Official studio documentation management.</p>
      </div>

      <div className="grid gap-6">
        {orders.map(order => (
          <div key={order.id} className="bg-white p-8 rounded-3xl border border-[#EBE3D5] flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-6">
              <div className="w-14 h-14 bg-[#FDFBF7] border border-[#EBE3D5] rounded-2xl flex items-center justify-center font-bold text-[#5C4D3C]">#</div>
              <div>
                <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">ID: {order.id} • {order.status}</p>
                <h3 className="text-xl font-serif font-bold text-[#5C4D3C]">{order.invoiceData?.nameOverride || order.userName}</h3>
              </div>
            </div>
            <div className="flex gap-4">
               {order.invoiceData?.lockedAt ? (
                 <button onClick={() => setPreviewDoc(order)} className="px-6 py-2 bg-[#5C4D3C] text-white text-[10px] font-bold uppercase rounded-xl">Print A4</button>
               ) : (
                 <button onClick={() => startEdit(order)} className="px-6 py-2 bg-[#EBE3D5] text-[#5C4D3C] text-[10px] font-bold uppercase rounded-xl hover:bg-[#D4C5B9]">Generate Invoice</button>
               )}
            </div>
          </div>
        ))}
      </div>

      {selectedOrder && (
        <div className="fixed inset-0 z-[400] bg-black/60 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-2xl rounded-[40px] shadow-2xl overflow-hidden animate-in zoom-in">
             <div className="bg-[#5C4D3C] p-8 text-white flex justify-between items-center">
                <h2 className="text-2xl font-serif font-bold">Invoice Finalizer</h2>
                <button onClick={() => { setSelectedOrder(null); setRiskWarnings(null); }} className="text-3xl opacity-60" disabled={isAuditing}>&times;</button>
             </div>
             
             <div className="p-10 space-y-6 max-h-[70vh] overflow-y-auto">
                {riskWarnings ? (
                  <div className="space-y-6 animate-in fade-in">
                    <div className="bg-amber-50 border border-amber-200 p-6 rounded-3xl space-y-4">
                      <p className="text-xs font-bold text-amber-800 uppercase tracking-widest">⚠️ AI Risk Warnings</p>
                      <ul className="space-y-2">
                        {riskWarnings.map((w, i) => <li key={i} className="text-sm text-amber-900 font-medium">• {w}</li>)}
                      </ul>
                    </div>
                    <p className="text-xs text-center text-gray-500">You are proceeding despite AI risk warnings. Continue?</p>
                    <div className="flex gap-4">
                      <button onClick={() => setRiskWarnings(null)} className="flex-1 py-4 border rounded-2xl text-[10px] font-bold uppercase">Fix Issues</button>
                      <button onClick={finalize} className="flex-1 py-4 bg-amber-500 text-white rounded-2xl text-[10px] font-bold uppercase shadow-xl">Confirm Override</button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="space-y-4">
                      <div className="space-y-1">
                          <label className="text-[9px] font-bold uppercase text-gray-400">Customer Full Name</label>
                          <input value={editData.nameOverride} onChange={e => setEditData({...editData, nameOverride: e.target.value})} className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm" />
                      </div>
                      <div className="space-y-1">
                          <label className="text-[9px] font-bold uppercase text-gray-400">Billing Address</label>
                          <textarea value={editData.addressOverride} onChange={e => setEditData({...editData, addressOverride: e.target.value})} className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm" rows={2} />
                      </div>
                    </div>
                    <div className="pt-6 border-t flex gap-4">
                      <button onClick={() => setSelectedOrder(null)} disabled={isAuditing} className="flex-1 py-4 border rounded-2xl text-xs font-bold uppercase">Cancel</button>
                      <button onClick={attemptFinalize} disabled={isAuditing} className="flex-1 py-4 bg-[#5C4D3C] text-white rounded-2xl text-xs font-bold uppercase shadow-xl">
                            {isAuditing ? 'Auditing...' : 'Finalize & Lock'}
                      </button>
                    </div>
                  </div>
                )}
             </div>
          </div>
        </div>
      )}

      {previewDoc && <DocumentViewer mode="INVOICE" order={previewDoc} settings={adminSettings} onClose={() => setPreviewDoc(null)} />}
    </div>
  );
};

export default InvoiceManager;
