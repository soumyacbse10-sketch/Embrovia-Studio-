
import React, { useState } from 'react';
import { Order, OrderStatus, AdminSettings, DocData } from '../../types.ts';
import DocumentViewer from '../Shared/DocumentViewer.tsx';

interface LabelManagerProps {
  orders: Order[];
  adminSettings: AdminSettings;
  onUpdateOrder: (id: string, updates: Partial<Order>, log?: string) => void;
}

const LabelManager: React.FC<LabelManagerProps> = ({ orders, adminSettings, onUpdateOrder }) => {
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [editData, setEditData] = useState<Partial<DocData>>({});
  const [previewDoc, setPreviewDoc] = useState<Order | null>(null);

  const startEdit = (order: Order) => {
    // ENFORCEMENT: ACTION PERMISSION MATRIX
    if (order.status !== OrderStatus.INVOICE_FINAL) {
        alert("Action Blocked: Labels can only be created after the Invoice is marked FINAL.");
        return;
    }
    setSelectedOrder(order);
    setEditData({
      title: order.labelData?.title || 'Delivery Label',
      nameOverride: order.labelData?.nameOverride || order.invoiceData?.nameOverride || order.deliveryAddress.fullName || order.userName,
      addressOverride: order.labelData?.addressOverride || `${order.deliveryAddress.houseFlat}, ${order.deliveryAddress.streetArea}`,
      phoneOverride: order.labelData?.phoneOverride || order.deliveryAddress.phone,
      note: order.labelData?.note || 'Fragile. Hand-embroidered artwork.'
    });
  };

  const finalize = () => {
    if (!selectedOrder) return;
    if (!editData.nameOverride?.trim() || !editData.addressOverride?.trim() || !editData.phoneOverride?.trim()) {
      alert("Name, Address, and Phone are MANDATORY.");
      return;
    }

    if (confirm("Mark label FINAL? This action cannot be undone.")) {
        const finalizedData: DocData = {
          title: editData.title || 'Delivery Label',
          note: editData.note || '',
          lockedAt: new Date().toISOString(),
          nameOverride: editData.nameOverride,
          addressOverride: editData.addressOverride,
          phoneOverride: editData.phoneOverride
        };
        onUpdateOrder(selectedOrder.id, { 
            labelData: finalizedData, 
            status: OrderStatus.LABEL_FINAL,
            checklist: { ...selectedOrder.checklist, labelsGenerated: true }
        }, "Logistics label finalized");
        setSelectedOrder(null);
    }
  };

  return (
    <div className="space-y-10">
      <div>
        <h1 className="text-4xl font-serif font-bold text-[#5C4D3C]">Logistics Labels</h1>
        <p className="text-[#A68F7A] mt-1 italic">Parcel identification for couriers.</p>
      </div>

      <div className="grid gap-6">
        {orders.map(order => (
          <div key={order.id} className="bg-white p-8 rounded-3xl border border-[#EBE3D5] flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-6">
              <div className="w-14 h-14 bg-gray-50 border border-gray-100 rounded-2xl flex items-center justify-center font-bold text-gray-400">📦</div>
              <div>
                <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">ID: {order.id}</p>
                <h3 className="text-xl font-serif font-bold text-[#5C4D3C]">{order.labelData?.nameOverride || order.userName}</h3>
                <p className="text-xs text-[#7C6A58] uppercase font-bold">{order.status}</p>
              </div>
            </div>
            <div className="flex gap-4">
               {order.labelData?.lockedAt ? (
                 <button onClick={() => setPreviewDoc(order)} className="px-6 py-2 bg-black text-white text-[10px] font-bold uppercase rounded-xl">Print Label</button>
               ) : (
                 <button onClick={() => startEdit(order)} className="px-6 py-2 bg-[#EBE3D5] text-[#5C4D3C] text-[10px] font-bold uppercase rounded-xl">Create Label</button>
               )}
            </div>
          </div>
        ))}
      </div>

      {selectedOrder && (
        <div className="fixed inset-0 z-[400] bg-black/60 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-[40px] shadow-2xl overflow-hidden animate-in zoom-in">
             <div className="bg-black p-8 text-white flex justify-between items-center">
                <h2 className="text-2xl font-serif font-bold">Label Finalizer</h2>
                <button onClick={() => setSelectedOrder(null)} className="text-3xl opacity-60">&times;</button>
             </div>
             <div className="p-10 space-y-6">
                <div className="space-y-4">
                   <div className="space-y-1">
                      <label className="text-[9px] font-bold uppercase text-gray-400">Recipient Name</label>
                      <input value={editData.nameOverride} onChange={e => setEditData({...editData, nameOverride: e.target.value})} className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm font-bold" />
                   </div>
                   <div className="space-y-1">
                      <label className="text-[9px] font-bold uppercase text-gray-400">Courier Phone</label>
                      <input value={editData.phoneOverride} onChange={e => setEditData({...editData, phoneOverride: e.target.value})} className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm" />
                   </div>
                </div>
                <div className="pt-6 border-t flex gap-4">
                   <button onClick={() => setSelectedOrder(null)} className="flex-1 py-4 border rounded-2xl text-xs font-bold uppercase">Cancel</button>
                   <button onClick={finalize} className="flex-1 py-4 bg-black text-white rounded-2xl text-xs font-bold uppercase shadow-xl">Finalize Label</button>
                </div>
             </div>
          </div>
        </div>
      )}

      {previewDoc && <DocumentViewer mode="LABEL" order={previewDoc} settings={adminSettings} onClose={() => setPreviewDoc(null)} />}
    </div>
  );
};

export default LabelManager;
