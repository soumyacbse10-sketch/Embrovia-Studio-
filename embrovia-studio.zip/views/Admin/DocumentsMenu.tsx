
import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { AdminSettings, DocumentTheme } from '../../types.ts';

interface DocumentsMenuProps {
  settings: AdminSettings;
  onUpdate: (s: AdminSettings) => void;
}

const DocumentsMenu: React.FC<DocumentsMenuProps> = ({ settings, onUpdate }) => {
  const [activeTab, setActiveTab] = useState<'assets' | 'theme' | 'labels'>('assets');
  const [isPolishing, setIsPolishing] = useState(false);
  const theme = settings.documentTheme;

  const updateTheme = (field: keyof DocumentTheme, value: any) => {
    onUpdate({ ...settings, documentTheme: { ...theme, [field]: value } });
  };

  const handleFileUpload = (field: 'businessLogo' | 'watermarkImage' | 'signatureImage', e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      const reader = new FileReader();
      reader.onload = (ev) => onUpdate({ ...settings, [field]: ev.target?.result as string });
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const polishWithAI = async (label: string, field: keyof DocumentTheme) => {
    const originalText = theme[field] as string;
    if (!originalText.trim()) return;
    setIsPolishing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Rewrite this ${label} for an invoice to sound more professional, artisanal, and premium for an embroidery brand: "${originalText}"`;
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt
      });
      const polished = response.text || originalText;
      updateTheme(field, polished.trim());
    } catch (e) {
      alert("AI polishing failed. Please try again.");
    } finally {
      setIsPolishing(false);
    }
  };

  return (
    <div className="max-w-5xl space-y-8 animate-in fade-in slide-in-from-top-4 duration-500">
      <div className="space-y-1">
        <h1 className="text-3xl font-serif font-bold text-[#5C4D3C]">Invoices & Receipts Hub</h1>
        <p className="text-[#A68F7A] text-sm">Design artisanal documents that represent your brand.</p>
      </div>

      <div className="flex bg-white p-1 rounded-2xl border border-[#EBE3D5] w-fit shadow-sm">
        {['assets', 'theme', 'labels'].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab as any)}
            className={`px-6 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${activeTab === tab ? 'bg-[#5C4D3C] text-white shadow-md' : 'text-[#A68F7A] hover:bg-[#FDFBF7]'}`}
          >
            {tab}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        <div className="space-y-8">
          {activeTab === 'assets' && (
            <div className="bg-white p-8 rounded-3xl border border-[#EBE3D5] shadow-sm space-y-8">
              <h3 className="font-serif font-bold text-lg text-[#5C4D3C]">Brand Assets</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <AssetUploader 
                  label="Primary Logo" 
                  image={settings.businessLogo} 
                  onUpload={(e) => handleFileUpload('businessLogo', e)} 
                />
                <AssetUploader 
                  label="Watermark" 
                  image={settings.watermarkImage} 
                  onUpload={(e) => handleFileUpload('watermarkImage', e)} 
                />
                <AssetUploader 
                  label="Signature" 
                  image={settings.signatureImage} 
                  onUpload={(e) => handleFileUpload('signatureImage', e)} 
                />
              </div>
              <div className="pt-6 border-t border-[#EBE3D5] space-y-4">
                 <div className="flex items-center justify-between">
                    <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Enable Watermark</label>
                    <button 
                      onClick={() => updateTheme('showWatermark', !theme.showWatermark)}
                      className={`w-12 h-6 rounded-full transition-all relative ${theme.showWatermark ? 'bg-[#5C4D3C]' : 'bg-gray-200'}`}
                    >
                      <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${theme.showWatermark ? 'right-1' : 'left-1'}`} />
                    </button>
                 </div>
                 <div className="space-y-2">
                    <div className="flex justify-between">
                      <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Watermark Opacity</label>
                      <span className="text-[10px] font-mono">{(theme.watermarkOpacity * 100).toFixed(0)}%</span>
                    </div>
                    <input 
                      type="range" min="0" max="0.3" step="0.01" 
                      value={theme.watermarkOpacity} 
                      onChange={(e) => updateTheme('watermarkOpacity', parseFloat(e.target.value))}
                      className="w-full accent-[#5C4D3C]"
                    />
                 </div>
              </div>
            </div>
          )}

          {activeTab === 'theme' && (
            <div className="bg-white p-8 rounded-3xl border border-[#EBE3D5] shadow-sm space-y-8">
              <h3 className="font-serif font-bold text-lg text-[#5C4D3C]">Visual Identity</h3>
              <div className="grid grid-cols-2 gap-6">
                 <div className="space-y-2">
                    <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest block">Primary Color</label>
                    <div className="flex gap-2">
                      <input type="color" value={theme.primaryColor} onChange={(e) => updateTheme('primaryColor', e.target.value)} className="w-10 h-10 rounded-xl overflow-hidden cursor-pointer" />
                      <input type="text" value={theme.primaryColor} onChange={(e) => updateTheme('primaryColor', e.target.value)} className="flex-grow px-4 py-2 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-xs font-mono" />
                    </div>
                 </div>
                 <div className="space-y-2">
                    <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest block">Secondary Color</label>
                    <div className="flex gap-2">
                      <input type="color" value={theme.secondaryColor} onChange={(e) => updateTheme('secondaryColor', e.target.value)} className="w-10 h-10 rounded-xl overflow-hidden cursor-pointer" />
                      <input type="text" value={theme.secondaryColor} onChange={(e) => updateTheme('secondaryColor', e.target.value)} className="flex-grow px-4 py-2 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-xs font-mono" />
                    </div>
                 </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Typography</label>
                  <select value={theme.fontFamily} onChange={(e) => updateTheme('fontFamily', e.target.value)} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-xs outline-none">
                    <option value="serif">Premium Serif</option>
                    <option value="sans">Modern Sans</option>
                    <option value="mono">Precision Mono</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Layout Mode</label>
                  <select value={theme.layout} onChange={(e) => updateTheme('layout', e.target.value)} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-xs outline-none">
                    <option value="premium">Classic Premium</option>
                    <option value="minimal">Minimal Artisan</option>
                    <option value="boxed">Structured Boxed</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Header Align</label>
                  <select value={theme.headerAlignment} onChange={(e) => updateTheme('headerAlignment', e.target.value)} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-xs outline-none">
                    <option value="left">Left</option>
                    <option value="center">Center</option>
                    <option value="right">Right</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Divider Style</label>
                  <select value={theme.dividerStyle} onChange={(e) => updateTheme('dividerStyle', e.target.value)} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-xs outline-none">
                    <option value="solid">Solid Line</option>
                    <option value="dashed">Dashed Line</option>
                    <option value="dotted">Artisan Dots</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'labels' && (
            <div className="bg-white p-8 rounded-3xl border border-[#EBE3D5] shadow-sm space-y-8">
              <h3 className="font-serif font-bold text-lg text-[#5C4D3C]">Labels & Messaging</h3>
              <div className="space-y-4">
                 <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                       <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Invoice Title</label>
                       <input value={theme.invoiceTitle} onChange={(e) => updateTheme('invoiceTitle', e.target.value)} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-xs" />
                    </div>
                    <div className="space-y-1">
                       <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Receipt Title</label>
                       <input value={theme.receiptTitle} onChange={(e) => updateTheme('receiptTitle', e.target.value)} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-xs" />
                    </div>
                 </div>
                 <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Footer / Artisan Note</label>
                      <button 
                        onClick={() => polishWithAI('footer note', 'footerNote')}
                        disabled={isPolishing}
                        className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest hover:text-indigo-800 disabled:opacity-50"
                      >
                        {isPolishing ? '✨ Polishing...' : '✨ AI Enhance'}
                      </button>
                    </div>
                    <textarea 
                      value={theme.footerNote}
                      onChange={(e) => updateTheme('footerNote', e.target.value)}
                      className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-2xl text-xs outline-none leading-relaxed"
                      rows={5}
                    />
                 </div>
              </div>
            </div>
          )}
        </div>

        {/* Live Preview Simulation */}
        <div className="lg:sticky lg:top-24 space-y-4">
           <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-[3px] text-center">Live Preview Simulation</p>
           <div 
             className={`bg-white border-2 border-[#EBE3D5] rounded-[40px] p-10 relative overflow-hidden shadow-2xl flex flex-col justify-between aspect-[3/4.2] ${theme.fontFamily === 'serif' ? 'font-serif' : theme.fontFamily === 'mono' ? 'font-mono' : 'font-sans'}`}
           >
              {theme.showWatermark && settings.watermarkImage && (
                <div 
                  className="absolute inset-0 flex items-center justify-center -rotate-12 pointer-events-none scale-150"
                  style={{ opacity: theme.watermarkOpacity }}
                >
                  <img src={settings.watermarkImage} alt="Watermark" />
                </div>
              )}
              
              <div className={`
                ${theme.headerAlignment === 'center' ? 'text-center' : theme.headerAlignment === 'right' ? 'text-right' : 'text-left'}
                ${theme.layout === 'boxed' ? 'bg-[#FDFBF7] p-6 rounded-2xl border border-[#EBE3D5]' : ''}
              `}>
                 <img src={settings.businessLogo} className={`w-12 h-12 object-contain mb-4 ${theme.headerAlignment === 'center' ? 'mx-auto' : theme.headerAlignment === 'right' ? 'ml-auto' : ''}`} />
                 <h2 className="text-2xl font-bold" style={{ color: theme.primaryColor }}>{settings.businessName}</h2>
                 <p className="text-[9px] text-[#A68F7A] mt-1">{settings.businessAddress}</p>
              </div>

              <div className="mt-8 space-y-4">
                 <div className="flex justify-between items-end border-b pb-4" style={{ borderStyle: theme.dividerStyle, borderColor: theme.secondaryColor }}>
                    <h3 className="text-3xl font-bold" style={{ color: theme.primaryColor }}>{theme.invoiceTitle}</h3>
                    <div className="text-right">
                       <p className="text-[8px] font-bold text-[#A68F7A] uppercase">Date</p>
                       <p className="text-[10px] font-bold">15 March 2024</p>
                    </div>
                 </div>
                 <div className="space-y-2 opacity-20">
                    <div className="h-4 bg-gray-200 w-full rounded"></div>
                    <div className="h-4 bg-gray-200 w-3/4 rounded"></div>
                 </div>
              </div>

              <div className="mt-auto pt-10 text-center space-y-6">
                 <p className="text-[10px] italic text-[#7C6A58] opacity-60 px-8">"{theme.footerNote}"</p>
                 <div className="flex flex-col items-center gap-4">
                    {settings.signatureImage && (
                      <div className="h-16 relative">
                         <img src={settings.signatureImage} className="h-full object-contain grayscale opacity-60" />
                         <div className="absolute inset-x-0 bottom-0 h-px bg-gray-200" style={{ borderStyle: theme.dividerStyle }}></div>
                      </div>
                    )}
                    <span className="text-[6px] uppercase tracking-[3px] text-[#A68F7A]">Authorized Signatory</span>
                 </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

const AssetUploader: React.FC<{ label: string; image?: string; onUpload: (e: React.ChangeEvent<HTMLInputElement>) => void }> = ({ label, image, onUpload }) => (
  <div className="space-y-2">
    <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest block">{label}</label>
    <div className="w-full aspect-square bg-[#FDFBF7] border border-[#EBE3D5] rounded-3xl flex items-center justify-center relative overflow-hidden group">
      {image ? (
        <img src={image} className="w-full h-full object-contain p-4 transition-transform group-hover:scale-105" alt={label} />
      ) : (
        <span className="text-2xl opacity-20">📸</span>
      )}
      <label className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition-all">
        <input type="file" className="hidden" onChange={onUpload} accept="image/*" />
        <span className="text-[10px] text-white font-bold uppercase tracking-widest">Update</span>
      </label>
    </div>
  </div>
);

export default DocumentsMenu;
