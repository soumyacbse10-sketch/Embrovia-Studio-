
import React from 'react';
import { AdminSettings } from '../../types.ts';

interface PaymentsMenuProps {
  settings: AdminSettings;
  onUpdate: (s: AdminSettings) => void;
}

const PaymentsMenu: React.FC<PaymentsMenuProps> = ({ settings, onUpdate }) => {
  const updateRazorpay = (field: keyof AdminSettings['razorpayConfig'], value: any) => {
    onUpdate({ ...settings, razorpayConfig: { ...settings.razorpayConfig, [field]: value } });
  };

  const updateBank = (field: keyof AdminSettings['bankDetails'], value: string) => {
    onUpdate({ ...settings, bankDetails: { ...settings.bankDetails, [field]: value } });
  };

  const handleQRUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      const reader = new FileReader();
      reader.onload = (ev) => onUpdate({ ...settings, qrCodeImage: ev.target?.result as string });
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  return (
    <div className="max-w-4xl space-y-8 animate-in fade-in slide-in-from-top-4 duration-500">
      <div className="space-y-1">
        <h1 className="text-3xl font-serif font-bold text-[#5C4D3C]">Payments Hub</h1>
        <p className="text-[#A68F7A] text-sm">Configure gateways, settlements, and QR codes.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Razorpay Integration */}
        <div className="bg-white p-8 rounded-3xl border border-[#EBE3D5] shadow-sm space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-serif font-bold text-lg text-[#5C4D3C]">Razorpay Secure</h3>
            <button 
              onClick={() => updateRazorpay('isEnabled', !settings.razorpayConfig.isEnabled)}
              className={`w-12 h-6 rounded-full transition-all relative ${settings.razorpayConfig.isEnabled ? 'bg-[#5C4D3C]' : 'bg-gray-200'}`}
            >
              <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${settings.razorpayConfig.isEnabled ? 'right-1' : 'left-1'}`} />
            </button>
          </div>
          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Key ID (Live/Test)</label>
              <input 
                type="text" value={settings.razorpayConfig.keyId}
                onChange={(e) => updateRazorpay('keyId', e.target.value)}
                className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm font-mono outline-none"
                placeholder="rzp_live_..."
              />
            </div>
            <p className="text-[10px] text-[#A68F7A] italic leading-relaxed">
              Enabling Razorpay allows customers to pay instantly via UPI, Cards, and Net Banking.
            </p>
          </div>
        </div>

        {/* QR Code Settings */}
        <div className="bg-white p-8 rounded-3xl border border-[#EBE3D5] shadow-sm space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-serif font-bold text-lg text-[#5C4D3C]">QR Scan & Pay</h3>
            <button 
              onClick={() => onUpdate({ ...settings, qrEnabled: !settings.qrEnabled })}
              className={`w-12 h-6 rounded-full transition-all relative ${settings.qrEnabled ? 'bg-[#5C4D3C]' : 'bg-gray-200'}`}
            >
              <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${settings.qrEnabled ? 'right-1' : 'left-1'}`} />
            </button>
          </div>
          <div className="flex gap-6 items-start">
            <div className="w-24 h-24 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl overflow-hidden relative group">
              <img src={settings.qrCodeImage} alt="QR Code" className="w-full h-full object-contain" />
              <label className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center cursor-pointer transition-opacity">
                <span className="text-[10px] text-white font-bold uppercase">Update</span>
                <input type="file" className="hidden" onChange={handleQRUpload} accept="image/*" />
              </label>
            </div>
            <div className="flex-grow space-y-2">
              <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Payment Instructions</label>
              <textarea 
                value={settings.qrInstructions}
                onChange={(e) => onUpdate({ ...settings, qrInstructions: e.target.value })}
                className="w-full px-3 py-2 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-[11px] outline-none"
                rows={3}
              />
            </div>
          </div>
        </div>

        {/* Bank Settlement Details */}
        <div className="bg-white p-8 rounded-3xl border border-[#EBE3D5] shadow-sm space-y-6 md:col-span-2">
          <h3 className="font-serif font-bold text-lg text-[#5C4D3C]">Bank Settlement Profile</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Account Holder Name</label>
              <input type="text" value={settings.bankDetails.accountHolder} onChange={(e) => updateBank('accountHolder', e.target.value)} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm outline-none" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Bank Name</label>
              <input type="text" value={settings.bankDetails.bankName} onChange={(e) => updateBank('bankName', e.target.value)} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm outline-none" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Account Number</label>
              <input type="text" value={settings.bankDetails.accountNumber} onChange={(e) => updateBank('accountNumber', e.target.value)} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm font-mono outline-none" />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">IFSC Code</label>
              <input type="text" value={settings.bankDetails.ifscCode} onChange={(e) => updateBank('ifscCode', e.target.value)} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm font-mono outline-none" />
            </div>
          </div>
          <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100 flex items-center gap-3">
             <span className="text-xl">🔒</span>
             <p className="text-[11px] text-amber-800 leading-relaxed italic">These details are sensitive and used exclusively for your internal studio records and settlement tracking.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentsMenu;
