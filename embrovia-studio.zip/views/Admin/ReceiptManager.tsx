
import React, { useState } from 'react';
import { Order, OrderStatus, AdminSettings, DocData } from '../../types.ts';
import DocumentViewer from '../Shared/DocumentViewer.tsx';
import { GoogleGenAI } from "@google/genai";

interface ReceiptManagerProps {
  orders: Order[];
  adminSettings: AdminSettings;
  onUpdateOrder: (id: string, updates: Partial<Order>) => void;
}

const ReceiptManager: React.FC<ReceiptManagerProps> = ({ orders, adminSettings, onUpdateOrder }) => {
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [editData, setEditData] = useState<Partial<DocData>>({});
  const [isGenerating, setIsGenerating] = useState(false);
  const [previewDoc, setPreviewDoc] = useState<Order | null>(null);

  // ENFORCEMENT: ONLY ORDERS WITH EXPLICIT CUSTOMER PAYMENT ACTIONS OR VERIFIED COD
  const paidOrders = orders.filter(o => 
    o.status === OrderStatus.PAYMENT_SUCCESS || 
    o.status === OrderStatus.COD_CONFIRMED ||
    o.status === OrderStatus.INVOICE_FINAL ||
    o.status === OrderStatus.LABEL_FINAL ||
    o.status === OrderStatus.SHIPPED ||
    o.status === OrderStatus.DELIVERED
  );

  const startEdit = (order: Order) => {
    // HARD STATE GATE
    // Fix: Removed reference to non-existent OrderStatus members and used CUSTOMER_PAYMENT_PENDING
    const isPaid = order.status !== OrderStatus.DRAFT && order.status !== OrderStatus.CUSTOMER_PAYMENT_PENDING;
    if (!isPaid) {
        alert("Action Blocked: Proof of receipt is only available after payment is finalized.");
        return;
    }
    setSelectedOrder(order);
    setEditData({
      title: order.receiptData?.title || 'Payment Receipt',
      note: order.receiptData?.note || 'Transaction verified and secured by Embrovia Studio.',
      nameOverride: order.receiptData?.nameOverride || order.invoiceData?.nameOverride || order.userName
    });
  };

  const handleAI = async () => {
    if (!selectedOrder) return;
    setIsGenerating(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Craft a sophisticated, artisanal payment receipt message for "${selectedOrder.userName}" for ₹${selectedOrder.total}. Focus on craftsmanship and security. JSON: { "note": "string" }`;
      const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: prompt, config: { responseMimeType: 'application/json' } });
      const res = JSON.parse(response.text || '{}');
      setEditData(prev => ({ ...prev, note: res.note }));
    } catch (e) {
      alert("AI communication snagged.");
    } finally {
      setIsGenerating(false);
    }
  };

  const finalize = () => {
    if (!selectedOrder) return;
    if (confirm("Generate official receipt? This action is tracked in the audit history.")) {
        const finalizedData: DocData = {
          title: editData.title || 'Payment Receipt',
          note: editData.note || '',
          lockedAt: new Date().toISOString(),
          nameOverride: editData.nameOverride
        };
        onUpdateOrder(selectedOrder.id, { receiptData: finalizedData });
        setSelectedOrder(null);
    }
  };

  return (
    <div className="space-y-10">
      <div>
        <h1 className="text-4xl font-serif font-bold text-[#5C4D3C]">Payment Ledger</h1>
        <p className="text-[#A68F7A] mt-1 italic">Verified transaction proof for studio records.</p>
      </div>

      <div className="grid gap-6">
        {paidOrders.length === 0 ? (
          <div className="text-center py-20 bg-white border-2 border-dashed border-[#EBE3D5] rounded-[40px]">
             <p className="text-[#7C6A58] italic">No verified payments found for receipt generation.</p>
          </div>
        ) : (
          paidOrders.map(order => (
            <div key={order.id} className="bg-white p-8 rounded-[40px] border border-[#EBE3D5] flex items-center justify-between shadow-sm group hover:border-[#A68F7A] transition-all">
              <div className="flex items-center gap-6">
                <div className="w-16 h-16 bg-emerald-50 border border-emerald-100 rounded-[24px] flex items-center justify-center font-bold text-emerald-600 shadow-inner">✓</div>
                <div>
                  <div className="flex items-center gap-3">
                    <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">ID: {order.id}</p>
                    <span className="bg-emerald-600 text-white px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-[1px] shadow-sm">PAID</span>
                  </div>
                  <h3 className="text-xl font-serif font-bold text-[#5C4D3C] mt-1">{order.receiptData?.nameOverride || order.userName}</h3>
                  <p className="text-[10px] text-[#A68F7A] font-bold uppercase mt-1 tracking-widest">{order.paymentMethod} • ₹{order.total.toLocaleString()}</p>
                </div>
              </div>
              <div className="flex gap-4">
                 {order.receiptData?.lockedAt ? (
                   <button onClick={() => setPreviewDoc(order)} className="px-8 py-3 bg-[#5C4D3C] text-white text-[10px] font-bold uppercase tracking-widest rounded-2xl shadow-xl hover:bg-black transition-all">Print Receipt</button>
                 ) : (
                   <button onClick={() => startEdit(order)} className="px-8 py-3 bg-[#EBE3D5] text-[#5C4D3C] text-[10px] font-bold uppercase tracking-widest rounded-2xl hover:bg-[#D4C5B9] transition-all">Finalize Doc</button>
                 )}
              </div>
            </div>
          ))
        )}
      </div>

      {selectedOrder && (
        <div className="fixed inset-0 z-[400] bg-black/60 backdrop-blur-md flex items-center justify-center p-6">
          <div className="bg-white w-full max-w-lg rounded-[60px] shadow-2xl overflow-hidden animate-in zoom-in">
             <div className="bg-emerald-600 p-10 text-white flex justify-between items-center">
                <div>
                  <h2 className="text-2xl font-serif font-bold">Receipt Architect</h2>
                  <p className="text-[10px] uppercase tracking-widest opacity-80 mt-1">Transaction Proofing</p>
                </div>
                <button onClick={() => setSelectedOrder(null)} className="text-4xl opacity-60 hover:opacity-100 transition-opacity" disabled={isGenerating}>&times;</button>
             </div>
             <div className="p-10 space-y-8">
                <div className="space-y-6">
                   <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400 block px-2">Account Name (Override)</label>
                      <input value={editData.nameOverride} onChange={e => setEditData({...editData, nameOverride: e.target.value})} className="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-3xl text-sm font-bold text-[#5C4D3C] outline-none focus:bg-white focus:border-emerald-200 transition-all" />
                   </div>
                   <div className="space-y-2">
                      <div className="flex justify-between items-center px-2">
                        <label className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Formal Note</label>
                        <button onClick={handleAI} className="text-[9px] text-indigo-600 font-bold uppercase tracking-widest hover:underline" disabled={isGenerating}>
                          {isGenerating ? '⌛ Polishing...' : '✨ AI Polish'}
                        </button>
                      </div>
                      <textarea value={editData.note} onChange={e => setEditData({...editData, note: e.target.value})} className="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-3xl text-sm outline-none leading-relaxed h-32 focus:bg-white focus:border-emerald-200 transition-all" />
                   </div>
                </div>
                <div className="pt-6 border-t flex gap-4">
                   <button onClick={() => setSelectedOrder(null)} className="flex-1 py-5 border border-gray-100 rounded-3xl text-[10px] font-bold uppercase tracking-widest text-gray-400 hover:bg-gray-50 transition-all">Discard</button>
                   <button onClick={finalize} className="flex-1 py-5 bg-emerald-600 text-white rounded-3xl text-[10px] font-bold uppercase tracking-widest shadow-xl hover:bg-emerald-700 transition-all">Secure & Generate</button>
                </div>
             </div>
          </div>
        </div>
      )}

      {previewDoc && <DocumentViewer mode="RECEIPT" order={previewDoc} settings={adminSettings} onClose={() => setPreviewDoc(null)} />}
    </div>
  );
};

export default ReceiptManager;
