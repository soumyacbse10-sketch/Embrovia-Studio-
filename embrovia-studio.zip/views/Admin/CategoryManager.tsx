
import React, { useState } from 'react';
import { Category, AdminSettings } from '../../types.ts';

interface CategoryManagerProps {
  settings: AdminSettings;
  onUpdate: (s: Partial<AdminSettings>) => void;
}

const CategoryManager: React.FC<CategoryManagerProps> = ({ settings, onUpdate }) => {
  const [editingCat, setEditingCat] = useState<Partial<Category> | null>(null);

  const handleUpsert = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCat) return;

    const updatedCategories = editingCat.id 
      ? settings.categories.map(c => c.id === editingCat.id ? (editingCat as Category) : c)
      : [...settings.categories, { ...editingCat, id: `cat-${Date.now()}`, isEnabled: true } as Category];

    onUpdate({ categories: updatedCategories });
    setEditingCat(null);
  };

  const deleteCat = (id: string) => {
    // Only allow deletion if no products exist (simulated check by logic, though products are global)
    if (confirm("Permanently remove this artisanal category?")) {
      onUpdate({ categories: settings.categories.filter(c => c.id !== id) });
    }
  };

  const toggleStatus = (cat: Category) => {
    onUpdate({ categories: settings.categories.map(c => c.id === cat.id ? { ...c, isEnabled: !c.isEnabled } : c) });
  };

  return (
    <div className="space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-4xl font-serif font-bold text-[#5C4D3C]">Artisanal Categories</h1>
          <p className="text-[#A68F7A] mt-1 italic">Organize your studio masterpieces by craft type.</p>
        </div>
        <button 
          onClick={() => setEditingCat({ name: '', description: '', image: 'https://picsum.photos/seed/studio/400/400', isEnabled: true })}
          className="bg-[#5C4D3C] text-white px-8 py-3 rounded-full font-bold shadow-lg hover:bg-black transition-all"
        >
          + Add Category
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {settings.categories.map(cat => (
          <div key={cat.id} className={`bg-white p-6 rounded-[32px] border transition-all shadow-sm ${cat.isEnabled ? 'border-[#EBE3D5]' : 'border-red-100 opacity-60 grayscale'}`}>
            <div className="aspect-square rounded-2xl overflow-hidden mb-4 border border-[#EBE3D5]">
               <img src={cat.image} className="w-full h-full object-cover" alt={cat.name} />
            </div>
            <div className="flex justify-between items-center mb-2">
              <h3 className="font-serif font-bold text-[#5C4D3C] text-lg">{cat.name}</h3>
              <button 
                onClick={() => toggleStatus(cat)}
                className={`px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-widest ${cat.isEnabled ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}
              >
                {cat.isEnabled ? 'Active' : 'Disabled'}
              </button>
            </div>
            <p className="text-[10px] text-[#A68F7A] leading-relaxed line-clamp-2 mb-6 h-8 italic">"{cat.description}"</p>
            <div className="flex gap-2 pt-4 border-t border-[#EBE3D5]">
               <button onClick={() => setEditingCat(cat)} className="flex-1 py-2 text-[10px] font-bold uppercase tracking-widest text-[#5C4D3C] bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl hover:bg-[#EBE3D5]">Edit</button>
               <button onClick={() => deleteCat(cat.id)} className="flex-1 py-2 text-[10px] font-bold uppercase tracking-widest text-rose-600 bg-rose-50 rounded-xl hover:bg-rose-100">Delete</button>
            </div>
          </div>
        ))}
      </div>

      {editingCat && (
        <div className="fixed inset-0 bg-[#5C4D3C]/60 backdrop-blur-md z-[200] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-[40px] shadow-2xl overflow-hidden animate-in zoom-in duration-300">
            <div className="px-8 py-6 border-b border-[#EBE3D5] flex justify-between items-center bg-[#FDFBF7]">
              <h2 className="text-xl font-serif font-bold text-[#5C4D3C]">Category Management</h2>
              <button onClick={() => setEditingCat(null)} className="text-3xl text-[#A68F7A]">&times;</button>
            </div>
            <form onSubmit={handleUpsert} className="p-8 space-y-6">
              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-widest text-[#A68F7A]">Category Name</label>
                <input required value={editingCat.name} onChange={(e) => setEditingCat({...editingCat, name: e.target.value})} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl outline-none text-sm font-bold text-[#5C4D3C]" />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-widest text-[#A68F7A]">Icon/Image URL</label>
                <input value={editingCat.image} onChange={(e) => setEditingCat({...editingCat, image: e.target.value})} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl outline-none text-[10px] font-mono" />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-widest text-[#A68F7A]">Artisanal Description</label>
                <textarea required value={editingCat.description} onChange={(e) => setEditingCat({...editingCat, description: e.target.value})} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl outline-none text-xs leading-relaxed" rows={3} />
              </div>
              <div className="pt-6 flex gap-4">
                <button type="button" onClick={() => setEditingCat(null)} className="flex-1 py-4 border border-[#EBE3D5] rounded-2xl text-[10px] font-bold uppercase tracking-widest text-[#A68F7A]">Discard</button>
                <button type="submit" className="flex-1 py-4 bg-[#5C4D3C] text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-xl">Save Category</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default CategoryManager;
