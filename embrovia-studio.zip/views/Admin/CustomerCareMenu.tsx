
import React from 'react';
import { AdminSettings } from '../../types.ts';

interface CustomerCareMenuProps {
  settings: AdminSettings;
  onUpdate: (s: AdminSettings) => void;
}

const CustomerCareMenu: React.FC<CustomerCareMenuProps> = ({ settings, onUpdate }) => {
  const toggle = (field: keyof AdminSettings) => {
    onUpdate({ ...settings, [field]: !settings[field as any] });
  };

  const update = (field: keyof AdminSettings, value: string) => {
    onUpdate({ ...settings, [field]: value });
  };

  return (
    <div className="max-w-3xl space-y-8 animate-in fade-in slide-in-from-top-4 duration-500">
      <div className="space-y-1">
        <h1 className="text-3xl font-serif font-bold text-[#5C4D3C]">Customer Care Desk</h1>
        <p className="text-[#A68F7A] text-sm">Control how your customers can reach out for support.</p>
      </div>

      <div className="bg-white p-8 rounded-3xl border border-[#EBE3D5] shadow-sm space-y-8">
        {[
          { label: 'WhatsApp Support', field: 'supportWhatsApp', toggleField: 'supportWhatsAppEnabled', icon: '💬', placeholder: '+91 9876543210' },
          { label: 'Phone Support', field: 'supportPhone', toggleField: 'supportPhoneEnabled', icon: '📞', placeholder: '+91 9876543210' },
          { label: 'Email Support', field: 'supportEmail', toggleField: 'supportEmailEnabled', icon: '✉️', placeholder: 'support@embrovia.studio' },
        ].map(item => (
          <div key={item.field} className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-8 border-b border-[#EBE3D5] last:border-0 last:pb-0">
            <div className="flex items-center gap-4">
               <div className="w-12 h-12 bg-[#FDFBF7] rounded-2xl flex items-center justify-center text-xl shadow-inner border border-[#EBE3D5]">{item.icon}</div>
               <div>
                  <h4 className="font-bold text-[#5C4D3C] text-sm">{item.label}</h4>
                  <p className="text-[10px] text-[#A68F7A] uppercase tracking-widest mt-1">Direct Contact Route</p>
               </div>
            </div>
            <div className="flex-grow max-w-sm flex items-center gap-4">
              <input 
                type="text" value={settings[item.field as keyof AdminSettings] as string}
                onChange={(e) => update(item.field as keyof AdminSettings, e.target.value)}
                placeholder={item.placeholder}
                className="flex-grow px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm outline-none"
              />
              <button 
                onClick={() => toggle(item.toggleField as keyof AdminSettings)}
                className={`w-14 h-7 rounded-full transition-all relative shrink-0 ${settings[item.toggleField as keyof AdminSettings] ? 'bg-[#5C4D3C]' : 'bg-gray-200'}`}
              >
                <div className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-all ${settings[item.toggleField as keyof AdminSettings] ? 'right-1' : 'left-1'}`} />
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-[#5C4D3C] p-8 rounded-3xl text-white shadow-xl relative overflow-hidden group">
         <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform">🎧</div>
         <h4 className="text-xl font-serif font-bold italic mb-2">Omnichannel Availability</h4>
         <p className="text-sm opacity-70 leading-relaxed max-w-md">Enabling these options will display contact buttons on the user profile, home screen, and order tracking pages.</p>
      </div>
    </div>
  );
};

export default CustomerCareMenu;
