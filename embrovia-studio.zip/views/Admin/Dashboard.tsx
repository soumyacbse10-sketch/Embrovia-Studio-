
import React from 'react';
import { Link } from 'react-router-dom';
import { Order, Product, OrderStatus } from '../../types.ts';

interface AdminDashboardProps {
  orders: Order[];
  products: Product[];
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ orders, products }) => {
  const totalRevenue = orders.reduce((acc, curr) => acc + curr.total, 0);
  const pendingPricing = orders.filter(o => o.status === OrderStatus.DRAFT).length;
  // Fixed typo ORDER_CONFIRMED to CONFIRMED
  const inProduction = orders.filter(o => o.status === OrderStatus.CONFIRMED).length;
  const activeShipments = orders.filter(o => o.status === OrderStatus.SHIPPED).length;

  return (
    <div className="space-y-10">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-4xl font-serif font-bold text-[#5C4D3C]">Studio Analytics</h1>
          <p className="text-[#A68F7A] mt-1">Real-time studio operation metrics</p>
        </div>
        <div className="bg-[#A68F7A] text-white px-4 py-2 rounded-xl text-sm font-bold shadow-md uppercase tracking-wider">
          Artisanal OS v2.0
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <StatCard title="Total Earnings" value={`₹${totalRevenue.toLocaleString()}`} icon="💰" color="bg-emerald-50 text-emerald-700" />
        <StatCard title="Pricing Requests" value={pendingPricing} icon="⚖️" color="bg-yellow-50 text-yellow-700" highlight={pendingPricing > 0} />
        <StatCard title="In Production" value={inProduction} icon="🪡" color="bg-blue-50 text-blue-700" />
        <StatCard title="In Transit" value={activeShipments} icon="🚚" color="bg-purple-50 text-purple-700" />
      </div>

      <div className="grid lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-serif font-bold text-[#5C4D3C]">Recent Activity</h2>
            <Link to="/admin/orders" className="text-sm font-bold text-[#A68F7A] hover:underline">Manage All Orders</Link>
          </div>
          <div className="bg-white rounded-3xl border border-[#EBE3D5] shadow-sm overflow-hidden">
            <table className="w-full text-left">
              <thead className="bg-[#FDFBF7] border-b border-[#EBE3D5]">
                <tr>
                  <th className="px-6 py-4 text-xs font-bold text-[#7C6A58] uppercase">Order</th>
                  <th className="px-6 py-4 text-xs font-bold text-[#7C6A58] uppercase">Customer</th>
                  <th className="px-6 py-4 text-xs font-bold text-[#7C6A58] uppercase">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EBE3D5]">
                {orders.slice(0, 5).map(order => (
                  <tr key={order.id} className="hover:bg-[#FDFBF7] transition-colors">
                    <td className="px-6 py-4 font-mono text-xs text-[#5C4D3C] font-bold">{order.id.slice(-6)}</td>
                    <td className="px-6 py-4 text-sm text-[#7C6A58]">{order.userName}</td>
                    <td className="px-6 py-4">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        order.status === OrderStatus.DELIVERED ? 'bg-green-100 text-green-700' : 
                        order.status === OrderStatus.DRAFT ? 'bg-yellow-100 text-yellow-700' : 'bg-orange-100 text-orange-700'
                      }`}>
                        {order.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="space-y-6">
          <h2 className="text-2xl font-serif font-bold text-[#5C4D3C]">Quick Actions</h2>
          <div className="bg-white p-6 rounded-3xl border border-[#EBE3D5] shadow-sm space-y-4">
            <Link to="/admin/products" className="w-full flex items-center justify-between p-4 bg-[#FDFBF7] rounded-2xl border border-[#EBE3D5] hover:border-[#A68F7A] transition-all group">
              <span className="font-bold text-[#5C4D3C]">Add New Art</span>
              <span className="group-hover:translate-x-1 transition-transform">→</span>
            </Link>
            <Link to="/admin/settings" className="w-full flex items-center justify-between p-4 bg-[#FDFBF7] rounded-2xl border border-[#EBE3D5] hover:border-[#A68F7A] transition-all group">
              <span className="font-bold text-[#5C4D3C]">Update Payment QR</span>
              <span className="group-hover:translate-x-1 transition-transform">→</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ title: string, value: string | number, icon: string, color: string, highlight?: boolean }> = ({ title, value, icon, color, highlight }) => (
  <div className={`bg-white p-6 rounded-3xl border ${highlight ? 'border-yellow-400 ring-4 ring-yellow-50' : 'border-[#EBE3D5]'} shadow-sm flex items-center gap-4 transition-all`}>
    <div className={`w-12 h-12 rounded-2xl ${color} flex items-center justify-center text-xl`}>
      {icon}
    </div>
    <div>
      <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">{title}</p>
      <p className="text-2xl font-serif font-bold text-[#5C4D3C] mt-1">{value}</p>
    </div>
  </div>
);

export default AdminDashboard;
