
import React from 'react';
import { Link } from 'react-router-dom';
import { AdminSettings } from '../../types.ts';

interface AdminSettingsProps {
  settings: AdminSettings;
  onUpdate: (s: AdminSettings) => void;
}

const AdminSettingsView: React.FC<AdminSettingsProps> = ({ settings, onUpdate }) => {
  const handleLogoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (ev) => onUpdate({ ...settings, businessLogo: ev.target?.result as string });
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const updateTheme = (field: keyof AdminSettings['documentTheme'], value: any) => {
    onUpdate({
      ...settings,
      documentTheme: { ...settings.documentTheme, [field]: value }
    });
  };

  const updateBankDetails = (field: keyof AdminSettings['bankDetails'], value: string) => {
    onUpdate({
      ...settings,
      bankDetails: { ...settings.bankDetails, [field]: value }
    });
  };

  const updateRazorpay = (field: keyof AdminSettings['razorpayConfig'], value: any) => {
    onUpdate({
      ...settings,
      razorpayConfig: { ...settings.razorpayConfig, [field]: value }
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10 pb-20">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-serif font-bold text-[#5C4D3C]">Studio Settings</h1>
          <p className="text-[#A68F7A] mt-1">Manage payment methods, branding, and customer experience</p>
        </div>
        <Link 
          to="/admin/emails" 
          className="bg-[#5C4D3C] text-white px-6 py-3 rounded-xl font-bold hover:bg-[#483C2F] shadow-lg transition-all"
        >
          Email Hub
        </Link>
      </div>

      {/* Payment Gateways & Settlements */}
      <div className="bg-white p-8 rounded-3xl border border-[#EBE3D5] shadow-sm space-y-8">
        <h3 className="text-xl font-serif font-bold text-[#5C4D3C] border-b border-[#EBE3D5] pb-4">Payment Gateways & Settlements</h3>
        
        <div className="space-y-8">
          {/* Razorpay Setup */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-[#5C4D3C] uppercase tracking-wider">Razorpay Integration</h4>
              <button 
                onClick={() => updateRazorpay('isEnabled', !settings.razorpayConfig.isEnabled)}
                className={`w-12 h-6 rounded-full transition-all relative ${settings.razorpayConfig.isEnabled ? 'bg-[#5C4D3C]' : 'bg-gray-300'}`}
              >
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${settings.razorpayConfig.isEnabled ? 'right-1' : 'left-1'}`} />
              </button>
            </div>
            <div className="grid md:grid-cols-1 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Razorpay Key ID</label>
                <input 
                  type="text"
                  value={settings.razorpayConfig.keyId}
                  onChange={(e) => updateRazorpay('keyId', e.target.value)}
                  placeholder="rzp_live_..."
                  className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm outline-none font-mono"
                />
              </div>
            </div>
            <p className="text-[10px] text-[#A68F7A] italic">Ensure this key matches your Razorpay dashboard. Settlements will go to the bank account linked in Razorpay.</p>
          </div>

          <div className="border-t border-[#EBE3D5] pt-6"></div>

          {/* Settlement Bank Details */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold text-[#5C4D3C] uppercase tracking-wider">Settlement Bank Details</h4>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Account Holder Name</label>
                <input 
                  type="text"
                  value={settings.bankDetails.accountHolder}
                  onChange={(e) => updateBankDetails('accountHolder', e.target.value)}
                  className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm outline-none"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Bank Name</label>
                <input 
                  type="text"
                  value={settings.bankDetails.bankName}
                  onChange={(e) => updateBankDetails('bankName', e.target.value)}
                  className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm outline-none"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Account Number</label>
                <input 
                  type="text"
                  value={settings.bankDetails.accountNumber}
                  onChange={(e) => updateBankDetails('accountNumber', e.target.value)}
                  className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm outline-none font-mono"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">IFSC Code</label>
                <input 
                  type="text"
                  value={settings.bankDetails.ifscCode}
                  onChange={(e) => updateBankDetails('ifscCode', e.target.value)}
                  className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm outline-none font-mono"
                />
              </div>
            </div>
            <p className="text-[10px] text-[#A68F7A] italic">These details are for internal studio records and settlement tracking.</p>
          </div>
        </div>
      </div>

      {/* Brand Identity & Theme */}
      <div className="bg-white p-8 rounded-3xl border border-[#EBE3D5] shadow-sm space-y-8">
        <h3 className="text-xl font-serif font-bold text-[#5C4D3C] border-b border-[#EBE3D5] pb-4">Artisanal Branding & Themes</h3>
        
        <div className="grid md:grid-cols-2 gap-10">
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest block">Primary Brand Color</label>
              <div className="flex items-center gap-4">
                <input 
                  type="color" 
                  value={settings.documentTheme.primaryColor}
                  onChange={(e) => updateTheme('primaryColor', e.target.value)}
                  className="w-12 h-12 rounded-lg border border-[#EBE3D5] overflow-hidden"
                />
                <input 
                  type="text" 
                  value={settings.documentTheme.primaryColor}
                  onChange={(e) => updateTheme('primaryColor', e.target.value)}
                  className="flex-grow px-4 py-2 bg-[#FDFBF7] border border-[#EBE3D5] rounded-lg text-sm font-mono"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest block">Document Layout</label>
              <div className="grid grid-cols-2 gap-3">
                <button 
                  onClick={() => updateTheme('layout', 'premium')}
                  className={`p-3 rounded-xl border text-xs font-bold transition-all ${settings.documentTheme.layout === 'premium' ? 'bg-[#5C4D3C] text-white' : 'bg-[#FDFBF7] text-[#7C6A58] border-[#EBE3D5]'}`}
                >
                  Premium Serif
                </button>
                <button 
                  onClick={() => updateTheme('layout', 'minimal')}
                  className={`p-3 rounded-xl border text-xs font-bold transition-all ${settings.documentTheme.layout === 'minimal' ? 'bg-[#5C4D3C] text-white' : 'bg-[#FDFBF7] text-[#7C6A58] border-[#EBE3D5]'}`}
                >
                  Clean Sans
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest block">Invoice Footer Note</label>
              <textarea 
                value={settings.documentTheme.footerNote}
                onChange={(e) => updateTheme('footerNote', e.target.value)}
                rows={3}
                className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm outline-none"
                placeholder="A signature message for your customers..."
              />
            </div>
          </div>

          <div className="space-y-4">
            <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest block text-center">Identity Preview</label>
            <div className="aspect-[3/4] bg-white border-2 border-dashed border-[#EBE3D5] rounded-2xl p-6 flex flex-col justify-between overflow-hidden relative">
              {settings.documentTheme.showWatermark && (
                <div className="absolute inset-0 flex items-center justify-center opacity-[0.05] -rotate-12 pointer-events-none">
                  <img src={settings.businessLogo} className="w-1/2" alt="watermark" />
                </div>
              )}
              <div className={settings.documentTheme.headerAlignment === 'center' ? 'text-center' : 'text-left'}>
                <img src={settings.businessLogo} className="w-10 h-10 object-contain mb-2 inline-block" alt="logo" />
                <h4 className="font-serif font-bold text-lg" style={{ color: settings.documentTheme.primaryColor }}>{settings.businessName}</h4>
                <div className="w-12 h-1 bg-gray-200 mt-1 inline-block"></div>
              </div>
              <div className="space-y-2 opacity-30">
                <div className="h-2 bg-gray-200 w-full rounded"></div>
                <div className="h-2 bg-gray-200 w-5/6 rounded"></div>
                <div className="h-2 bg-gray-200 w-4/6 rounded"></div>
              </div>
              <div className="text-[8px] text-gray-400 italic text-center">
                {settings.documentTheme.footerNote.substring(0, 60)}...
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Business Details */}
      <div className="bg-white p-8 rounded-3xl border border-[#EBE3D5] shadow-sm space-y-8">
        <h3 className="text-xl font-serif font-bold text-[#5C4D3C] border-b border-[#EBE3D5] pb-4">Store Identification</h3>
        <div className="flex flex-col md:flex-row gap-8 items-start">
          <div className="space-y-2 flex-shrink-0">
            <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest block">Studio Logo</label>
            <div className="w-32 h-32 bg-[#FDFBF7] border border-[#EBE3D5] rounded-2xl flex items-center justify-center overflow-hidden relative group">
              <img src={settings.businessLogo} alt="Business Logo" className="w-full h-full object-contain" />
              <label className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-all cursor-pointer">
                <span className="text-white text-[10px] font-bold uppercase">Update</span>
                <input type="file" accept="image/*" className="hidden" onChange={handleLogoFileChange} />
              </label>
            </div>
          </div>
          <div className="grid md:grid-cols-2 gap-6 flex-grow">
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Business Name</label>
              <input value={settings.businessName} onChange={(e) => onUpdate({...settings, businessName: e.target.value})} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm" />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Billing Email</label>
              <input value={settings.businessEmail} onChange={(e) => onUpdate({...settings, businessEmail: e.target.value})} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm" />
            </div>
            <div className="space-y-2 md:col-span-2">
              <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Business Address</label>
              <textarea value={settings.businessAddress} onChange={(e) => onUpdate({...settings, businessAddress: e.target.value})} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm" rows={2} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminSettingsView;
