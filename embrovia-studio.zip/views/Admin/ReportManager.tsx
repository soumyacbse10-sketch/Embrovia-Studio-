
import React, { useState } from 'react';
import { Order, OrderStatus } from '../../types.ts';

interface ReportManagerProps {
  orders: Order[];
}

const ReportManager: React.FC<ReportManagerProps> = ({ orders }) => {
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  
  const stats = orders.reduce((acc, o) => ({
    totalSales: acc.totalSales + o.total,
    deliveryTotal: acc.deliveryTotal + o.shippingCharge,
    packagingTotal: acc.packagingTotal + o.packagingCharges,
    discountTotal: acc.discountTotal + o.discount,
    count: acc.count + 1
  }), { totalSales: 0, deliveryTotal: 0, packagingTotal: 0, discountTotal: 0, count: 0 });

  const exportCSV = () => {
    const headers = ['Order ID', 'Customer', 'Date', 'Amount', 'Shipping', 'Packaging', 'Discount', 'Status'];
    const rows = orders.map(o => [
      o.id, o.userName, new Date(o.createdAt).toLocaleDateString(), 
      o.total, o.shippingCharge, o.packagingCharges, o.discount, o.status
    ]);
    const csvContent = "data:text/csv;charset=utf-8," + headers.join(",") + "\n" + rows.map(r => r.join(",")).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `embrovia_report_${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
  };

  return (
    <div className="space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-4xl font-serif font-bold text-[#5C4D3C]">Sales Intel</h1>
          <p className="text-[#A68F7A] mt-1">Financial performance and studio growth metrics.</p>
        </div>
        <div className="flex gap-4">
           <button onClick={() => window.print()} className="bg-white border border-[#EBE3D5] text-[#5C4D3C] px-6 py-3 rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-sm hover:bg-[#FDFBF7]">Download PDF</button>
           <button onClick={exportCSV} className="bg-[#5C4D3C] text-white px-6 py-3 rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-xl hover:bg-black">Export CSV</button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
         <ReportStat label="Gross Revenue" value={`₹${stats.totalSales.toLocaleString()}`} icon="💹" color="bg-emerald-50 text-emerald-700" />
         <ReportStat label="Logistics Fees" value={`₹${stats.deliveryTotal.toLocaleString()}`} icon="🚚" color="bg-blue-50 text-blue-700" />
         <ReportStat label="Packaging Income" value={`₹${stats.packagingTotal.toLocaleString()}`} icon="📦" color="bg-amber-50 text-amber-700" />
         <ReportStat label="Total Retained" value={`₹${(stats.totalSales - stats.discountTotal).toLocaleString()}`} icon="💎" color="bg-indigo-50 text-indigo-700" />
      </div>

      <div className="grid lg:grid-cols-3 gap-10">
         <div className="lg:col-span-2 bg-white p-10 rounded-[40px] border border-[#EBE3D5] shadow-sm space-y-8">
            <h3 className="text-2xl font-serif font-bold text-[#5C4D3C]">Order Breakdown</h3>
            <div className="space-y-4">
               {orders.slice(0, 10).map(o => (
                  <div key={o.id} className="flex items-center justify-between py-4 border-b border-gray-50 last:border-0">
                     <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-gray-50 rounded-xl flex items-center justify-center text-xs font-bold text-[#5C4D3C]">#</div>
                        <div>
                           <p className="text-sm font-bold text-[#5C4D3C]">{o.userName}</p>
                           <p className="text-[10px] text-[#A68F7A] uppercase tracking-widest">{new Date(o.createdAt).toLocaleDateString()}</p>
                        </div>
                     </div>
                     <div className="text-right">
                        <p className="text-sm font-bold text-[#5C4D3C]">₹{o.total.toLocaleString()}</p>
                        <p className={`text-[9px] font-bold uppercase ${o.status === OrderStatus.DELIVERED ? 'text-green-600' : 'text-orange-600'}`}>{o.status}</p>
                     </div>
                  </div>
               ))}
            </div>
         </div>

         <div className="space-y-8">
            <div className="bg-white p-8 rounded-[40px] border border-[#EBE3D5] shadow-sm space-y-6">
               <h4 className="text-lg font-serif font-bold text-[#5C4D3C]">Marketing & Promo</h4>
               <div className="space-y-6">
                  <div className="p-6 bg-rose-50 border border-rose-100 rounded-3xl">
                     <p className="text-[10px] font-bold text-rose-700 uppercase tracking-widest">Discounts Applied</p>
                     <p className="text-3xl font-bold text-rose-800 mt-1">₹{stats.discountTotal.toLocaleString()}</p>
                     <p className="text-[10px] text-rose-600 mt-2 italic">Total promotional value shared with artisans.</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
      
      <style dangerouslySetInnerHTML={{ __html: `
        @media print {
          nav, aside, button { display: none !important; }
          .grid { display: block !important; }
          .bg-white { border: none !important; shadow: none !important; }
        }
      `}} />
    </div>
  );
};

const ReportStat: React.FC<{ label: string, value: string, icon: string, color: string }> = ({ label, value, icon, color }) => (
  <div className="bg-white p-8 rounded-[32px] border border-[#EBE3D5] shadow-sm space-y-4">
     <div className={`w-12 h-12 rounded-2xl ${color} flex items-center justify-center text-2xl`}>{icon}</div>
     <div>
        <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-[2px]">{label}</p>
        <p className="text-2xl font-serif font-bold text-[#5C4D3C] mt-1">{value}</p>
     </div>
  </div>
);

export default ReportManager;
