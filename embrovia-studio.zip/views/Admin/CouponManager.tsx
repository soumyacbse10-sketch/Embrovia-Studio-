
import React, { useState } from 'react';
import { Coupon, AdminSettings } from '../../types.ts';

interface CouponManagerProps {
  settings: AdminSettings;
  onUpdate: (s: Partial<AdminSettings>) => void;
}

const CouponManager: React.FC<CouponManagerProps> = ({ settings, onUpdate }) => {
  const [editingCoupon, setEditingCoupon] = useState<Partial<Coupon> | null>(null);

  const handleUpsert = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCoupon) return;

    const updatedCoupons = editingCoupon.id 
      ? settings.coupons.map(c => c.id === editingCoupon.id ? (editingCoupon as Coupon) : c)
      : [...settings.coupons, { ...editingCoupon, id: `cp-${Date.now()}` } as Coupon];

    onUpdate({ coupons: updatedCoupons });
    setEditingCoupon(null);
  };

  const deleteCoupon = (id: string) => {
    if (confirm("Delete this coupon code?")) {
      onUpdate({ coupons: settings.coupons.filter(c => c.id !== id) });
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-serif font-bold text-[#5C4D3C]">Studio Discounts</h1>
          <p className="text-[#A68F7A] mt-1">Manage promotional codes and special studio offers.</p>
        </div>
        <button 
          onClick={() => setEditingCoupon({ code: '', type: 'PERCENT', value: 0, minOrderAmount: 0, isEnabled: true, description: '' })}
          className="bg-[#5C4D3C] text-white px-6 py-3 rounded-full font-bold shadow-lg hover:bg-[#483C2F] transition-all"
        >
          + Create Coupon
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {settings.coupons.map(cp => (
          <div key={cp.id} className={`bg-white p-8 rounded-3xl border shadow-sm relative overflow-hidden transition-all ${cp.isEnabled ? 'border-[#EBE3D5]' : 'border-red-100 grayscale opacity-60'}`}>
            <div className="absolute top-0 right-0 p-4">
               <span className={`px-3 py-1 rounded-full text-[9px] font-bold uppercase tracking-widest ${cp.isEnabled ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
                 {cp.isEnabled ? 'Active' : 'Disabled'}
               </span>
            </div>
            
            <h3 className="text-2xl font-mono font-bold text-[#5C4D3C] mb-1">{cp.code}</h3>
            <p className="text-sm font-bold text-[#A68F7A] mb-4">
              {cp.type === 'PERCENT' ? `${cp.value}% Off` : `₹${cp.value} Flat Off`}
            </p>
            
            <div className="space-y-2 mb-6">
               <p className="text-[11px] text-[#7C6A58] italic leading-relaxed">"{cp.description}"</p>
               <div className="flex items-center gap-2 text-[10px] font-bold text-[#5C4D3C] uppercase tracking-widest bg-[#FDFBF7] p-2 rounded-lg border border-[#EBE3D5] w-fit">
                 <span>Min Order: ₹{cp.minOrderAmount}</span>
               </div>
            </div>

            <div className="flex gap-2 pt-6 border-t border-[#EBE3D5]">
               <button onClick={() => setEditingCoupon(cp)} className="flex-1 py-2 text-[10px] font-bold text-[#5C4D3C] bg-[#EBE3D5] rounded-xl hover:bg-[#D4C5B9]">Edit Policy</button>
               <button onClick={() => deleteCoupon(cp.id)} className="flex-1 py-2 text-[10px] font-bold text-red-600 bg-red-50 rounded-xl hover:bg-red-100">Retire Code</button>
            </div>
          </div>
        ))}
      </div>

      {editingCoupon && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden animate-in zoom-in">
            <div className="px-8 py-6 border-b border-[#EBE3D5] flex justify-between items-center bg-[#FDFBF7]">
              <h2 className="text-xl font-serif font-bold text-[#5C4D3C]">Coupon Configuration</h2>
              <button onClick={() => setEditingCoupon(null)} className="text-2xl text-[#A68F7A]">&times;</button>
            </div>
            <form onSubmit={handleUpsert} className="p-8 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase text-[#A68F7A]">Promo Code</label>
                  <input required value={editingCoupon.code} onChange={(e) => setEditingCoupon({...editingCoupon, code: e.target.value.toUpperCase()})} className="w-full px-4 py-2 border border-[#EBE3D5] rounded-xl font-mono text-sm" placeholder="SUMMER20" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase text-[#A68F7A]">Type</label>
                  <select value={editingCoupon.type} onChange={(e) => setEditingCoupon({...editingCoupon, type: e.target.value as any})} className="w-full px-4 py-2 border border-[#EBE3D5] rounded-xl text-sm outline-none">
                    <option value="PERCENT">Percentage (%)</option>
                    <option value="FLAT">Flat Amount (₹)</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase text-[#A68F7A]">Value</label>
                  <input type="number" required value={editingCoupon.value} onChange={(e) => setEditingCoupon({...editingCoupon, value: parseInt(e.target.value) || 0})} className="w-full px-4 py-2 border border-[#EBE3D5] rounded-xl text-sm" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase text-[#A68F7A]">Min Order (₹)</label>
                  <input type="number" required value={editingCoupon.minOrderAmount} onChange={(e) => setEditingCoupon({...editingCoupon, minOrderAmount: parseInt(e.target.value) || 0})} className="w-full px-4 py-2 border border-[#EBE3D5] rounded-xl text-sm" />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase text-[#A68F7A]">Description</label>
                <textarea value={editingCoupon.description} onChange={(e) => setEditingCoupon({...editingCoupon, description: e.target.value})} className="w-full px-4 py-2 border border-[#EBE3D5] rounded-xl text-sm" rows={2} placeholder="Get 10% off on masterpieces..." />
              </div>
              <div className="flex items-center gap-3 pt-2">
                 <button 
                  type="button"
                  onClick={() => setEditingCoupon({...editingCoupon, isEnabled: !editingCoupon.isEnabled})}
                  className={`w-12 h-6 rounded-full relative transition-all ${editingCoupon.isEnabled ? 'bg-[#5C4D3C]' : 'bg-gray-200'}`}
                 >
                   <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${editingCoupon.isEnabled ? 'right-1' : 'left-1'}`} />
                 </button>
                 <span className="text-[10px] font-bold uppercase tracking-widest text-[#7C6A58]">Activate Coupon</span>
              </div>
              <div className="pt-6 flex gap-3">
                <button type="button" onClick={() => setEditingCoupon(null)} className="flex-1 py-3 border border-[#EBE3D5] rounded-xl text-xs font-bold text-[#7C6A58]">Discard</button>
                <button type="submit" className="flex-1 py-3 bg-[#5C4D3C] text-white rounded-xl text-xs font-bold shadow-lg">Confirm Coupon</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default CouponManager;
