
import { Order, OrderStatus, ShippingDetails, AdminSettings, DocData, Package, OrderSnapshot, DispatchSlot, PaymentState, VerifiedPaymentDetails } from '../../types.ts';
import DocumentViewer from '../Shared/DocumentViewer.tsx';
import React, { useState } from 'react';
import { runAIRiskCheck } from '../../services/RiskService.ts';

interface OrderManagerProps {
  orders: Order[];
  adminSettings: AdminSettings;
  onUpdateStatus: (id: string, status: OrderStatus, shipping?: ShippingDetails) => void;
  onVerifyPayment: (id: string, verified: boolean) => void;
  onRejectPayment: (id: string, reason: string) => void;
  onTriggerEmail: (type: any, payload: any) => void;
  onUpdateSummary: (orderId: string, updates: Partial<Order>, log?: string) => void;
}

const OrderManager: React.FC<OrderManagerProps> = ({ orders, adminSettings, onUpdateStatus, onVerifyPayment, onRejectPayment, onUpdateSummary }) => {
  const [selectedDocMode, setSelectedDocMode] = useState<{ mode: 'INVOICE' | 'RECEIPT' | 'LABEL', order: Order } | null>(null);
  const [filter, setFilter] = useState<'ALL' | 'DRAFT' | 'PENDING_PAYMENT' | 'PAID' | 'SHIPPED'>('ALL');
  const [activeHistory, setActiveHistory] = useState<Order | null>(null);
  const [verifyingUPI, setVerifyingUPI] = useState<Order | null>(null);
  const [manualUPIFields, setManualUPIFields] = useState<Partial<VerifiedPaymentDetails>>({});
  const [rejectionReason, setRejectionReason] = useState('');

  const filteredOrders = orders.filter(o => {
    if (filter === 'DRAFT') return o.status === OrderStatus.DRAFT;
    if (filter === 'PENDING_PAYMENT') return o.status === OrderStatus.CUSTOMER_PAYMENT_PENDING;
    if (filter === 'PAID') return o.status === OrderStatus.CONFIRMED;
    if (filter === 'SHIPPED') return o.status === OrderStatus.SHIPPED;
    return true;
  });

  const confirmUPIPayment = () => {
    if (!verifyingUPI) return;
    const finalDetails: VerifiedPaymentDetails = {
      transactionId: manualUPIFields.transactionId || verifyingUPI.transactionId || 'MANUAL',
      amount: manualUPIFields.amount || verifyingUPI.total,
      date: manualUPIFields.date || new Date().toISOString(),
      payee: manualUPIFields.payee || 'Studio Account',
      confidence: 1.0, aiExtracted: false, adminLocked: true
    };
    onUpdateSummary(verifyingUPI.id, {
      paymentVerified: true, paymentState: PaymentState.VERIFIED, status: OrderStatus.CONFIRMED,
      transactionId: finalDetails.transactionId, verifiedPaymentDetails: finalDetails,
      checklist: { ...verifyingUPI.checklist, paymentVerified: true },
      rejectionReason: undefined
    }, `Admin verified UPI Payment. UTR: ${finalDetails.transactionId}`);
    setVerifyingUPI(null);
  };

  const rejectUPIPayment = () => {
    if (!verifyingUPI || !rejectionReason.trim()) {
      alert("Please provide a reason for rejection.");
      return;
    }
    onRejectPayment(verifyingUPI.id, rejectionReason);
    setVerifyingUPI(null);
    setRejectionReason('');
  };

  return (
    <div className="space-y-10 pb-20">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="text-4xl font-serif font-bold text-[#5C4D3C]">Artisan Command</h1>
          <p className="text-[#A68F7A] mt-1 italic">Enterprise control for handcrafted creations.</p>
        </div>
        <div className="flex bg-white p-1 rounded-2xl border border-[#EBE3D5] shadow-sm overflow-x-auto">
           {['ALL', 'DRAFT', 'PENDING_PAYMENT', 'PAID', 'SHIPPED'].map((f) => (
             <button 
                key={f} onClick={() => setFilter(f as any)}
                className={`px-4 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all whitespace-nowrap ${filter === f ? 'bg-[#5C4D3C] text-white shadow-md' : 'text-[#A68F7A] hover:bg-[#FDFBF7]'}`}
             >
                {f === 'PENDING_PAYMENT' ? 'AWAITING CUSTOMER' : f}
             </button>
           ))}
        </div>
      </div>

      <div className="space-y-8">
        {filteredOrders.map(order => (
          <div key={order.id} className="bg-white rounded-[40px] border border-[#EBE3D5] shadow-sm p-8 relative overflow-hidden group">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8 pb-8 border-b border-[#EBE3D5]">
              <div className="flex items-center gap-6">
                 <div className="w-14 h-14 bg-[#FDFBF7] border border-[#EBE3D5] rounded-2xl flex items-center justify-center font-bold text-[#5C4D3C]">#</div>
                 <div>
                   <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">ID: {order.id}</p>
                   <h3 className="text-2xl font-serif font-bold text-[#5C4D3C]">{order.userName}</h3>
                 </div>
              </div>
              <div className="text-right">
                <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Total</p>
                <p className="text-2xl font-bold text-[#5C4D3C]">₹{order.total.toLocaleString()}</p>
                <p className="text-[9px] font-bold uppercase text-indigo-600 mt-1">{order.status === OrderStatus.CUSTOMER_PAYMENT_PENDING ? 'AWAITING CUSTOMER PAYMENT' : order.status}</p>
              </div>
            </div>

            <div className="grid lg:grid-cols-4 gap-10">
              <div className="lg:col-span-1 bg-[#FDFBF7] p-6 rounded-3xl border border-[#EBE3D5] space-y-4">
                <h4 className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Payment Audit</h4>
                <div className="space-y-3">
                  <p className="text-xs text-[#7C6A58] font-bold uppercase">Method: <span className="text-[#5C4D3C]">{order.paymentMethod || 'N/A'}</span></p>
                  {order.paymentScreenshot && !order.paymentVerified && (
                    <button onClick={() => { setVerifyingUPI(order); setManualUPIFields(order.verifiedPaymentDetails || {}); }} className="w-full py-3 bg-amber-500 text-white rounded-xl text-[9px] font-bold uppercase tracking-widest shadow-lg hover:bg-amber-600 transition-all">
                      Verify Proof
                    </button>
                  )}
                  {order.paymentVerified && (
                    <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
                      <p className="text-[8px] font-bold text-emerald-700 uppercase">✓ Verified UTR</p>
                      <p className="text-xs font-mono font-bold text-emerald-900 mt-1">{order.transactionId}</p>
                    </div>
                  )}
                  {order.paymentState === PaymentState.REJECTED && (
                    <div className="p-4 bg-rose-50 rounded-2xl border border-rose-100">
                      <p className="text-[8px] font-bold text-rose-700 uppercase">⚠️ Proof Rejected</p>
                      <p className="text-xs font-medium text-rose-900 mt-1 italic">"{order.rejectionReason}"</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="lg:col-span-3 flex items-center justify-center p-4 bg-gray-50 border border-dashed border-gray-200 rounded-3xl">
                 {order.status === OrderStatus.DRAFT ? (
                   <button 
                     onClick={() => onUpdateStatus(order.id, OrderStatus.CUSTOMER_PAYMENT_PENDING)}
                     className="px-8 py-4 bg-[#5C4D3C] text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-lg hover:bg-black transition-all"
                   >
                     Push to Customer for Payment
                   </button>
                 ) : order.paymentVerified ? (
                   <div className="text-center space-y-2">
                      <p className="text-[10px] font-bold text-emerald-700 uppercase tracking-widest">✓ Order Authenticated</p>
                      <button onClick={() => setActiveHistory(order)} className="text-[9px] font-bold text-[#A68F7A] uppercase underline">Audit History</button>
                   </div>
                 ) : order.paymentState === PaymentState.REJECTED ? (
                   <div className="text-center">
                      <p className="text-[10px] font-bold text-rose-600 uppercase tracking-widest animate-pulse">⌛ Waiting for Re-submission</p>
                      <p className="text-[9px] text-gray-400 italic mt-1">Proof was rejected. Customer must re-upload.</p>
                   </div>
                 ) : (
                   <div className="text-center">
                      <p className="text-[10px] font-bold text-amber-600 uppercase tracking-widest animate-pulse">⌛ Customer Action Required</p>
                      <p className="text-[9px] text-gray-400 italic mt-1">Pricing Finalized. Awaiting Payment.</p>
                   </div>
                 )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {verifyingUPI && (
        <div className="fixed inset-0 z-[800] bg-[#5C4D3C]/95 backdrop-blur-2xl flex items-center justify-center p-6">
           <div className="bg-white w-full max-w-5xl rounded-[60px] shadow-2xl overflow-hidden flex flex-col md:flex-row">
              <div className="md:w-1/2 p-12 bg-gray-100 border-r border-[#EBE3D5] flex flex-col">
                 <h3 className="text-xl font-serif font-bold text-[#5C4D3C] mb-8">Customer Proof</h3>
                 <div className="flex-grow rounded-3xl overflow-hidden border border-[#EBE3D5] shadow-inner bg-black flex items-center justify-center">
                    {verifyingUPI.paymentScreenshot ? (
                      <img src={verifyingUPI.paymentScreenshot} alt="Proof" className="max-w-full max-h-full object-contain" />
                    ) : (
                      <div className="text-white text-xs font-bold uppercase opacity-40 italic">No Screenshot Found</div>
                    )}
                 </div>
              </div>
              <div className="md:w-1/2 p-12 space-y-8">
                 <div className="flex justify-between items-start">
                    <div>
                       <h2 className="text-3xl font-serif font-bold text-[#5C4D3C]">Transaction Audit</h2>
                       <p className="text-xs text-[#A68F7A] mt-1 italic">Verify amounts and references before handover.</p>
                    </div>
                    <button onClick={() => setVerifyingUPI(null)} className="text-4xl text-gray-300 hover:text-gray-500">&times;</button>
                 </div>
                 <div className="space-y-6">
                    <div className="space-y-1">
                       <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest px-2">Transaction ID / UTR</label>
                       <input value={manualUPIFields.transactionId || ''} onChange={e => setManualUPIFields({...manualUPIFields, transactionId: e.target.value})} className="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold outline-none" />
                    </div>
                    <div className="space-y-1">
                       <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest px-2">Amount Verified (₹)</label>
                       <input type="number" value={manualUPIFields.amount || ''} onChange={e => setManualUPIFields({...manualUPIFields, amount: parseFloat(e.target.value)})} className="w-full px-6 py-4 bg-gray-50 border border-gray-100 rounded-2xl text-sm font-bold outline-none" />
                    </div>
                    <div className="space-y-1 pt-4 border-t border-gray-100">
                       <label className="text-[10px] font-bold text-rose-400 uppercase tracking-widest px-2">Rejection Reason (if declining)</label>
                       <textarea 
                          value={rejectionReason} 
                          onChange={e => setRejectionReason(e.target.value)} 
                          placeholder="e.g. Transaction ID mismatch, amount incorrect, or screenshot blurry."
                          className="w-full px-6 py-4 bg-rose-50 border border-rose-100 rounded-2xl text-sm outline-none placeholder:text-rose-200" 
                          rows={3}
                       />
                    </div>
                 </div>
                 <div className="pt-8 border-t flex gap-4">
                    <button onClick={rejectUPIPayment} className="flex-1 py-5 bg-white border border-rose-200 text-rose-600 rounded-3xl text-[10px] font-bold uppercase tracking-widest shadow-sm hover:bg-rose-50">Reject Proof</button>
                    <button onClick={confirmUPIPayment} className="flex-1 py-5 bg-[#5C4D3C] text-white rounded-3xl text-[10px] font-bold uppercase tracking-widest shadow-2xl hover:bg-black">Confirm & Verify</button>
                 </div>
              </div>
           </div>
        </div>
      )}

      {activeHistory && (
        <div className="fixed inset-0 z-[600] bg-black/80 backdrop-blur-xl flex items-center justify-center p-6">
           <div className="bg-white w-full max-w-2xl rounded-[40px] shadow-2xl overflow-hidden animate-in slide-in-from-bottom-10">
              <div className="bg-[#5C4D3C] p-8 text-white flex justify-between items-center">
                 <h2 className="text-2xl font-serif font-bold">Audit History</h2>
                 <button onClick={() => setActiveHistory(null)} className="text-4xl opacity-50">&times;</button>
              </div>
              <div className="p-10 space-y-4 max-h-[70vh] overflow-y-auto">
                 {activeHistory.history?.map((snap, i) => (
                    <div key={i} className="flex gap-6 p-6 border border-[#EBE3D5] rounded-3xl">
                       <div className="w-10 h-10 bg-[#FDFBF7] rounded-xl flex items-center justify-center font-bold text-[#5C4D3C]">V{snap.version}</div>
                       <div>
                          <p className="text-[9px] font-bold text-[#A68F7A] uppercase">{new Date(snap.timestamp).toLocaleString()}</p>
                          <p className="text-sm font-bold text-[#5C4D3C] mt-1">{snap.changeLog}</p>
                       </div>
                    </div>
                 ))}
              </div>
           </div>
        </div>
      )}

      {selectedDocMode && (
        <DocumentViewer mode={selectedDocMode.mode} order={selectedDocMode.order} settings={adminSettings} onClose={() => setSelectedDocMode(null)} />
      )}
    </div>
  );
};

export default OrderManager;
