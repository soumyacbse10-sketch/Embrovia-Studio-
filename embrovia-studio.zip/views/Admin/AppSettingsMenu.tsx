
import React from 'react';
import { AdminSettings } from '../../types.ts';

interface AppSettingsMenuProps {
  settings: AdminSettings;
  onUpdate: (s: AdminSettings) => void;
}

const AppSettingsMenu: React.FC<AppSettingsMenuProps> = ({ settings, onUpdate }) => {
  const update = (field: keyof AdminSettings, value: string) => {
    onUpdate({ ...settings, [field]: value });
  };

  return (
    <div className="max-w-3xl space-y-8 animate-in fade-in slide-in-from-top-4 duration-500">
      <div className="space-y-1">
        <h1 className="text-3xl font-serif font-bold text-[#5C4D3C]">App Identity</h1>
        <p className="text-[#A68F7A] text-sm">Manage core business credentials and app settings.</p>
      </div>

      <div className="bg-white p-8 rounded-3xl border border-[#EBE3D5] shadow-sm space-y-8">
        <h3 className="font-serif font-bold text-lg text-[#5C4D3C]">Business Identification</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Brand Name</label>
            <input value={settings.businessName} onChange={(e) => update('businessName', e.target.value)} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm outline-none" />
          </div>
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Official Email</label>
            <input value={settings.businessEmail} onChange={(e) => update('businessEmail', e.target.value)} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm outline-none" />
          </div>
          <div className="space-y-1 md:col-span-2">
            <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Registered Studio Address</label>
            <textarea value={settings.businessAddress} onChange={(e) => update('businessAddress', e.target.value)} className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm outline-none" rows={3} />
          </div>
        </div>
      </div>

      <div className="bg-[#EBE3D5]/30 p-8 rounded-3xl border border-[#EBE3D5] flex flex-col items-center text-center space-y-4">
         <div className="w-16 h-16 bg-[#5C4D3C] rounded-full flex items-center justify-center text-white text-2xl font-serif font-bold">E</div>
         <div>
            <h4 className="font-serif font-bold text-[#5C4D3C]">Embrovia Artisanal OS</h4>
            <p className="text-[10px] text-[#A68F7A] uppercase tracking-[2px] mt-1 italic">Scalable Handmade Architecture</p>
         </div>
      </div>
    </div>
  );
};

export default AppSettingsMenu;
