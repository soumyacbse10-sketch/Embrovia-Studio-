
import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { AdminSettings, EmailType, EmailTemplate } from '../../types.ts';

interface EmailTemplateManagerProps {
  settings: AdminSettings;
  onUpdate: (s: AdminSettings) => void;
}

const TEMPLATE_TYPES: { type: EmailType; label: string; desc: string }[] = [
  { type: 'WELCOME_ACCOUNT', label: 'Welcome Account', desc: 'Sent when a new customer signs up.' },
  { type: 'SECURITY_LOGIN', label: 'Login Alert', desc: 'Sent on new login for security.' },
  { type: 'ORDER_CONFIRMED', label: 'Order Confirmation', desc: 'Sent when an order is placed/confirmed.' },
  { type: 'ORDER_SHIPPED', label: 'Shipping Update', desc: 'Sent when tracking details are added.' },
  { type: 'PAYMENT_RECEIPT', label: 'Payment Receipt', desc: 'Sent after payment is verified.' },
];

const PLACEHOLDERS = [
  '{{customer_name}}', '{{order_id}}', '{{order_total}}', 
  '{{product_name}}', '{{payment_method}}', '{{tracking_number}}', 
  '{{courier_name}}', '{{business_name}}'
];

const EmailTemplateManager: React.FC<EmailTemplateManagerProps> = ({ settings, onUpdate }) => {
  const [activeType, setActiveType] = useState<EmailType>('ORDER_CONFIRMED');
  const [isEnhancing, setIsEnhancing] = useState(false);

  const currentTemplate = settings.emailTemplates[activeType];

  const handleUpdateTemplate = (field: keyof EmailTemplate, value: any) => {
    const updatedTemplates = {
      ...settings.emailTemplates,
      [activeType]: { ...currentTemplate, [field]: value }
    };
    onUpdate({ ...settings, emailTemplates: updatedTemplates });
  };

  const handleAIEnhance = async () => {
    if (isEnhancing) return;
    setIsEnhancing(true);
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const systemInstruction = `
        You are a high-end luxury brand communications specialist for "Embrovia Studio".
        Your task is to rewrite a given email template to sound more professional, sophisticated, and artisanal.
        
        CRITICAL RULES:
        1. PRESERVE ALL {{placeholders}} EXACTLY. Do not change their names or remove them.
        2. Use a warm, grateful, and elegant tone inspired by traditional hand-embroidery crafts.
        3. Keep the output as PLAIN TEXT.
        4. Do not include subject lines, only the body.
        
        Available Placeholders: ${PLACEHOLDERS.join(', ')}
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Please enhance this email template body while keeping placeholders intact: \n\n ${currentTemplate.body}`,
        config: { systemInstruction, temperature: 0.8 }
      });

      const enhancedBody = response.text || currentTemplate.body;
      handleUpdateTemplate('body', enhancedBody);
    } catch (error) {
      console.error("AI Enhancement failed:", error);
      alert("Failed to connect to AI service. Please try again later.");
    } finally {
      setIsEnhancing(false);
    }
  };

  const insertPlaceholder = (placeholder: string) => {
    const textarea = document.getElementById('template-body') as HTMLTextAreaElement;
    if (textarea) {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const text = textarea.value;
      const before = text.substring(0, start);
      const after = text.substring(end);
      handleUpdateTemplate('body', before + placeholder + after);
    }
  };

  return (
    <div className="space-y-10">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-serif font-bold text-[#5C4D3C]">Communication Hub</h1>
          <p className="text-[#A68F7A] mt-1">Control artisanal email templates and automated messaging.</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1 space-y-2">
          {TEMPLATE_TYPES.map(t => (
            <button
              key={t.type}
              onClick={() => setActiveType(t.type)}
              className={`w-full text-left p-4 rounded-2xl border transition-all ${
                activeType === t.type 
                  ? 'bg-[#5C4D3C] text-white border-[#5C4D3C] shadow-lg' 
                  : 'bg-white text-[#7C6A58] border-[#EBE3D5] hover:border-[#A68F7A]'
              }`}
            >
              <p className="text-xs font-bold uppercase tracking-widest opacity-80 mb-1">{t.type.replace('_', ' ')}</p>
              <p className="text-sm font-bold">{t.label}</p>
            </button>
          ))}
        </div>

        <div className="lg:col-span-3 space-y-6">
          <div className="bg-white p-8 rounded-3xl border border-[#EBE3D5] shadow-sm space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-serif font-bold text-[#5C4D3C]">Edit {TEMPLATE_TYPES.find(t => t.type === activeType)?.label}</h3>
                <p className="text-xs text-[#A68F7A]">{TEMPLATE_TYPES.find(t => t.type === activeType)?.desc}</p>
              </div>
              <div className="flex items-center gap-4">
                <button 
                  onClick={handleAIEnhance}
                  disabled={isEnhancing}
                  className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-md hover:bg-indigo-700 disabled:opacity-50 transition-all flex items-center gap-2"
                >
                  {isEnhancing ? '✨ Enhancing...' : '✨ Enhance with AI'}
                </button>
                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold text-[#7C6A58] uppercase">Status</span>
                  <button 
                    onClick={() => handleUpdateTemplate('isEnabled', !currentTemplate.isEnabled)}
                    className={`w-12 h-6 rounded-full transition-all relative ${currentTemplate.isEnabled ? 'bg-[#5C4D3C]' : 'bg-gray-300'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${currentTemplate.isEnabled ? 'right-1' : 'left-1'}`} />
                  </button>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest mb-1 block">Email Subject</label>
                <input 
                  type="text"
                  value={currentTemplate.subject}
                  onChange={(e) => handleUpdateTemplate('subject', e.target.value)}
                  placeholder="e.g. Your order from {{business_name}} is confirmed!"
                  className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm outline-none focus:ring-1 focus:ring-[#A68F7A]"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Email Body (Plain Text)</label>
                  <p className="text-[10px] text-[#A68F7A] italic">Click placeholders to insert</p>
                </div>
                <div className="flex flex-wrap gap-2 mb-3">
                  {PLACEHOLDERS.map(p => (
                    <button 
                      key={p} 
                      onClick={() => insertPlaceholder(p)}
                      className="px-2 py-1 bg-[#EBE3D5] text-[#5C4D3C] text-[10px] font-bold rounded-lg hover:bg-[#D4C5B9]"
                    >
                      {p}
                    </button>
                  ))}
                </div>
                <textarea 
                  id="template-body"
                  rows={12}
                  value={currentTemplate.body}
                  onChange={(e) => handleUpdateTemplate('body', e.target.value)}
                  className="w-full px-4 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl text-sm outline-none focus:ring-1 focus:ring-[#A68F7A] font-mono leading-relaxed"
                />
              </div>
            </div>
          </div>

          <div className="bg-[#EBE3D5]/30 p-6 rounded-2xl border border-[#EBE3D5]">
            <h4 className="text-xs font-bold text-[#5C4D3C] uppercase mb-2">Live Preview Simulation</h4>
            <div className="bg-white p-6 rounded-xl border border-[#EBE3D5] shadow-inner text-sm space-y-2 italic">
              <p className="font-bold border-b pb-2 mb-4">Subject: {currentTemplate.subject.replace('{{business_name}}', settings.businessName)}</p>
              <div className="whitespace-pre-wrap leading-relaxed text-[#7C6A58]">
                {currentTemplate.body
                  .replace('{{customer_name}}', 'Anjali Sharma')
                  .replace('{{order_id}}', 'ORD-12345')
                  .replace('{{order_total}}', '₹1,250')
                  .replace('{{business_name}}', settings.businessName)}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmailTemplateManager;
