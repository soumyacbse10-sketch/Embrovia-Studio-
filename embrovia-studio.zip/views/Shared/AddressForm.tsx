
import React, { useState, useEffect } from 'react';
import { Address } from '../../types.ts';

interface AddressFormProps {
  initialAddress?: Address;
  onSave: (addr: Address) => void;
  onCancel: () => void;
}

const AddressForm: React.FC<AddressFormProps> = ({ initialAddress, onSave, onCancel }) => {
  const [formData, setFormData] = useState<Omit<Address, 'id'>>(initialAddress ? {
    fullName: initialAddress.fullName,
    phone: initialAddress.phone,
    houseFlat: initialAddress.houseFlat,
    streetArea: initialAddress.streetArea,
    landmark: initialAddress.landmark,
    city: initialAddress.city,
    state: initialAddress.state,
    pinCode: initialAddress.pinCode,
    label: initialAddress.label,
    lat: initialAddress.lat,
    lng: initialAddress.lng,
  } : {
    fullName: '',
    phone: '',
    houseFlat: '',
    streetArea: '',
    landmark: '',
    city: '',
    state: '',
    pinCode: '',
    label: 'Home',
    lat: undefined,
    lng: undefined,
  });

  const [showMap, setShowMap] = useState(false);
  const [mapCoords, setMapCoords] = useState<{lat: number, lng: number}>({lat: 20.5937, lng: 78.9629}); // Center of India

  useEffect(() => {
    if (showMap && navigator.geolocation) {
       navigator.geolocation.getCurrentPosition((pos) => {
         setMapCoords({lat: pos.coords.latitude, lng: pos.coords.longitude});
       });
    }
  }, [showMap]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...formData,
      id: initialAddress?.id || `addr-${Date.now()}`
    });
  };

  const pickLocation = () => {
    setFormData({ ...formData, lat: mapCoords.lat, lng: mapCoords.lng });
    setShowMap(false);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300">
        <div className="px-8 py-6 border-b border-[#EBE3D5] flex justify-between items-center bg-[#FDFBF7]">
          <h2 className="text-2xl font-serif font-bold text-[#5C4D3C]">Delivery Details</h2>
          <button onClick={onCancel} className="text-2xl text-[#A68F7A]">&times;</button>
        </div>

        {!showMap ? (
          <form onSubmit={handleSubmit} className="p-8 space-y-6 max-h-[70vh] overflow-y-auto">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-widest text-[#A68F7A]">Full Name</label>
                <input required value={formData.fullName} onChange={(e) => setFormData({...formData, fullName: e.target.value})} className="w-full px-4 py-2 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl outline-none" />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-widest text-[#A68F7A]">Mobile Number</label>
                <input required value={formData.phone} onChange={(e) => setFormData({...formData, phone: e.target.value})} className="w-full px-4 py-2 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl outline-none" />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-widest text-[#A68F7A]">House / Flat / Building</label>
              <input required value={formData.houseFlat} onChange={(e) => setFormData({...formData, houseFlat: e.target.value})} className="w-full px-4 py-2 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl outline-none" />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold uppercase tracking-widest text-[#A68F7A]">Street / Area</label>
              <input required value={formData.streetArea} onChange={(e) => setFormData({...formData, streetArea: e.target.value})} className="w-full px-4 py-2 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl outline-none" />
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-widest text-[#A68F7A]">City</label>
                <input required value={formData.city} onChange={(e) => setFormData({...formData, city: e.target.value})} className="w-full px-4 py-2 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl outline-none" />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-widest text-[#A68F7A]">State</label>
                <input required value={formData.state} onChange={(e) => setFormData({...formData, state: e.target.value})} className="w-full px-4 py-2 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl outline-none" />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-widest text-[#A68F7A]">PIN Code</label>
                <input required value={formData.pinCode} onChange={(e) => setFormData({...formData, pinCode: e.target.value})} className="w-full px-4 py-2 bg-[#FDFBF7] border border-[#EBE3D5] rounded-xl outline-none" />
              </div>
            </div>

            <div className="flex flex-wrap gap-4 items-end">
              <div className="space-y-1 flex-grow">
                <label className="text-[10px] font-bold uppercase tracking-widest text-[#A68F7A]">Address Label</label>
                <div className="flex gap-2">
                  {['Home', 'Work', 'Other'].map(l => (
                    <button 
                      key={l} type="button" 
                      onClick={() => setFormData({...formData, label: l as any})}
                      className={`px-4 py-2 rounded-full text-xs font-bold border ${formData.label === l ? 'bg-[#5C4D3C] text-white' : 'bg-white border-[#EBE3D5] text-[#7C6A58]'}`}
                    >
                      {l}
                    </button>
                  ))}
                </div>
              </div>
              <button 
                type="button" 
                onClick={() => setShowMap(true)}
                className="px-6 py-2 bg-[#EBE3D5] text-[#5C4D3C] rounded-full text-xs font-bold hover:bg-[#D4C5B9] flex items-center gap-2"
              >
                📍 {formData.lat ? 'Location Pinned' : 'Pin Exact Location'}
              </button>
            </div>

            <div className="pt-6 flex gap-4">
              <button type="button" onClick={onCancel} className="flex-1 py-3 border border-[#EBE3D5] rounded-xl font-bold text-[#7C6A58]">Cancel</button>
              <button type="submit" className="flex-1 py-3 bg-[#5C4D3C] text-white rounded-xl font-bold shadow-lg">Save Delivery Info</button>
            </div>
          </form>
        ) : (
          <div className="p-8 space-y-6">
            <div className="aspect-video bg-[#FDFBF7] border border-[#EBE3D5] rounded-2xl relative overflow-hidden flex items-center justify-center">
               <div className="absolute inset-0 bg-[url('https://maps.googleapis.com/maps/api/staticmap?center=20.5937,78.9629&zoom=4&size=600x300&key=MOCK_KEY')] bg-cover opacity-30"></div>
               <div className="relative text-center space-y-4 px-10">
                  <div className="text-4xl">🗺️</div>
                  <h3 className="text-lg font-serif font-bold text-[#5C4D3C]">Interactive Map Picker</h3>
                  <p className="text-xs text-[#7C6A58]">Simulated Map View. In a production app, we would load Leaflet or Google Maps here.</p>
                  <div className="p-4 bg-white border border-[#EBE3D5] rounded-xl shadow-sm text-xs font-mono text-[#A68F7A]">
                    LAT: {mapCoords.lat.toFixed(4)} <br/>
                    LNG: {mapCoords.lng.toFixed(4)}
                  </div>
                  <p className="text-[10px] text-[#A68F7A] italic">Drag the map or use GPS to pin your doorstep for perfect delivery.</p>
               </div>
               <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-full text-3xl drop-shadow-lg">📍</div>
            </div>
            <div className="flex gap-4">
              <button type="button" onClick={() => setShowMap(false)} className="flex-1 py-3 border border-[#EBE3D5] rounded-xl font-bold text-[#7C6A58]">Back</button>
              <button type="button" onClick={pickLocation} className="flex-1 py-3 bg-[#5C4D3C] text-white rounded-xl font-bold shadow-lg">Confirm Pin Location</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AddressForm;
