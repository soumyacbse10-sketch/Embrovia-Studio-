
import React from 'react';
import { Order, OrderStatus, AdminSettings, DocumentTheme, DocData } from '../../types.ts';

interface DocumentViewerProps {
  mode: 'INVOICE' | 'RECEIPT' | 'LABEL';
  order: Order;
  settings: AdminSettings;
  onClose: () => void;
}

const DocumentViewer: React.FC<DocumentViewerProps> = ({ mode, order, settings, onClose }) => {
  const isInvoice = mode === 'INVOICE';
  const isReceipt = mode === 'RECEIPT';
  const isLabel = mode === 'LABEL';

  // ENFORCEMENT: FAIL-SAFE RULE - Check if paid before viewing sensitive financial docs
  const isDraftState = !order.paymentVerified;
  const accessDenied = (isInvoice || isReceipt) && isDraftState;

  if (accessDenied) {
    return (
      <div className="fixed inset-0 bg-black/95 z-[500] flex items-center justify-center p-6 backdrop-blur-xl animate-in fade-in duration-500">
        <div className="bg-white p-12 rounded-[60px] text-center max-w-sm space-y-8 shadow-2xl">
          <div className="w-24 h-24 bg-rose-50 rounded-full flex items-center justify-center mx-auto">
            <span className="text-5xl">🔒</span>
          </div>
          <div className="space-y-2">
            <h3 className="text-2xl font-serif font-bold text-[#5C4D3C]">Verification Sealed</h3>
            <p className="text-sm text-[#7C6A58] italic leading-relaxed">This document is blocked. A verified Transaction ID / UTR must be present in our studio ledger before this record can be generated.</p>
          </div>
          <button onClick={onClose} className="w-full py-4 bg-[#5C4D3C] text-white rounded-3xl font-bold uppercase text-[10px] tracking-widest shadow-xl hover:bg-black transition-all">Return to Studio</button>
        </div>
      </div>
    );
  }

  const theme = isInvoice ? settings.invoiceTheme : isReceipt ? settings.receiptTheme : settings.labelTheme;
  const data = isInvoice ? order.invoiceData : isReceipt ? order.receiptData : order.labelData;

  const docTitle = data?.title || (isInvoice ? 'Tax Invoice' : isReceipt ? 'Payment Receipt' : 'Delivery Label');
  const docRef = `${isInvoice ? 'INV' : isReceipt ? 'RCP' : 'LBL'}-${order.id.slice(-6).toUpperCase()}`;
  
  const getFontFamily = () => {
    if (theme.fontFamily === 'serif') return 'font-serif';
    if (theme.fontFamily === 'mono') return 'font-mono';
    return 'font-sans';
  };

  return (
    <div className="fixed inset-0 bg-black/90 z-[300] flex items-center justify-center p-4 overflow-y-auto print:p-0 print:bg-white animate-in fade-in duration-300">
      <div className={`print-container bg-white shadow-2xl relative print:shadow-none overflow-hidden ${getFontFamily()}`}>
        
        <div className="h-4 w-full" style={{ backgroundColor: theme.primaryColor }}></div>

        <div className="fixed top-8 right-8 flex gap-4 print:hidden z-50">
          <button onClick={() => window.print()} className="bg-emerald-600 text-white px-8 py-4 rounded-2xl text-xs font-bold uppercase shadow-2xl hover:scale-105 active:scale-95 transition-all">🖨️ Print Document</button>
          <button onClick={onClose} className="bg-white/10 backdrop-blur-md text-white w-14 h-14 rounded-full flex items-center justify-center text-2xl hover:bg-white/20 transition-all shadow-xl">&times;</button>
        </div>

        <div className={`a4-content p-16 print:p-12 space-y-12 relative z-10 ${theme.layout === 'boxed' ? 'border-[20px] border-gray-50' : ''}`}>
          
          {/* Header */}
          <div className={`flex flex-col gap-6 border-b border-gray-100 pb-12 ${theme.headerAlignment === 'center' ? 'items-center text-center' : theme.headerAlignment === 'right' ? 'items-end text-right' : ''}`}>
            {settings.businessLogo && !isLabel && (
              <img src={settings.businessLogo} alt="Logo" className="w-24 h-24 object-contain" />
            )}
            <div>
              <h1 className="text-4xl font-bold tracking-tight" style={{ color: theme.primaryColor }}>{settings.businessName}</h1>
              <p className="text-[10px] text-gray-400 uppercase tracking-[4px] font-bold mt-2">{docTitle}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-12">
            <div className="space-y-6">
              <div>
                <h4 className="text-[9px] font-bold uppercase tracking-widest text-gray-400 mb-2">Recipient</h4>
                <p className="text-xl font-bold text-gray-900">{data?.nameOverride || order.deliveryAddress.fullName || order.userName}</p>
                <div className="text-xs text-gray-500 leading-relaxed mt-2 whitespace-pre-line">
                  {data?.addressOverride || `${order.deliveryAddress.houseFlat}, ${order.deliveryAddress.streetArea}`}
                  <br />{order.deliveryAddress.city}, {order.deliveryAddress.state} - {order.deliveryAddress.pinCode}
                  <br /><span className="font-bold text-gray-800">Phone: {data?.phoneOverride || order.deliveryAddress.phone}</span>
                </div>
              </div>
            </div>
            <div className="text-right space-y-4">
              <div className="text-xs">
                <p className="text-gray-400 font-bold uppercase text-[9px] tracking-widest">Doc Reference</p>
                <p className="font-bold text-lg">{docRef}</p>
              </div>
              <div className="text-xs">
                <p className="text-gray-400 font-bold uppercase text-[9px] tracking-widest">Transaction Verified Date</p>
                <p className="text-gray-600">{new Date(order.verifiedPaymentDetails?.date || order.createdAt).toLocaleDateString(undefined, { dateStyle: 'long' })}</p>
              </div>
              <div className="inline-block px-4 py-2 bg-emerald-50 border border-emerald-100 rounded-xl">
                 <p className="text-[8px] font-bold text-emerald-700 uppercase tracking-[2px]">Status</p>
                 <p className="text-xs font-bold text-emerald-800">FULLY PAID</p>
              </div>
            </div>
          </div>

          {!isLabel ? (
            <div className="pt-4">
              <table className="w-full text-left font-sans border-collapse">
                <thead>
                  <tr className="border-b-2" style={{ borderColor: theme.primaryColor }}>
                    <th className="py-6 text-[10px] font-bold uppercase tracking-widest">Artisan Description</th>
                    <th className="py-6 text-center text-[10px] font-bold uppercase tracking-widest">Qty</th>
                    {isInvoice && <th className="py-6 text-right text-[10px] font-bold uppercase tracking-widest">Amount</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {order.items.map((item, idx) => (
                    <tr key={idx}>
                      <td className="py-8 font-bold text-gray-900">{item.name}</td>
                      <td className="py-8 text-center text-gray-700">{item.quantity}</td>
                      {isInvoice && <td className="py-8 text-right font-bold text-gray-900">₹{(item.price * item.quantity).toLocaleString()}</td>}
                    </tr>
                  ))}
                </tbody>
                {isInvoice && (
                  <tfoot>
                    <tr className="border-t-2" style={{ borderColor: theme.primaryColor }}>
                      <td colSpan={1}></td>
                      <td className="py-8 text-right text-gray-900 uppercase text-xs font-bold">Total Settled</td>
                      <td className="py-8 text-right text-3xl font-bold" style={{ color: theme.primaryColor }}>₹{order.total.toLocaleString()}</td>
                    </tr>
                  </tfoot>
                )}
              </table>
              
              {/* UPI INTEGRATION BLOCK */}
              <div className="mt-12 p-8 bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                   <div className="space-y-1">
                      <p className="text-[8px] font-bold text-gray-400 uppercase tracking-widest">Payment Method</p>
                      <p className="text-xs font-bold text-gray-800">{order.paymentMethod}</p>
                   </div>
                   <div className="space-y-1">
                      <p className="text-[8px] font-bold text-gray-400 uppercase tracking-widest">Transaction / UTR ID</p>
                      <p className="text-xs font-mono font-bold text-gray-800">{order.transactionId || 'STUDIO-CONFIRMED'}</p>
                   </div>
                   <div className="space-y-1">
                      <p className="text-[8px] font-bold text-gray-400 uppercase tracking-widest">Verified Amount</p>
                      <p className="text-xs font-bold text-gray-800">₹{order.verifiedPaymentDetails?.amount?.toLocaleString() || order.total.toLocaleString()}</p>
                   </div>
                   <div className="space-y-1">
                      <p className="text-[8px] font-bold text-gray-400 uppercase tracking-widest">Audit Status</p>
                      <p className="text-xs font-bold text-emerald-600 uppercase">Confirmed Success</p>
                   </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="pt-20 border-t border-gray-100 flex flex-col items-center gap-10">
              <div className="w-full grid grid-cols-2 gap-10">
                 <div className="p-8 bg-gray-50 rounded-[40px] flex flex-col items-center justify-center">
                    <div className="w-48 h-12 bg-black flex items-center justify-center text-white font-mono text-xs tracking-[10px]">BARCODE</div>
                    <p className="text-[8px] font-bold uppercase mt-2">{order.id}</p>
                 </div>
                 <div className="p-8 border-4 border-black rounded-[40px] text-center flex flex-col justify-center">
                    <p className="text-[10px] font-bold uppercase text-gray-400">Shipment Status</p>
                    <p className="text-3xl font-bold uppercase">PREPAID VERIFIED</p>
                 </div>
              </div>
            </div>
          )}

          <div className="pt-20">
            <h5 className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-3">Artisan Certification Note</h5>
            <p className="text-xs text-gray-500 italic leading-relaxed">"{data?.note || 'This record confirms a successful artisanal commission settlement.'}"</p>
          </div>
        </div>

        <style dangerouslySetInnerHTML={{ __html: `
          .print-container { width: 210mm; min-height: 297mm; background: white; }
          @media print {
            @page { size: A4; margin: 0; }
            body { background: white; }
            .print-container { width: 100%; height: 100%; position: absolute; left: 0; top: 0; }
            body * { visibility: hidden !important; }
            .print-container, .print-container * { visibility: visible !important; }
          }
        `}} />
      </div>
    </div>
  );
};

export default DocumentViewer;
