
import React from 'react';
import { AdminSettings } from '../../types.ts';

interface SupportContactProps {
  settings: AdminSettings;
  title?: string;
  subtitle?: string;
  layout?: 'horizontal' | 'vertical';
  compact?: boolean;
}

const SupportContact: React.FC<SupportContactProps> = ({ 
  settings, 
  title = "Need Help?", 
  subtitle = "Contact our artisans for any assistance.",
  layout = 'horizontal',
  compact = false
}) => {
  const hasAtLeastOne = settings.supportPhoneEnabled || settings.supportWhatsAppEnabled || settings.supportEmailEnabled;

  if (!hasAtLeastOne) return null;

  const handleCall = () => {
    window.open(`tel:${settings.supportPhone}`, '_self');
  };

  const handleWhatsApp = () => {
    const message = encodeURIComponent("Hello Embrovia Studio, I need help with my order.");
    window.open(`https://wa.me/${settings.supportWhatsApp.replace(/\s+/g, '')}?text=${message}`, '_blank');
  };

  const handleEmail = () => {
    window.open(`mailto:${settings.supportEmail}`, '_self');
  };

  return (
    <div className={`bg-white rounded-3xl border border-[#EBE3D5] shadow-sm p-6 ${compact ? 'p-4' : 'p-8'} space-y-6`}>
      {!compact && (
        <div className="text-center md:text-left">
          <h3 className="text-xl font-serif font-bold text-[#5C4D3C]">{title}</h3>
          <p className="text-sm text-[#7C6A58] mt-1 italic">{subtitle}</p>
        </div>
      )}

      <div className={`flex flex-wrap gap-4 ${layout === 'vertical' ? 'flex-col' : 'justify-center md:justify-start'}`}>
        {settings.supportPhoneEnabled && (
          <button 
            onClick={handleCall}
            className={`flex items-center gap-3 px-6 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-2xl hover:border-[#A68F7A] transition-all group ${layout === 'vertical' ? 'w-full' : ''}`}
          >
            <span className="text-lg group-hover:scale-110 transition-transform">📞</span>
            <div className="text-left">
              <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Call Us</p>
              <p className="text-sm font-bold text-[#5C4D3C]">{settings.supportPhone}</p>
            </div>
          </button>
        )}

        {settings.supportWhatsAppEnabled && (
          <button 
            onClick={handleWhatsApp}
            className={`flex items-center gap-3 px-6 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-2xl hover:border-[#A68F7A] transition-all group ${layout === 'vertical' ? 'w-full' : ''}`}
          >
            <span className="text-lg group-hover:scale-110 transition-transform">💬</span>
            <div className="text-left">
              <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">WhatsApp</p>
              <p className="text-sm font-bold text-[#5C4D3C]">{settings.supportWhatsApp}</p>
            </div>
          </button>
        )}

        {settings.supportEmailEnabled && (
          <button 
            onClick={handleEmail}
            className={`flex items-center gap-3 px-6 py-3 bg-[#FDFBF7] border border-[#EBE3D5] rounded-2xl hover:border-[#A68F7A] transition-all group ${layout === 'vertical' ? 'w-full' : ''}`}
          >
            <span className="text-lg group-hover:scale-110 transition-transform">✉️</span>
            <div className="text-left">
              <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Email Support</p>
              <p className="text-sm font-bold text-[#5C4D3C]">{settings.supportEmail}</p>
            </div>
          </button>
        )}
      </div>
    </div>
  );
};

export default SupportContact;
