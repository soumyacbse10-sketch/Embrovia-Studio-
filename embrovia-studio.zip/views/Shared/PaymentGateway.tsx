
import React, { useState } from 'react';
import { PaymentMethod, AdminSettings, PaymentState, Order } from '../../types.ts';
import { extractUPIDetails } from '../../services/OCRService.ts';

interface PaymentGatewayProps {
  order: Order;
  settings: AdminSettings;
  onConfirm: (method: PaymentMethod, screenshot?: string, transactionId?: string, aiDetails?: any) => void;
  onCancel?: () => void;
}

const PaymentGateway: React.FC<PaymentGatewayProps> = ({ order, settings, onConfirm, onCancel }) => {
  const [method, setMethod] = useState<PaymentMethod | null>(null);
  const [pState, setPState] = useState<PaymentState>(PaymentState.NOT_SELECTED);
  const [screenshot, setScreenshot] = useState<string | null>(null);
  const [isAiProcessing, setIsAiProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleScreenshotUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      const reader = new FileReader();
      reader.onload = async (ev) => {
        const base64 = ev.target?.result as string;
        setScreenshot(base64);
        setIsAiProcessing(true);
        // Instant background extraction
        const aiDetails = await extractUPIDetails(base64);
        setIsAiProcessing(false);
        if (aiDetails) {
            console.debug("AI Extracted:", aiDetails);
        }
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const initiatePayment = async () => {
    if (!method) return;
    
    if (method === PaymentMethod.QR_CODE && !screenshot) {
      setError("Please attach the transaction screenshot for verification.");
      return;
    }

    setError(null);
    setPState(PaymentState.IN_PROGRESS);

    // Simulate Payment Redirect/Processing
    setTimeout(async () => {
      if (method === PaymentMethod.RAZORPAY) {
        // Mock Razorpay Success
        const mockTxn = `pay_rzp_${Math.random().toString(36).slice(2, 10).toUpperCase()}`;
        onConfirm(method, undefined, mockTxn);
      } else if (method === PaymentMethod.QR_CODE) {
        // Manual verification path
        const aiDetails = screenshot ? await extractUPIDetails(screenshot) : null;
        onConfirm(method, screenshot || undefined, aiDetails?.transactionId, aiDetails);
      } else {
        // COD path
        onConfirm(method);
      }
    }, 2000);
  };

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="bg-[#FDFBF7] p-8 rounded-[40px] border border-[#EBE3D5] flex flex-col items-center justify-center space-y-2">
        <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-[3px]">Amount to Pay</p>
        <p className="text-5xl font-serif font-bold text-[#5C4D3C]">₹{order.total.toLocaleString()}</p>
      </div>

      <div className="space-y-4">
        <label className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest px-2">Select Artisan Payment Route</label>
        
        <div className="grid grid-cols-1 gap-4">
          {settings.razorpayConfig.isEnabled && (
            <PaymentOption 
              active={method === PaymentMethod.RAZORPAY}
              onClick={() => setMethod(PaymentMethod.RAZORPAY)}
              title="Razorpay Secure"
              desc="Instant UPI, Cards & Net Banking"
              icon="🛡️"
            />
          )}

          {settings.qrEnabled && (
            <div className="space-y-4">
              <PaymentOption 
                active={method === PaymentMethod.QR_CODE}
                onClick={() => setMethod(PaymentMethod.QR_CODE)}
                title="Manual QR Scan & Pay"
                desc="Direct Bank Settlement (Screenshot Required)"
                icon="📱"
              />
              
              {method === PaymentMethod.QR_CODE && (
                <div className="p-8 bg-[#FDFBF7] border-2 border-dashed border-[#EBE3D5] rounded-[40px] space-y-6 animate-in zoom-in duration-300">
                  <div className="flex flex-col md:flex-row gap-8 items-center">
                    <div className="w-40 h-40 bg-white p-2 rounded-2xl shadow-xl relative group">
                      <img src={settings.qrCodeImage} alt="Payment QR" className="w-full h-full object-contain" />
                      <div className="absolute inset-0 bg-[#5C4D3C]/5 animate-pulse rounded-2xl"></div>
                    </div>
                    <div className="flex-grow space-y-4">
                      <p className="text-xs text-[#7C6A58] leading-relaxed italic">{settings.qrInstructions}</p>
                      <div className="space-y-2">
                        <label className="block w-full">
                          <div className={`w-full py-4 border-2 border-dashed rounded-2xl flex items-center justify-center gap-3 cursor-pointer transition-all ${screenshot ? 'bg-emerald-50 border-emerald-200' : 'bg-white border-[#EBE3D5] hover:border-[#A68F7A]'}`}>
                            <span className="text-lg">{screenshot ? '✓' : '📸'}</span>
                            <span className="text-[10px] font-bold uppercase tracking-widest text-[#5C4D3C]">
                              {screenshot ? 'Screenshot Attached' : 'Attach Payment Proof'}
                            </span>
                            <input type="file" className="hidden" accept="image/*" onChange={handleScreenshotUpload} />
                          </div>
                        </label>
                        {isAiProcessing && (
                          <div className="flex items-center gap-2 px-4 animate-pulse">
                            <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full"></div>
                            <span className="text-[9px] font-bold text-indigo-600 uppercase">AI Reading UTR...</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          <PaymentOption 
            active={method === PaymentMethod.COD}
            onClick={() => setMethod(PaymentMethod.COD)}
            title="Cash on Delivery"
            desc="Pay only when piece arrives"
            icon="🚚"
          />
        </div>
      </div>

      {error && (
        <div className="p-5 bg-rose-50 border border-rose-100 rounded-3xl flex items-center gap-4 text-rose-700 animate-shake">
          <span className="text-xl">⚠️</span>
          <p className="text-[10px] font-bold uppercase">{error}</p>
        </div>
      )}

      <div className="space-y-4">
        <button 
          onClick={initiatePayment}
          disabled={!method || pState === PaymentState.IN_PROGRESS}
          className={`w-full py-6 rounded-3xl font-bold shadow-2xl transition-all uppercase tracking-[3px] text-xs flex items-center justify-center gap-4 ${!method || pState === PaymentState.IN_PROGRESS ? 'bg-gray-100 text-gray-400' : 'bg-[#5C4D3C] text-white hover:bg-black hover:scale-[1.02]'}`}
        >
          {pState === PaymentState.IN_PROGRESS ? (
            <div className="flex items-center gap-3">
              <div className="w-5 h-5 border-3 border-white border-t-transparent rounded-full animate-spin"></div>
              <span>Securing Transaction...</span>
            </div>
          ) : (
            <>
              <span>Pay Now to Confirm Order</span>
              <span className="text-lg">→</span>
            </>
          )}
        </button>
        {onCancel && pState !== PaymentState.IN_PROGRESS && (
          <button onClick={onCancel} className="w-full text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest hover:text-[#5C4D3C] transition-colors">Discard Order Review</button>
        )}
      </div>
    </div>
  );
};

const PaymentOption: React.FC<{ active: boolean, onClick: () => void, title: string, desc: string, icon: string }> = ({ active, onClick, title, desc, icon }) => (
  <button 
    onClick={onClick}
    className={`p-6 rounded-[32px] border-2 text-left transition-all flex items-center gap-6 group ${active ? 'border-[#5C4D3C] bg-[#FDFBF7] ring-8 ring-[#5C4D3C]/5' : 'border-[#EBE3D5] opacity-70 hover:opacity-100 hover:border-[#A68F7A]'}`}
  >
    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl transition-all ${active ? 'bg-[#5C4D3C] text-white shadow-lg' : 'bg-white border border-[#EBE3D5]'}`}>
      {icon}
    </div>
    <div className="flex-grow">
      <h4 className="text-sm font-bold text-[#5C4D3C]">{title}</h4>
      <p className="text-[10px] text-[#A68F7A] mt-0.5">{desc}</p>
    </div>
    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${active ? 'border-[#5C4D3C] bg-[#5C4D3C]' : 'border-[#EBE3D5]'}`}>
      {active && <div className="w-2 h-2 bg-white rounded-full"></div>}
    </div>
  </button>
);

export default PaymentGateway;
