
import React, { useState, useEffect } from 'react';
import { User, Address, AdminSettings, Order, OrderStatus, Product, PaymentMethod } from '../../types.ts';
import AddressForm from '../Shared/AddressForm.tsx';
import CustomerOrders from './Orders.tsx';
import { useSearchParams } from 'react-router-dom';

interface ProfileProps {
  user: User;
  adminSettings: AdminSettings;
  orders: Order[];
  products: Product[];
  onUpdateAddresses: (addresses: Address[]) => void;
  onUpdateProfile: (name: string, email: string, phone: string) => void;
  onPayOrder: (id: string, method: PaymentMethod, screenshot?: string, transactionId?: string, aiDetails?: any) => void;
  onAddReview: (productId: string, orderId: string, rating: number, comment: string) => void;
}

const ProfileView: React.FC<ProfileProps> = ({ 
  user, 
  adminSettings, 
  orders, 
  products, 
  onUpdateAddresses, 
  onUpdateProfile,
  onPayOrder,
  onAddReview
}) => {
  const [searchParams, setSearchParams] = useSearchParams();
  const activeTab = searchParams.get('tab') || 'info';
  
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [profileName, setProfileName] = useState(user.name);
  const [profileEmail, setProfileEmail] = useState(user.email);
  const [profilePhone, setProfilePhone] = useState(user.phone || '');

  const [showAddressModal, setShowAddressModal] = useState(false);
  const [editingAddress, setEditingAddress] = useState<Address | undefined>();

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile(profileName, profileEmail, profilePhone);
    setIsEditingProfile(false);
  };

  const handleSaveAddress = (addr: Address) => {
    const existingIdx = user.addresses.findIndex(a => a.id === addr.id);
    let updated: Address[];
    
    // If setting as default, clear others first
    if (addr.isDefault) {
      updated = user.addresses.map(a => ({ ...a, isDefault: false }));
    } else {
      updated = [...user.addresses];
    }

    if (existingIdx > -1) {
      updated[existingIdx] = addr;
    } else {
      updated.push(addr);
    }
    onUpdateAddresses(updated);
    setShowAddressModal(false);
    setEditingAddress(undefined);
  };

  const handleDeleteAddress = (id: string) => {
    if (confirm("Permanently remove this delivery destination?")) {
      onUpdateAddresses(user.addresses.filter(a => a.id !== id));
    }
  };

  const handleSetDefaultAddress = (id: string) => {
    onUpdateAddresses(user.addresses.map(a => ({ ...a, isDefault: a.id === id })));
  };

  const TabButton = ({ id, label, icon }: { id: string, label: string, icon: string }) => (
    <button 
      onClick={() => setSearchParams({ tab: id })}
      className={`px-8 py-4 text-[10px] font-bold uppercase tracking-widest transition-all border-b-2 ${
        activeTab === id 
          ? 'text-[#5C4D3C] border-[#5C4D3C] bg-white' 
          : 'text-[#A68F7A] border-transparent hover:text-[#5C4D3C]'
      }`}
    >
      <span className="mr-2">{icon}</span> {label}
    </button>
  );

  return (
    <div className="max-w-5xl mx-auto space-y-10 animate-in fade-in duration-500 pb-20 pt-10">
      <div className="flex flex-col items-center text-center space-y-4">
        <div className="w-24 h-24 bg-[#5C4D3C] rounded-full flex items-center justify-center text-4xl text-white border-4 border-[#EBE3D5] shadow-xl font-serif">
          {user.name[0]}
        </div>
        <div>
          <h1 className="text-4xl font-serif font-bold text-[#5C4D3C]">{user.name}</h1>
          <p className="text-[#A68F7A] text-[10px] uppercase tracking-[4px] font-bold mt-1 italic">Artisanal Member</p>
        </div>
      </div>

      <div className="flex bg-[#FDFBF7] border-b border-[#EBE3D5] sticky top-16 z-40 overflow-x-auto no-scrollbar justify-center">
        <TabButton id="info" label="Personal Details" icon="👤" />
        <TabButton id="addresses" label="Saved Hubs" icon="📍" />
        <TabButton id="orders" label="Order History" icon="📋" />
      </div>

      <div className="min-h-[50vh]">
        {activeTab === 'info' && (
          <div className="max-w-xl mx-auto py-12 space-y-10 animate-in slide-in-from-bottom-2">
            <div className="bg-white p-10 rounded-[40px] border border-[#EBE3D5] shadow-sm relative overflow-hidden">
               <div className="absolute top-0 right-0 p-8 opacity-5 text-8xl italic font-serif pointer-events-none">Member</div>
               <div className="flex justify-between items-center mb-8">
                  <h3 className="text-2xl font-serif font-bold text-[#5C4D3C]">Identity Profile</h3>
                  {!isEditingProfile && (
                    <button onClick={() => setIsEditingProfile(true)} className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest hover:text-[#5C4D3C] border border-[#EBE3D5] px-4 py-2 rounded-full transition-colors">Edit Identity</button>
                  )}
               </div>

               {isEditingProfile ? (
                 <form onSubmit={handleSaveProfile} className="space-y-6">
                    <div className="space-y-2">
                       <label className="text-[9px] font-bold uppercase text-[#A68F7A] tracking-widest px-2">Full Legal Name</label>
                       <input value={profileName} onChange={e => setProfileName(e.target.value)} className="w-full px-6 py-4 bg-[#FDFBF7] border border-[#EBE3D5] rounded-2xl outline-none text-sm font-bold text-[#5C4D3C]" />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[9px] font-bold uppercase text-[#A68F7A] tracking-widest px-2">Email Identity</label>
                       <input value={profileEmail} onChange={e => setProfileEmail(e.target.value)} className="w-full px-6 py-4 bg-[#FDFBF7] border border-[#EBE3D5] rounded-2xl outline-none text-sm font-bold text-[#5C4D3C]" />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[9px] font-bold uppercase text-[#A68F7A] tracking-widest px-2">Contact Number</label>
                       <input value={profilePhone} onChange={e => setProfilePhone(e.target.value)} className="w-full px-6 py-4 bg-[#FDFBF7] border border-[#EBE3D5] rounded-2xl outline-none text-sm font-bold text-[#5C4D3C]" />
                    </div>
                    <div className="flex gap-4 pt-4">
                       <button type="button" onClick={() => setIsEditingProfile(false)} className="flex-1 py-4 border border-[#EBE3D5] rounded-2xl text-[10px] font-bold uppercase tracking-widest text-[#A68F7A]">Discard</button>
                       <button type="submit" className="flex-1 py-4 bg-[#5C4D3C] text-white rounded-2xl text-[10px] font-bold uppercase tracking-widest shadow-lg hover:bg-black transition-all">Update Identity</button>
                    </div>
                 </form>
               ) : (
                 <div className="space-y-10">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                       <div>
                          <p className="text-[9px] font-bold uppercase text-[#A68F7A] tracking-widest mb-1">Name</p>
                          <p className="text-lg font-bold text-[#5C4D3C]">{user.name}</p>
                       </div>
                       <div>
                          <p className="text-[9px] font-bold uppercase text-[#A68F7A] tracking-widest mb-1">Email</p>
                          <p className="text-lg font-bold text-[#5C4D3C]">{user.email}</p>
                       </div>
                    </div>
                    <div>
                       <p className="text-[9px] font-bold uppercase text-[#A68F7A] tracking-widest mb-1">Phone Verified</p>
                       <p className="text-lg font-bold text-[#5C4D3C] flex items-center gap-2">
                         {user.phone || 'Not Shared'} 
                         {user.phone && <span className="text-emerald-500 text-xs">✓</span>}
                       </p>
                    </div>
                    <div className="p-6 bg-[#FDFBF7] rounded-[32px] border border-dashed border-[#EBE3D5]">
                       <p className="text-[10px] text-[#7C6A58] leading-relaxed italic">"Profile updates apply only to future creation requests. Existing order signatures remain preserved for studio auditing."</p>
                    </div>
                 </div>
               )}
            </div>
          </div>
        )}

        {activeTab === 'addresses' && (
          <div className="py-12 space-y-10 animate-in slide-in-from-bottom-2">
            <div className="flex justify-between items-center">
               <div>
                  <h3 className="text-3xl font-serif font-bold text-[#5C4D3C]">Delivery Hubs</h3>
                  <p className="text-[#A68F7A] text-xs mt-1 italic">Manage your handcrafted delivery locations.</p>
               </div>
               <button 
                onClick={() => { setEditingAddress(undefined); setShowAddressModal(true); }}
                className="bg-[#5C4D3C] text-white px-8 py-3 rounded-full text-[10px] font-bold uppercase tracking-widest shadow-xl hover:bg-black hover:scale-105 transition-all"
               >
                + Add New Hub
               </button>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {user.addresses.length === 0 ? (
                <div className="lg:col-span-3 py-24 text-center bg-white border-2 border-dashed border-[#EBE3D5] rounded-[50px]">
                   <p className="text-[#A68F7A] font-serif italic text-lg">Your delivery list is empty.</p>
                </div>
              ) : (
                user.addresses.map((addr) => (
                  <div key={addr.id} className={`bg-white p-8 rounded-[40px] border transition-all shadow-sm group relative ${addr.isDefault ? 'border-[#5C4D3C] ring-8 ring-[#5C4D3C]/5' : 'border-[#EBE3D5] hover:border-[#A68F7A]'}`}>
                    <div className="flex justify-between items-start mb-6">
                       <div className="flex items-center gap-3">
                          <span className={`text-[9px] font-bold uppercase tracking-widest px-4 py-1.5 rounded-full ${addr.isDefault ? 'bg-[#5C4D3C] text-white' : 'bg-[#FDFBF7] text-[#A68F7A] border border-[#EBE3D5]'}`}>{addr.label}</span>
                          {addr.isDefault && <span className="text-[10px] text-amber-600">★</span>}
                       </div>
                       <div className="flex gap-4 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button onClick={() => { setEditingAddress(addr); setShowAddressModal(true); }} className="text-[9px] text-[#5C4D3C] font-bold uppercase hover:underline">Edit</button>
                          {!addr.isDefault && (
                            <button onClick={() => handleDeleteAddress(addr.id)} className="text-[9px] text-rose-500 font-bold uppercase hover:underline">Delete</button>
                          )}
                       </div>
                    </div>
                    <p className="text-xl font-serif font-bold text-[#5C4D3C]">{addr.fullName}</p>
                    <div className="text-[13px] text-[#7C6A58] mt-3 leading-relaxed whitespace-pre-line font-medium italic">
                      {addr.houseFlat}, {addr.streetArea}<br/>
                      {addr.city}, {addr.state} - {addr.pinCode}
                    </div>
                    
                    <div className="pt-6 mt-6 border-t border-[#FDFBF7] flex justify-between items-center">
                       <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-[2px]">{addr.phone}</p>
                       {!addr.isDefault && (
                         <button onClick={() => handleSetDefaultAddress(addr.id)} className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest hover:underline">Set Default</button>
                       )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {activeTab === 'orders' && (
          <div className="py-12 animate-in slide-in-from-bottom-2">
             <CustomerOrders 
                orders={orders} 
                adminSettings={adminSettings} 
                products={products}
                onPay={onPayOrder}
                onAddReview={onAddReview}
             />
          </div>
        )}
      </div>

      {showAddressModal && (
        <AddressForm 
          initialAddress={editingAddress}
          onSave={handleSaveAddress}
          onCancel={() => { setShowAddressModal(false); setEditingAddress(undefined); }}
        />
      )}
    </div>
  );
};

export default ProfileView;
