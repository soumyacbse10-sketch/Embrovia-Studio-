
import React, { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Product } from '../../types';

interface ProductListProps {
  products: Product[];
}

const ProductList: React.FC<ProductListProps> = ({ products }) => {
  const [searchParams] = useSearchParams();
  const categoryFilter = searchParams.get('category');
  
  const [searchTerm, setSearchTerm] = useState('');
  const [sortOrder, setSortOrder] = useState<'low' | 'high' | 'new'>('new');

  const filtered = products
    .filter(p => !categoryFilter || p.category === categoryFilter)
    .filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()))
    .sort((a, b) => {
      if (sortOrder === 'low') return a.price - b.price;
      if (sortOrder === 'high') return b.price - a.price;
      return 0; // Default new
    });

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-[#EBE3D5]">
        <div>
          <h1 className="text-4xl font-serif font-bold text-[#5C4D3C]">
            {categoryFilter ? `${categoryFilter} Collection` : 'All Treasures'}
          </h1>
          <p className="text-[#A68F7A] mt-1">{filtered.length} products found</p>
        </div>
        
        <div className="flex flex-wrap gap-3">
          <input 
            type="text" 
            placeholder="Search art..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="px-4 py-2 bg-[#FDFBF7] border border-[#EBE3D5] rounded-full text-sm outline-none focus:border-[#A68F7A] min-w-[200px]"
          />
          <select 
            value={sortOrder}
            onChange={(e) => setSortOrder(e.target.value as any)}
            className="px-4 py-2 bg-[#FDFBF7] border border-[#EBE3D5] rounded-full text-sm outline-none"
          >
            <option value="new">Latest Arrivals</option>
            <option value="low">Price: Low to High</option>
            <option value="high">Price: High to Low</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {filtered.map(p => (
          <div key={p.id} className="group relative">
            <Link to={`/product/${p.id}`} className="block space-y-3">
              <div className="aspect-square rounded-2xl overflow-hidden bg-[#EBE3D5]/20 border border-[#EBE3D5]">
                <img src={p.images[0]} alt={p.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-widest text-[#A68F7A] font-bold">{p.category}</span>
                <h3 className="text-lg font-serif text-[#5C4D3C] leading-tight mt-1">{p.name}</h3>
                <p className="text-[#5C4D3C] font-semibold mt-1">₹{p.price}</p>
              </div>
            </Link>
            <button className="absolute top-4 right-4 p-2 bg-white/80 backdrop-blur-sm rounded-full shadow-sm hover:text-red-500 transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
              </svg>
            </button>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-20 bg-[#EBE3D5]/10 rounded-3xl border border-dashed border-[#EBE3D5]">
          <p className="text-[#A68F7A] italic">No pieces matching your selection currently.</p>
          <button onClick={() => {setSearchTerm(''); setSortOrder('new');}} className="mt-4 text-[#5C4D3C] underline font-bold">Clear Filters</button>
        </div>
      )}
    </div>
  );
};

export default ProductList;
