
import React from 'react';
import { useParams, Link, Navigate } from 'react-router-dom';
import { Order, OrderStatus } from '../../types.ts';

interface OrderConfirmationProps {
  orders: Order[];
}

const OrderConfirmation: React.FC<OrderConfirmationProps> = ({ orders }) => {
  const { id } = useParams<{ id: string }>();
  const order = orders.find(o => o.id === id);

  if (!order) return <div className="text-center py-40 font-serif text-[#A68F7A]">Record Retrieval Error.</div>;

  /**
   * AUTHENTICATION GATE
   * Rely strictly on OrderStatus.CONFIRMED.
   */
  const isAuthorized = [OrderStatus.CONFIRMED, OrderStatus.SHIPPED, OrderStatus.DELIVERED].includes(order.status);
  
  if (!isAuthorized) {
      console.warn("UNAUTHORIZED ACCESS: Order not yet confirmed via payment.");
      return <Navigate to="/orders" replace />;
  }

  return (
    <div className="max-w-2xl mx-auto py-20 px-6 animate-in fade-in zoom-in duration-700">
      <div className="bg-white rounded-[60px] border border-[#EBE3D5] shadow-2xl overflow-hidden">
        <div className="bg-[#5C4D3C] p-16 text-center text-white space-y-6 relative overflow-hidden">
           <div className="absolute top-4 right-4 bg-white/20 px-4 py-1 rounded-full text-[8px] font-bold uppercase tracking-widest backdrop-blur-sm">
             Verified Studio Order
           </div>
           <div className="w-24 h-24 bg-white/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-white/20">
              <span className="text-5xl">✨</span>
           </div>
           <h1 className="text-5xl font-serif font-bold italic">Creation Secured</h1>
           <p className="text-white/60 text-lg uppercase tracking-[4px]">Audit Ref: {order.id}</p>
        </div>
        
        <div className="p-16 space-y-12">
           <div className="grid md:grid-cols-1 gap-12 border-b border-gray-100 pb-12">
              <div className="space-y-4">
                 <div className="flex justify-between items-end">
                    <div>
                       <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Confirmed Total</p>
                       <p className="text-4xl font-serif font-bold text-[#5C4D3C]">₹{order.total.toLocaleString()}</p>
                    </div>
                    <div className="text-right">
                       <span className="text-emerald-600 text-lg font-bold">✓</span>
                       <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest">Action Success</p>
                    </div>
                 </div>
                 {order.verificationReason && (
                    <div className="p-4 bg-[#FDFBF7] rounded-2xl border border-[#EBE3D5]">
                      <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest mb-1">AI Audit Result</p>
                      <p className="text-xs text-[#7C6A58] italic">"{order.verificationReason}"</p>
                    </div>
                 )}
              </div>
           </div>

           <div className="space-y-6">
              <h3 className="text-xl font-serif font-bold text-[#5C4D3C]">Artisanal Timeline</h3>
              <div className="space-y-8 relative">
                 <div className="absolute left-3 top-0 bottom-0 w-px bg-gray-100"></div>
                 <TimelineStep label="Stitching Handover" desc="Our artisans have received your validated order components." active={order.status === OrderStatus.CONFIRMED} />
                 <TimelineStep label="Dispatch & Packing" desc="Artisanal preparation for safe transit." active={false} />
              </div>
           </div>

           <div className="pt-10 flex gap-6">
              <Link to="/orders" className="flex-1 py-5 bg-[#FDFBF7] border border-[#EBE3D5] rounded-3xl text-center text-sm font-bold text-[#5C4D3C] hover:bg-[#EBE3D5] transition-all shadow-sm">My Collection</Link>
              <Link to="/" className="flex-1 py-5 bg-[#5C4D3C] text-white rounded-3xl text-center text-sm font-bold shadow-xl hover:bg-black transition-all">Studio Home</Link>
           </div>
        </div>
      </div>
    </div>
  );
};

const TimelineStep: React.FC<{ label: string, desc: string, active: boolean }> = ({ label, desc, active }) => (
  <div className={`flex gap-6 relative z-10 transition-all ${active ? 'opacity-100 scale-105' : 'opacity-30'}`}>
     <div className={`w-6 h-6 rounded-full border-4 ${active ? 'bg-[#5C4D3C] border-[#EBE3D5]' : 'bg-gray-100 border-white'} flex-shrink-0`}></div>
     <div>
        <h4 className="text-sm font-bold text-[#5C4D3C]">{label}</h4>
        <p className="text-xs text-[#7C6A58] mt-1">{desc}</p>
     </div>
  </div>
);

export default OrderConfirmation;
