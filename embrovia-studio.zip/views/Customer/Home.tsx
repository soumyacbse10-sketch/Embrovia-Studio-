
import React from 'react';
import { Link } from 'react-router-dom';
import { Product, AdminSettings } from '../../types';
import SupportContact from '../Shared/SupportContact.tsx';

interface HomeProps {
  products: Product[];
  adminSettings: AdminSettings;
}

const CustomerHome: React.FC<HomeProps> = ({ products, adminSettings }) => {
  const featured = products.filter(p => p.isFeatured).slice(0, 3);
  const newArrivals = products.slice(0, 4);

  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <section className="relative h-[500px] overflow-hidden rounded-3xl group">
        <img 
          src="https://picsum.photos/seed/embro-hero/1200/600" 
          alt="Embroidery Art" 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-black/30 flex items-center justify-center text-center px-4">
          <div className="max-w-2xl">
            <h1 className="text-5xl md:text-7xl font-serif text-white mb-6 drop-shadow-lg">Hand-stitched Stories</h1>
            <p className="text-xl text-white/90 mb-8 font-light italic">Artisanal embroidery pieces that bring soul to your spaces.</p>
            <Link to="/shop" className="inline-block bg-[#FDFBF7] text-[#5C4D3C] px-10 py-4 rounded-full font-bold hover:bg-[#EBE3D5] transition-all shadow-xl">Explore Collection</Link>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section>
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="text-3xl font-serif font-bold text-[#5C4D3C]">Browse by Craft</h2>
            <div className="h-1 w-20 bg-[#A68F7A] mt-2"></div>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {['Hoop Art', 'Home Decor', 'Accessories', 'Gifts'].map(cat => (
            <Link 
              key={cat} 
              to={`/shop?category=${cat}`}
              className="relative aspect-square rounded-2xl overflow-hidden group border border-[#EBE3D5]"
            >
              <img src={`https://picsum.photos/seed/${cat}/400/400`} alt={cat} className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
                <span className="text-white font-serif text-lg">{cat}</span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section>
        <div className="text-center mb-12">
          <h2 className="text-4xl font-serif font-bold text-[#5C4D3C]">The Masterpieces</h2>
          <p className="text-[#A68F7A] mt-2 italic">Our most intricate, time-intensive creations</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {featured.map(p => (
            <Link key={p.id} to={`/product/${p.id}`} className="group space-y-4">
              <div className="aspect-[4/5] overflow-hidden rounded-2xl border border-[#EBE3D5]">
                <img src={p.images[0]} alt={p.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
              </div>
              <div className="text-center">
                <h3 className="text-xl font-serif text-[#5C4D3C]">{p.name}</h3>
                <p className="text-[#A68F7A] font-medium">₹{p.price}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Quality Promise */}
      <section className="bg-[#EBE3D5]/30 rounded-3xl p-12 text-center border border-[#EBE3D5]">
        <div className="max-w-3xl mx-auto space-y-6">
          <h2 className="text-3xl font-serif text-[#5C4D3C]">Why Embrovia Studio?</h2>
          <div className="grid md:grid-cols-3 gap-8 pt-6">
            <div className="space-y-2">
              <div className="text-2xl">🪡</div>
              <h4 className="font-bold text-[#5C4D3C]">100% Handmade</h4>
              <p className="text-sm text-[#7C6A58]">Every stitch is placed by hand with love.</p>
            </div>
            <div className="space-y-2">
              <div className="text-2xl">🎨</div>
              <h4 className="font-bold text-[#5C4D3C]">Custom Art</h4>
              <p className="text-sm text-[#7C6A58]">We turn your memories into embroidery.</p>
            </div>
            <div className="space-y-2">
              <div className="text-2xl">🌱</div>
              <h4 className="font-bold text-[#5C4D3C]">Eco-Friendly</h4>
              <p className="text-sm text-[#7C6A58]">Sustainably sourced premium threads.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Dynamic Support Contact Section */}
      <SupportContact settings={adminSettings} />
    </div>
  );
};

export default CustomerHome;
