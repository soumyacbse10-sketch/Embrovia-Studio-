
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { CartItem, Product, Order, AdminSettings, Address, Coupon } from '../../types.ts';
import AddressForm from '../Shared/AddressForm.tsx';

interface CartProps {
  cart: CartItem[];
  products: Product[];
  adminSettings: AdminSettings;
  userAddresses: Address[];
  onUpdateQty: (id: string, qty: number) => void;
  onRemove: (id: string) => void;
  onCheckout: (address: Address, discount: number) => Order | undefined;
  onAddAddress: (address: Address) => void;
}

const CartView: React.FC<CartProps> = ({ cart, products, adminSettings, userAddresses, onUpdateQty, onRemove, onCheckout, onAddAddress }) => {
  const navigate = useNavigate();
  const [selectedAddressId, setSelectedAddressId] = useState<string>(userAddresses[0]?.id || '');
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showAddressModal, setShowAddressModal] = useState(false);
  
  // Coupon State
  const [couponInput, setCouponInput] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState<string | null>(null);

  const cartDetails = cart.map(ci => ({
    ...ci,
    product: products.find(p => p.id === ci.productId)!
  })).filter(ci => ci.product);

  const subtotal = cartDetails.reduce((acc, curr) => acc + (curr.product.price * curr.quantity), 0);
  
  // Calculate Discount
  let discountAmount = 0;
  if (appliedCoupon) {
    if (appliedCoupon.type === 'PERCENT') {
      discountAmount = Math.round(subtotal * (appliedCoupon.value / 100));
    } else {
      discountAmount = appliedCoupon.value;
    }
  }

  const estimatedShipping = 50;
  const total = subtotal + estimatedShipping - discountAmount;

  const handleApplyCoupon = () => {
    setCouponError(null);
    const code = couponInput.toUpperCase().trim();
    const coupon = adminSettings.coupons.find(c => c.code === code && c.isEnabled);
    
    if (!coupon) {
      setCouponError("Invalid or expired artisanal code.");
      setAppliedCoupon(null);
      return;
    }
    
    if (subtotal < coupon.minOrderAmount) {
      setCouponError(`Min order for this code is ₹${coupon.minOrderAmount}.`);
      setAppliedCoupon(null);
      return;
    }

    setAppliedCoupon(coupon);
    setCouponInput('');
  };

  const handlePlaceOrder = () => {
    setErrorMessage(null);
    const selectedAddress = userAddresses.find(a => a.id === selectedAddressId);
    
    if (!selectedAddress) {
      setErrorMessage("Please select or add a delivery address.");
      return;
    }
    
    setIsProcessing(true);
    setTimeout(() => {
      onCheckout(selectedAddress, discountAmount);
      setIsProcessing(false);
      navigate('/orders');
    }, 1500);
  };

  if (cart.length === 0) {
    return (
      <div className="text-center py-32 space-y-6">
        <div className="text-6xl">🧶</div>
        <h1 className="text-4xl font-serif text-[#5C4D3C] font-bold">Your Bag is Empty</h1>
        <p className="text-[#7C6A58] italic">Looks like you haven't added any handcrafted magic yet.</p>
        <Link to="/shop" className="inline-block bg-[#5C4D3C] text-white px-12 py-4 rounded-full font-bold shadow-xl hover:bg-black transition-all">Explore Creations</Link>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-12">
      <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-[#EBE3D5] pb-8">
        <div>
          <h1 className="text-5xl font-serif font-bold text-[#5C4D3C]">Checkout Review</h1>
          <p className="text-[#A68F7A] mt-2 italic font-medium">Verify your artisanal collection before processing.</p>
        </div>
        <div className="bg-[#FDFBF7] px-6 py-2 rounded-2xl border border-[#EBE3D5] text-[10px] font-bold text-[#5C4D3C] uppercase tracking-widest shadow-sm mt-4 md:mt-0">
          Studio Authenticated Bag
        </div>
      </div>
      
      <div className="grid lg:grid-cols-3 gap-16">
        <div className="lg:col-span-2 space-y-12">
          {/* Order Items */}
          <div className="space-y-6">
            <h2 className="text-2xl font-serif font-bold text-[#5C4D3C] flex items-center gap-3">
              <span className="text-lg">🧵</span> Collection Items
            </h2>
            <div className="space-y-4">
              {cartDetails.map(item => (
                <div key={item.productId} className="flex gap-6 p-5 bg-white rounded-[32px] border border-[#EBE3D5] shadow-sm group">
                  <div className="w-24 h-24 rounded-2xl overflow-hidden bg-[#EBE3D5]/20 flex-shrink-0">
                    <img src={item.product.images[0]} alt={item.product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  </div>
                  <div className="flex-grow flex flex-col justify-between py-1">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-lg font-bold text-[#5C4D3C] leading-tight">{item.product.name}</h3>
                        <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest mt-1">{item.product.category}</p>
                      </div>
                      <p className="text-lg font-serif font-bold text-[#5C4D3C]">₹{(item.product.price * item.quantity).toLocaleString()}</p>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-3 text-sm bg-[#FDFBF7] border border-[#EBE3D5] px-3 py-1.5 rounded-full">
                         <button onClick={() => onUpdateQty(item.productId, item.quantity - 1)} className="w-5 h-5 flex items-center justify-center text-[#A68F7A] hover:text-[#5C4D3C] font-bold">-</button>
                         <span className="font-bold text-[#5C4D3C] min-w-[20px] text-center">{item.quantity}</span>
                         <button onClick={() => onUpdateQty(item.productId, item.quantity + 1)} className="w-5 h-5 flex items-center justify-center text-[#A68F7A] hover:text-[#5C4D3C] font-bold">+</button>
                      </div>
                      <button onClick={() => onRemove(item.productId)} className="text-[10px] text-rose-500 font-bold uppercase tracking-wider hover:underline">Remove from bag</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Delivery Address */}
          <div className="bg-white p-10 rounded-[40px] border border-[#EBE3D5] space-y-8 shadow-sm">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-serif font-bold text-[#5C4D3C]">Shipping Destination</h2>
              <button 
                onClick={() => setShowAddressModal(true)}
                className="text-xs font-bold text-[#A68F7A] uppercase tracking-widest hover:text-[#5C4D3C] transition-colors"
              >
                + Add New Doorstep
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {userAddresses.length === 0 ? (
                <div className="md:col-span-2 text-center py-12 border-2 border-dashed border-[#EBE3D5] rounded-3xl bg-[#FDFBF7]">
                   <p className="text-sm text-[#7C6A58] italic font-serif">No delivery destinations found in your profile.</p>
                </div>
              ) : (
                userAddresses.map(addr => (
                  <div 
                    key={addr.id}
                    onClick={() => { setSelectedAddressId(addr.id); setErrorMessage(null); }}
                    className={`p-6 rounded-[32px] border-2 transition-all cursor-pointer relative shadow-sm ${selectedAddressId === addr.id ? 'border-[#5C4D3C] bg-[#FDFBF7] ring-4 ring-[#5C4D3C]/5' : 'border-[#EBE3D5] opacity-60 hover:opacity-100 hover:border-[#A68F7A]'}`}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <span className={`text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-full ${selectedAddressId === addr.id ? 'bg-[#5C4D3C] text-white' : 'bg-gray-100 text-[#7C6A58]'}`}>{addr.label}</span>
                      {selectedAddressId === addr.id && <span className="text-[#5C4D3C] text-xl">✓</span>}
                    </div>
                    <p className="text-lg font-serif font-bold text-[#5C4D3C]">{addr.fullName}</p>
                    <p className="text-sm text-[#7C6A58] mt-2 leading-relaxed">{addr.houseFlat}, {addr.streetArea}<br/>{addr.city}, {addr.state} - {addr.pinCode}</p>
                    <p className="text-xs font-bold text-[#A68F7A] mt-3 uppercase tracking-widest">{addr.phone}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-[#5C4D3C] p-10 rounded-[40px] text-white shadow-2xl sticky top-24 space-y-8 overflow-hidden">
            <div className="absolute top-0 left-0 p-4 opacity-5 pointer-events-none text-8xl italic font-serif">Bag</div>
            <h2 className="text-2xl font-serif font-bold border-b border-white/10 pb-4">Estimated Summary</h2>
            
            <div className="space-y-4 text-sm">
              <div className="flex justify-between opacity-70"><span>Craft Subtotal</span><span>₹{subtotal.toLocaleString()}</span></div>
              <div className="flex justify-between opacity-70"><span>Artisanal Shipping</span><span>₹{estimatedShipping.toLocaleString()}</span></div>
              
              {appliedCoupon && (
                <div className="flex justify-between text-emerald-400 font-bold">
                  <span>Code: {appliedCoupon.code}</span>
                  <span>-₹{discountAmount.toLocaleString()}</span>
                </div>
              )}

              <div className="pt-6 border-t border-white/10 flex justify-between text-3xl font-serif font-bold">
                <span>Total</span><span>₹{total.toLocaleString()}</span>
              </div>
            </div>

            {/* Promotional Input */}
            <div className="pt-2">
              <label className="text-[10px] font-bold uppercase tracking-widest opacity-50 mb-2 block">Studio Promo Code</label>
              <div className="flex gap-2">
                 <input 
                  type="text" 
                  value={couponInput}
                  onChange={(e) => setCouponInput(e.target.value)}
                  placeholder="Enter Code"
                  className="bg-white/10 border border-white/20 rounded-xl px-4 py-2 text-sm flex-grow outline-none focus:bg-white/20 transition-all placeholder:text-white/30"
                 />
                 <button 
                  onClick={handleApplyCoupon}
                  className="bg-white text-[#5C4D3C] px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-[#FDFBF7]"
                 >
                  Apply
                 </button>
              </div>
              {couponError && <p className="text-[10px] text-rose-400 mt-2 font-bold uppercase tracking-wide">{couponError}</p>}
              {appliedCoupon && <button onClick={() => setAppliedCoupon(null)} className="text-[10px] text-emerald-400 mt-2 uppercase tracking-widest font-bold hover:underline">Remove Code</button>}
            </div>

            {errorMessage && (
              <div className="p-4 bg-rose-500/20 border border-rose-500/50 rounded-2xl text-[10px] text-rose-100 font-bold uppercase tracking-widest text-center animate-shake">
                {errorMessage}
              </div>
            )}

            <button 
              onClick={handlePlaceOrder}
              disabled={isProcessing || userAddresses.length === 0}
              className={`w-full py-5 rounded-3xl font-bold shadow-2xl transition-all active:scale-[0.98] uppercase tracking-[3px] text-[10px] ${
                userAddresses.length === 0 
                  ? 'bg-white/5 text-white/30 cursor-not-allowed border border-white/10' 
                  : 'bg-white text-[#5C4D3C] hover:bg-[#FDFBF7]'
              }`}
            >
              {isProcessing ? 'Submitting to Studio...' : 'Finalize & Review'}
            </button>
            <p className="text-[9px] text-center opacity-40 italic">Reviewing for custom charges may follow.</p>
          </div>
        </div>
      </div>

      {showAddressModal && (
        <AddressForm 
          onSave={(a) => { onAddAddress(a); setSelectedAddressId(a.id); setShowAddressModal(false); }} 
          onCancel={() => setShowAddressModal(false)} 
        />
      )}
    </div>
  );
};

export default CartView;
