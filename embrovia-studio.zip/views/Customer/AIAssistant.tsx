
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Product, AdminSettings } from '../../types.ts';

interface Message {
  role: 'user' | 'model';
  text: string;
}

interface AIAssistantProps {
  products: Product[];
  isOpen: boolean;
  onClose: () => void;
  adminSettings: AdminSettings;
}

const AIAssistant: React.FC<AIAssistantProps> = ({ products, isOpen, onClose, adminSettings }) => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: 'Namaste! I am your Embrovia Concierge. How can I help you discover our handcrafted treasures today?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsLoading(true);

    try {
      // Create a new GoogleGenAI instance right before making an API call to ensure it always uses the most up-to-date API key.
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const productContext = products.map(p => 
        `Product: ${p.name}, Price: ₹${p.price}, Category: ${p.category}, Description: ${p.description}, Care: ${p.careInstructions}`
      ).join('\n');

      const supportContext = `
        Support Contact Info:
        ${adminSettings.supportPhoneEnabled ? `- Phone: ${adminSettings.supportPhone}` : ''}
        ${adminSettings.supportWhatsAppEnabled ? `- WhatsApp: ${adminSettings.supportWhatsApp}` : ''}
        ${adminSettings.supportEmailEnabled ? `- Email: ${adminSettings.supportEmail}` : ''}
      `;

      const systemInstruction = `
        You are "Embrovia Concierge", the premium AI assistant for "Embrovia Studio", a handmade embroidery brand.
        Tone: Calm, artisanal, helpful, and polite.
        Context:
        - We specialize in Hoops, Home Decor, Accessories, and Gifts.
        - All items are 100% hand-stitched.
        - Shipping: Manual via Delhivery or similar. Tracking provided after shipping.
        - Payments: Online Prepaid, COD, and QR Scan & Pay.
        - Our Catalog:
        ${productContext}
        
        Support Details:
        ${supportContext}
        
        Rules:
        1. Keep responses concise and elegant.
        2. If asked about an order issue, suggest they contact our artisans using the provided support details.
        3. Only recommend products from the catalog provided.
        4. Focus on the beauty of the craft.
      `;

      // Use gemini-3-flash-preview for general Q&A as per model selection rules.
      // Corrected contents mapping to include role for correct multi-turn conversation handling.
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [...messages, { role: 'user', text: userMsg }].map(m => ({
          role: m.role,
          parts: [{ text: m.text }]
        })),
        config: {
          systemInstruction,
          temperature: 0.7,
        }
      });

      // Access text as a property directly
      const aiText = response.text || "I apologize, I am momentarily speechless. How else may I assist you?";
      setMessages(prev => [...prev, { role: 'model', text: aiText }]);
    } catch (error) {
      console.error("AI Support Error:", error);
      setMessages(prev => [...prev, { role: 'model', text: "I encountered a small snag in my threads. Please try again or contact us directly." }]);
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-24 right-6 w-80 md:w-96 h-[500px] bg-white rounded-3xl shadow-2xl border border-[#EBE3D5] flex flex-col overflow-hidden z-[100] animate-in slide-in-from-bottom-4 duration-300">
      {/* Header */}
      <div className="bg-[#5C4D3C] p-4 text-white flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-[#A68F7A] rounded-full flex items-center justify-center text-xs">🧵</div>
          <div>
            <h3 className="font-serif font-bold text-sm">Embrovia Concierge</h3>
            <p className="text-[10px] opacity-70">AI Assistant • Online</p>
          </div>
        </div>
        <button onClick={onClose} className="text-white/60 hover:text-white transition-colors">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
        </button>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-grow overflow-y-auto p-4 space-y-4 bg-[#FDFBF7]">
        {messages.map((m, idx) => (
          <div key={idx} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] px-4 py-2 rounded-2xl text-sm leading-relaxed ${
              m.role === 'user' 
                ? 'bg-[#5C4D3C] text-white rounded-br-none' 
                : 'bg-white text-[#7C6A58] border border-[#EBE3D5] rounded-bl-none shadow-sm'
            }`}>
              {m.text}
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-white px-4 py-2 rounded-2xl border border-[#EBE3D5] rounded-bl-none shadow-sm animate-pulse text-[#A68F7A] text-xs font-medium">
              Stitching a response...
            </div>
          </div>
        )}
      </div>

      {/* Input */}
      <div className="p-4 bg-white border-t border-[#EBE3D5]">
        <div className="flex gap-2 bg-[#FDFBF7] p-1 rounded-2xl border border-[#EBE3D5]">
          <input 
            type="text" 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type your question..."
            className="flex-grow bg-transparent px-3 py-2 text-sm outline-none placeholder-[#A68F7A]"
          />
          <button 
            onClick={handleSend}
            disabled={isLoading}
            className="bg-[#5C4D3C] text-white p-2 rounded-xl hover:bg-[#483C2F] transition-colors disabled:opacity-50"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
          </button>
        </div>
        <p className="text-[9px] text-center text-[#A68F7A] mt-2">Powered by Gemini AI • Responses are instant</p>
      </div>
    </div>
  );
};

export default AIAssistant;
