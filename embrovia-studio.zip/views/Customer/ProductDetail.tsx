
import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Product } from '../../types';

interface ProductDetailProps {
  products: Product[];
  onAddToCart: (id: string, qty: number) => void;
}

const ProductDetail: React.FC<ProductDetailProps> = ({ products, onAddToCart }) => {
  const { id } = useParams<{ id: string }>();
  const product = products.find(p => p.id === id);
  const [mainImage, setMainImage] = useState(product?.images[0] || '');
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);

  if (!product) return <div className="text-center py-20">Product not found. <Link to="/shop" className="underline">Back to Shop</Link></div>;

  const handleAdd = () => {
    onAddToCart(product.id, qty);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const reviews = product.reviews || [];
  const avgRating = reviews.length > 0 
    ? reviews.reduce((acc, curr) => acc + curr.rating, 0) / reviews.length 
    : 0;

  return (
    <div className="space-y-16 mt-8">
      <div className="grid md:grid-cols-2 gap-12">
        {/* Gallery */}
        <div className="space-y-4">
          <div className="aspect-square rounded-3xl overflow-hidden border border-[#EBE3D5] shadow-lg">
            <img src={mainImage} alt={product.name} className="w-full h-full object-cover" />
          </div>
          <div className="flex gap-4 overflow-x-auto pb-2">
            {product.images.map((img, idx) => (
              <button 
                key={idx} 
                onClick={() => setMainImage(img)}
                className={`w-20 h-20 rounded-xl overflow-hidden border-2 transition-all flex-shrink-0 ${mainImage === img ? 'border-[#A68F7A]' : 'border-transparent opacity-60'}`}
              >
                <img src={img} alt={`${product.name} view ${idx}`} className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* Details */}
        <div className="flex flex-col">
          <div className="border-b border-[#EBE3D5] pb-6 mb-6">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-[#A68F7A] font-bold tracking-widest text-xs uppercase">{product.category}</span>
                <h1 className="text-4xl font-serif font-bold text-[#5C4D3C] mt-2 leading-tight">{product.name}</h1>
              </div>
              {avgRating > 0 && (
                <div className="flex items-center bg-[#FDFBF7] px-3 py-1 rounded-full border border-[#EBE3D5] shadow-sm">
                  <span className="text-[#5C4D3C] font-bold text-sm mr-1">{avgRating.toFixed(1)}</span>
                  <span className="text-amber-400">★</span>
                </div>
              )}
            </div>
            <p className="text-2xl text-[#5C4D3C] mt-4 font-semibold">₹{product.price}</p>
          </div>

          <div className="space-y-6 text-[#7C6A58] text-sm leading-relaxed">
            <p>{product.description}</p>
            
            <div className="bg-[#FDFBF7] border border-[#EBE3D5] p-4 rounded-2xl">
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#5C4D3C] mb-2 flex items-center">
                <span className="mr-2">✨</span> Care Instructions
              </h4>
              <p className="italic">{product.careInstructions}</p>
            </div>

            <div className="flex items-center space-x-6 pt-6">
              <div className="flex items-center border border-[#EBE3D5] rounded-full px-4 py-2 bg-[#FDFBF7]">
                <button onClick={() => setQty(Math.max(1, qty - 1))} className="text-[#5C4D3C] font-bold">-</button>
                <span className="mx-6 font-medium text-[#5C4D3C]">{qty}</span>
                <button onClick={() => setQty(qty + 1)} className="text-[#5C4D3C] font-bold">+</button>
              </div>
              
              <button 
                onClick={handleAdd}
                disabled={product.stock === 0}
                className={`flex-grow py-4 rounded-full font-bold transition-all shadow-lg transform active:scale-95 ${added ? 'bg-green-600 text-white' : 'bg-[#5C4D3C] text-white hover:bg-[#483C2F]'}`}
              >
                {product.stock === 0 ? 'Out of Stock' : added ? 'Added to Bag!' : 'Add to Cart'}
              </button>
            </div>

            <div className="pt-8 grid grid-cols-2 gap-4">
              <button className="flex items-center justify-center space-x-2 py-3 border border-[#EBE3D5] rounded-xl hover:bg-[#FDFBF7] transition-all">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
                </svg>
                <span className="font-medium">Wishlist</span>
              </button>
              <button className="flex items-center justify-center space-x-2 py-3 border border-[#EBE3D5] rounded-xl hover:bg-[#FDFBF7] transition-all">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M7.217 10.907a2.25 2.25 0 100 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186l9.566-5.314m-9.566 7.5l9.566 5.314m0-10.628a2.25 2.25 0 100-4.5 2.25 2.25 0 000 4.5zm0 10.628a2.25 2.25 0 100 4.5 2.25 2.25 0 000-4.5z" />
                </svg>
                <span className="font-medium">Share</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Reviews Section */}
      <div className="pt-12 border-t border-[#EBE3D5]">
        <div className="flex items-center justify-between mb-8">
           <h2 className="text-3xl font-serif font-bold text-[#5C4D3C]">Artisan Feedback</h2>
           <div className="text-sm text-[#A68F7A] font-medium">{reviews.length} Reviews</div>
        </div>

        {reviews.length === 0 ? (
          <div className="py-12 bg-white rounded-3xl border border-dashed border-[#EBE3D5] text-center">
            <p className="text-[#A68F7A] italic">No reviews yet for this masterpiece. Be the first to purchase and review!</p>
          </div>
        ) : (
          <div className="space-y-6">
            {reviews.map(rev => (
              <div key={rev.id} className="bg-white p-6 rounded-3xl border border-[#EBE3D5] shadow-sm">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <p className="font-bold text-[#5C4D3C]">{rev.userName}</p>
                    <p className="text-[10px] text-[#A68F7A] font-bold uppercase tracking-widest">{new Date(rev.createdAt).toLocaleDateString()}</p>
                  </div>
                  <div className="flex text-amber-400">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <span key={i} className={i < rev.rating ? 'opacity-100' : 'opacity-20'}>★</span>
                    ))}
                  </div>
                </div>
                <p className="text-[#7C6A58] text-sm italic leading-relaxed">"{rev.comment}"</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetail;
