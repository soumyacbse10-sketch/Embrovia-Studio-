
import React, { useState, useEffect } from 'react';
import { Order, OrderStatus, PaymentMethod, AdminSettings, PaymentState, Product } from '../../types.ts';
import DocumentViewer from '../Shared/DocumentViewer.tsx';
import SupportContact from '../Shared/SupportContact.tsx';
import PaymentGateway from '../Shared/PaymentGateway.tsx';
import { useNavigate } from 'react-router-dom';

interface CustomerOrdersProps {
  orders: Order[];
  adminSettings: AdminSettings;
  onPay: (id: string, method: PaymentMethod, screenshot?: string, transactionId?: string, aiDetails?: any) => void;
  onAddReview: (productId: string, orderId: string, rating: number, comment: string) => void;
  products: Product[];
  forceActive?: boolean;
}

const CustomerOrders: React.FC<CustomerOrdersProps> = ({ orders, adminSettings, onPay, onAddReview, products, forceActive }) => {
  const navigate = useNavigate();
  const [selectedDoc, setSelectedDoc] = useState<{ type: 'INVOICE' | 'RECEIPT', order: Order } | null>(null);
  const [activePaymentOrder, setActivePaymentOrder] = useState<Order | null>(null);
  const [reviewModal, setReviewModal] = useState<{ productId: string, orderId: string } | null>(null);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');

  useEffect(() => {
    if (forceActive && orders.length > 0) {
      setActivePaymentOrder(orders[0]);
    }
  }, [forceActive, orders]);

  // STRICT STATUS MAPPING AS PER REQ C
  const getDisplayStatus = (order: Order) => {
    if (order.status === OrderStatus.DELIVERED) return 'Delivered';
    if (order.status === OrderStatus.SHIPPED) return 'Shipped';
    if (order.paymentVerified || order.status === OrderStatus.CONFIRMED) return 'Confirmed';
    if (order.paymentState === PaymentState.PENDING_VERIFICATION) return 'Awaiting Payment Verification';
    if (order.paymentState === PaymentState.REJECTED) return 'Payment Required (Proof Rejected)';
    return 'Payment Required';
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (reviewModal) {
      onAddReview(reviewModal.productId, reviewModal.orderId, rating, comment);
      setReviewModal(null);
      setRating(5);
      setComment('');
      alert("Thank you for your feedback! Your artisanal review has been locked.");
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10">
      {!forceActive && (
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-serif font-bold text-[#5C4D3C]">Artisan Timeline</h1>
            <p className="text-[#A68F7A] mt-1 tracking-wide italic">Track your handcrafted journey.</p>
          </div>
          <div className="bg-[#EBE3D5] px-5 py-2 rounded-2xl text-[10px] font-bold text-[#5C4D3C] uppercase tracking-widest shadow-sm">{orders.length} Records</div>
        </div>
      )}

      <div className="space-y-8">
        {orders.map(order => {
          const isDelivered = order.status === OrderStatus.DELIVERED;
          const isRejected = order.paymentState === PaymentState.REJECTED;
          const needsPayment = !order.paymentVerified && (order.status === OrderStatus.CUSTOMER_PAYMENT_PENDING || isRejected);
          const isPendingVerification = order.paymentState === PaymentState.PENDING_VERIFICATION;
          const isConfirmed = [OrderStatus.CONFIRMED, OrderStatus.SHIPPED, OrderStatus.DELIVERED].includes(order.status);

          return (
            <div key={order.id} className="bg-white rounded-[40px] border border-[#EBE3D5] shadow-sm p-10 overflow-hidden relative">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-[#EBE3D5] pb-8 mb-8">
                <div>
                  <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-[2px]">ORDER: #{order.id}</p>
                  <p className="text-[9px] text-[#7C6A58] mt-1 italic">{new Date(order.createdAt).toLocaleDateString(undefined, { dateStyle: 'long' })}</p>
                </div>
                <div className="flex flex-col md:items-end gap-2">
                  <span className={`px-5 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest shadow-sm ${
                    isDelivered ? 'bg-indigo-50 text-indigo-700' :
                    isConfirmed ? 'bg-emerald-50 text-emerald-700' : 
                    isPendingVerification ? 'bg-amber-50 text-amber-700 animate-pulse' :
                    isRejected ? 'bg-rose-50 text-rose-700' :
                    needsPayment ? 'bg-rose-50 text-rose-700 animate-pulse' : 'bg-[#FDFBF7] text-[#A68F7A]'
                  }`}>
                    {getDisplayStatus(order)}
                  </span>
                </div>
              </div>

              {isRejected && (
                <div className="mb-10 p-6 bg-rose-50 border-2 border-dashed border-rose-200 rounded-[32px] space-y-3 animate-in slide-in-from-top-2">
                  <div className="flex items-center gap-3">
                    <span className="text-xl">⚠️</span>
                    <p className="text-xs font-bold text-rose-700 uppercase tracking-widest">Rejection Feedback</p>
                  </div>
                  <p className="text-sm text-rose-600 font-medium italic">"{order.rejectionReason || 'The provided payment proof was not valid. Please re-submit or contact us.'}"</p>
                </div>
              )}

              <div className="grid md:grid-cols-2 gap-12 mb-10">
                <div className="space-y-6">
                  <h4 className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Creations Purchased</h4>
                  <div className="space-y-4">
                    {order.items.map((item, idx) => {
                      const hasReviewed = order.reviewedProductIds?.includes(item.productId);
                      
                      return (
                        <div key={idx} className="flex justify-between items-center text-sm p-4 bg-[#FDFBF7] rounded-2xl border border-[#EBE3D5]">
                          <div className="flex flex-col">
                            <span className="text-[#5C4D3C] font-bold">{item.quantity}x {item.name}</span>
                            <span className="text-[10px] text-[#A68F7A] uppercase tracking-widest mt-0.5">₹{item.price.toLocaleString()} per piece</span>
                            
                            {/* REVIEWS & RATINGS (POST-DELIVERY ONLY) */}
                            {isDelivered && (
                              <div className="mt-3">
                                {hasReviewed ? (
                                  <span className="text-[9px] font-bold text-emerald-600 uppercase tracking-[2px] bg-white px-3 py-1 rounded-full border border-emerald-100 shadow-sm">Review Submitted ✓</span>
                                ) : (
                                  <button 
                                    onClick={() => setReviewModal({ productId: item.productId, orderId: order.id })}
                                    className="text-[9px] font-bold text-indigo-600 uppercase tracking-widest bg-indigo-50 px-3 py-1 rounded-full hover:bg-indigo-100 transition-colors"
                                  >
                                    Review & Rate
                                  </button>
                                )}
                              </div>
                            )}
                          </div>
                          <span className="text-[#5C4D3C] font-bold">₹{(item.price * item.quantity).toLocaleString()}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
                
                <div className="space-y-8">
                  <div className="bg-white p-8 rounded-[32px] border border-[#EBE3D5] shadow-inner">
                    <h4 className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest mb-4">Destination Snapshot</h4>
                    <p className="text-sm font-bold text-[#5C4D3C]">{order.deliveryAddress.fullName}</p>
                    <p className="text-[10px] text-[#7C6A58] mt-2 italic leading-relaxed">
                      {order.deliveryAddress.houseFlat}, {order.deliveryAddress.streetArea}<br/>
                      {order.deliveryAddress.city}, {order.deliveryAddress.state} - {order.deliveryAddress.pinCode}
                    </p>
                  </div>
                  <div className="flex justify-between font-bold text-3xl text-[#5C4D3C] font-serif border-t border-[#FDFBF7] pt-6">
                    <span>Order Total</span>
                    <span>₹{order.total.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-4 pt-8 border-t border-[#EBE3D5]">
                {needsPayment ? (
                  <button 
                    onClick={() => setActivePaymentOrder(order)} 
                    className={`w-full py-6 rounded-3xl font-bold shadow-2xl transition-all flex items-center justify-center gap-4 uppercase text-xs tracking-[3px] ${isRejected ? 'bg-rose-600 text-white' : 'bg-[#5C4D3C] text-white hover:bg-black'}`}
                  >
                    <span>💳</span> {isRejected ? 'Correct Proof & Re-Pay' : 'Pay Now to Confirm'} (₹{order.total.toLocaleString()})
                  </button>
                ) : isConfirmed ? (
                  <div className="w-full flex gap-4">
                     <button onClick={() => navigate(`/order-confirmation/${order.id}`)} className="flex-1 py-4 border border-[#EBE3D5] rounded-2xl text-[10px] font-bold uppercase tracking-widest text-[#5C4D3C] hover:bg-[#FDFBF7]">Stitching Certificate</button>
                     <button onClick={() => setSelectedDoc({ type: 'RECEIPT', order })} className="flex-1 py-4 border border-[#EBE3D5] rounded-2xl text-[10px] font-bold uppercase tracking-widest text-[#5C4D3C] hover:bg-[#FDFBF7]">Payment Receipt</button>
                  </div>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>

      {/* Review Modal */}
      {reviewModal && (
        <div className="fixed inset-0 z-[600] bg-black/60 backdrop-blur-md flex items-center justify-center p-6">
          <div className="bg-white w-full max-w-md rounded-[50px] shadow-2xl overflow-hidden animate-in zoom-in">
             <div className="bg-[#5C4D3C] p-8 text-white flex justify-between items-center">
                <h2 className="text-2xl font-serif font-bold italic">Artisanal Feedback</h2>
                <button onClick={() => setReviewModal(null)} className="text-4xl opacity-60">&times;</button>
             </div>
             <form onSubmit={handleSubmitReview} className="p-10 space-y-8">
                <div className="space-y-4 text-center">
                   <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">Rate the stitching</p>
                   <div className="flex justify-center gap-4">
                      {[1, 2, 3, 4, 5].map(star => (
                        <button 
                          key={star} 
                          type="button"
                          onClick={() => setRating(star)}
                          className={`text-3xl transition-all ${star <= rating ? 'text-amber-400 scale-110' : 'text-gray-200'}`}
                        >
                          ★
                        </button>
                      ))}
                   </div>
                </div>
                <div className="space-y-2">
                   <label className="text-[10px] font-bold uppercase text-[#A68F7A] tracking-widest block px-2">Your Review</label>
                   <textarea 
                    required
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="Describe the thread quality, colors, and overall hand-stitched feel..."
                    className="w-full px-6 py-4 bg-[#FDFBF7] border border-[#EBE3D5] rounded-3xl text-sm outline-none leading-relaxed h-32 focus:bg-white focus:border-[#A68F7A] transition-all"
                   />
                </div>
                <button type="submit" className="w-full py-5 bg-[#5C4D3C] text-white rounded-3xl font-bold shadow-xl hover:bg-black uppercase tracking-widest text-[10px]">Seal Review</button>
                <p className="text-[9px] text-center text-[#A68F7A] uppercase italic">Note: Reviews are final and cannot be edited after submission.</p>
             </form>
          </div>
        </div>
      )}

      {activePaymentOrder && (
        <div className="fixed inset-0 z-[500] bg-[#5C4D3C]/95 backdrop-blur-xl flex items-center justify-center p-6">
           <div className="bg-white w-full max-w-lg rounded-[60px] overflow-hidden shadow-2xl animate-in zoom-in duration-300">
              <div className="bg-[#FDFBF7] p-10 border-b border-[#EBE3D5] flex justify-between items-center">
                 <h4 className="font-serif font-bold text-2xl text-[#5C4D3C]">Confirm Selection</h4>
                 <button onClick={() => setActivePaymentOrder(null)} className="text-4xl text-[#A68F7A] hover:text-[#5C4D3C]">&times;</button>
              </div>
              <div className="p-12">
                 <PaymentGateway 
                    order={activePaymentOrder} 
                    settings={adminSettings}
                    onConfirm={(m, s, t, ai) => {
                       onPay(activePaymentOrder.id, m, s, t, ai);
                       setActivePaymentOrder(null);
                    }}
                    onCancel={() => setActivePaymentOrder(null)}
                 />
              </div>
           </div>
        </div>
      )}

      {selectedDoc && <DocumentViewer mode={selectedDoc.type} order={selectedDoc.order} settings={adminSettings} onClose={() => setSelectedDoc(null)} />}
    </div>
  );
};

export default CustomerOrders;
