
export enum UserRole {
  CUSTOMER = 'CUSTOMER',
  ADMIN = 'ADMIN'
}

export enum OrderStatus {
  DRAFT = 'DRAFT',
  CUSTOMER_PAYMENT_PENDING = 'CUSTOMER_PAYMENT_PENDING',
  PAYMENT_SUCCESS = 'PAYMENT_SUCCESS',
  COD_CONFIRMED = 'COD_CONFIRMED',
  CONFIRMED = 'CONFIRMED',
  INVOICE_FINAL = 'INVOICE_FINAL',
  LABEL_FINAL = 'LABEL_FINAL',
  SHIPPED = 'SHIPPED',
  DELIVERED = 'DELIVERED'
}

export enum PaymentMethod {
  ONLINE = 'Online Prepaid',
  COD = 'Cash on Delivery',
  QR_CODE = 'QR Code Scan & Pay',
  RAZORPAY = 'Razorpay Secure'
}

export enum PaymentState {
  NOT_SELECTED = 'NOT_SELECTED',
  IN_PROGRESS = 'IN_PROGRESS',
  PENDING_VERIFICATION = 'PENDING_VERIFICATION',
  COD_SELECTED = 'COD_SELECTED',
  VERIFIED = 'VERIFIED',
  REJECTED = 'REJECTED',
  FAILED = 'FAILED'
}

export interface Address {
  id: string;
  fullName: string;
  phone: string;
  houseFlat: string;
  streetArea: string;
  landmark?: string;
  city: string;
  state: string;
  pinCode: string;
  label: 'Home' | 'Work' | 'Other';
  isDefault?: boolean;
  lat?: number;
  lng?: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: UserRole;
  addresses: Address[];
}

export interface Review {
  id: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  createdAt: string;
  orderId?: string; // Linked to specific purchase
}

export interface Product {
  id: string;
  name: string;
  basePrice: number;
  artisanCharges: number;
  packagingCharges: number;
  shippingFee: number;
  customWorkCharges: number;
  discountPercent: number;
  flatDiscount: number;
  price: number; 
  unit: string;
  description: string;
  categoryId: string;
  category: string;
  images: string[];
  careInstructions: string;
  stock: number;
  isFeatured: boolean;
  isVisible: boolean;
  reviews?: Review[];
}

export interface Category {
  id: string;
  name: string;
  description: string;
  image: string;
  isEnabled: boolean;
}

export interface Coupon {
  id: string;
  code: string;
  type: 'PERCENT' | 'FLAT';
  value: number;
  minOrderAmount: number;
  isEnabled: boolean;
  description: string;
}

export interface CartItem {
  productId: string;
  quantity: number;
}

export interface ShippingDetails {
  courierName: string;
  awbNumber: string;
  trackingUrl?: string;
  shipmentDate?: string;
}

export interface DocData {
  title: string;
  note: string;
  lockedAt: string | null;
  nameOverride?: string;
  addressOverride?: string;
  phoneOverride?: string;
}

export interface Package {
  id: string;
  packageNumber: number;
  trackingId: string;
  courierName: string;
  labelData: DocData;
}

export interface OrderSnapshot {
  version: number;
  timestamp: string;
  changeLog: string;
  orderData: string; 
}

export interface DispatchSlot {
  date: string;
  window: 'Morning' | 'Afternoon' | 'Evening';
}

export type ConfirmationSource = 'SYSTEM' | 'AI_VERIFIED' | 'MANUAL_ADMIN';

export interface VerifiedPaymentDetails {
  transactionId: string;
  amount: number;
  date: string;
  payee: string;
  confidence: number;
  aiExtracted: boolean;
  adminLocked: boolean;
}

export interface Order {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  userPhone: string;
  items: (CartItem & { name: string; price: number })[];
  subtotal: number;
  artisanCharges: number;
  packagingCharges: number;
  shippingCharge: number;
  customCharges: number;
  discount: number;
  total: number;
  status: OrderStatus;
  paymentMethod?: PaymentMethod;
  summaryConfirmed: boolean;
  transactionId?: string;
  paymentScreenshot?: string;
  paymentVerified: boolean; 
  paymentState?: PaymentState;
  verifiedPaymentDetails?: VerifiedPaymentDetails;
  confirmationSource?: ConfirmationSource;
  verificationReason?: string;
  rejectionReason?: string;
  shipping?: ShippingDetails;
  deliveryAddress: Address;
  createdAt: string;
  invoiceData?: DocData;
  receiptData?: DocData;
  labelData?: DocData;
  history: OrderSnapshot[];
  holdNote?: string;
  dispatchSlot?: DispatchSlot;
  packages: Package[];
  riskAlerts: string[];
  lastRiskCheckedAt?: string;
  reviewedProductIds?: string[]; // Track which items in this order are reviewed
  checklist: {
    pricingFinalized: boolean;
    paymentVerified: boolean;
    invoiceLocked: boolean;
    labelsGenerated: boolean;
    trackingAdded: boolean;
    readyForDispatch: boolean;
  };
}

export type EmailType = 'WELCOME_ACCOUNT' | 'SECURITY_LOGIN' | 'ORDER_CONFIRMED' | 'ORDER_SHIPPED' | 'PAYMENT_RECEIPT';

export interface EmailTemplate {
  type: EmailType;
  subject: string;
  body: string;
  isEnabled: boolean;
}

export interface DocumentTheme {
  primaryColor: string;
  secondaryColor: string;
  layout: 'minimal' | 'boxed' | 'premium' | 'compact';
  headerAlignment: 'left' | 'center' | 'right';
  showWatermark: boolean;
  watermarkOpacity: number;
  fontFamily: 'serif' | 'sans' | 'mono';
  dividerStyle: 'solid' | 'dashed' | 'dotted';
  footerNote: string;
  invoiceTitle: string;
  receiptTitle: string;
}

export interface BankDetails {
  accountHolder: string;
  bankName: string;
  accountNumber: string;
  ifscCode: string;
}

export interface RazorpayConfig {
  keyId: string;
  isEnabled: boolean;
}

export interface AdminSettings {
  qrCodeImage: string;
  qrInstructions: string;
  qrEnabled: boolean;
  businessName: string;
  businessAddress: string;
  businessContact: string;
  businessEmail: string;
  businessLogo?: string;
  watermarkImage?: string;
  signatureImage?: string;
  supportPhone: string;
  supportWhatsApp: string;
  supportEmail: string;
  supportPhoneEnabled: boolean;
  supportWhatsAppEnabled: boolean;
  supportEmailEnabled: boolean;
  emailTemplates: Record<EmailType, EmailTemplate>;
  documentTheme: DocumentTheme;
  invoiceTheme: DocumentTheme;
  receiptTheme: DocumentTheme;
  labelTheme: DocumentTheme;
  bankDetails: BankDetails;
  razorpayConfig: RazorpayConfig;
  categories: Category[];
  coupons: Coupon[];
}
