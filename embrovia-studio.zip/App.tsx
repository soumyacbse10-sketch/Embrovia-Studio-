
import React, { useState, useEffect, useCallback } from 'react';
import { HashRouter, Routes, Route, Navigate, Link, useLocation, useNavigate } from 'react-router-dom';
import { User, UserRole, Product, Order, CartItem, OrderStatus, PaymentMethod, AdminSettings, Address, EmailType, Category, Coupon, DocumentTheme, OrderSnapshot, PaymentState, Review } from './types.ts';
import { INITIAL_PRODUCTS, INITIAL_USERS, INITIAL_ORDERS, INITIAL_CATEGORIES, INITIAL_COUPONS } from './data.ts';
import { prepareManualEmail, dispatchToEmailApp } from './services/EmailService.ts';
import { runOrderAIVerification } from './services/VerificationService.ts';

// --- Views ---
import CustomerHome from './views/Customer/Home.tsx';
import ProductList from './views/Customer/ProductList.tsx';
import ProductDetail from './views/Customer/ProductDetail.tsx';
import CartView from './views/Customer/Cart.tsx';
import CustomerOrders from './views/Customer/Orders.tsx';
import ProfileView from './views/Customer/Profile.tsx';
import LoginView from './views/Auth/Login.tsx';
import OrderConfirmation from './views/Customer/OrderConfirmation.tsx';
import AIAssistant from './views/Customer/AIAssistant.tsx';

// --- Admin Views ---
import AdminDashboard from './views/Admin/Dashboard.tsx';
import ProductManager from './views/Admin/ProductManager.tsx';
import OrderManager from './views/Admin/OrderManager.tsx';
import InvoiceManager from './views/Admin/InvoiceManager.tsx';
import ReceiptManager from './views/Admin/ReceiptManager.tsx';
import LabelManager from './views/Admin/LabelManager.tsx';
import PaymentsMenu from './views/Admin/PaymentsMenu.tsx';
import DocumentsMenu from './views/Admin/DocumentsMenu.tsx';
import EmailTemplateManager from './views/Admin/EmailTemplateManager.tsx';
import CustomerCareMenu from './views/Admin/CustomerCareMenu.tsx';
import AppSettingsMenu from './views/Admin/AppSettingsMenu.tsx';
import CategoryManager from './views/Admin/CategoryManager.tsx';
import CouponManager from './views/Admin/CouponManager.tsx';
import ReportManager from './views/Admin/ReportManager.tsx';

// --- Global UI Components ---

const Navbar: React.FC<{ user: User, cartCount: number, onLogout: () => void }> = ({ user, cartCount, onLogout }) => {
  const isAdmin = user.role === UserRole.ADMIN;
  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-[#EBE3D5] shadow-sm">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="text-2xl font-serif font-bold text-[#5C4D3C] tracking-tight">Embrovia <span className="text-[#A68F7A]">Studio</span></Link>
        <div className="flex items-center space-x-6 text-sm font-medium text-[#7C6A58]">
          {!isAdmin && (
            <div className="flex items-center gap-6">
              <Link to="/shop" className="hover:text-[#5C4D3C] transition-colors uppercase text-[10px] font-bold tracking-widest">Shop</Link>
              <Link to="/profile?tab=orders" className="hover:text-[#5C4D3C] transition-colors uppercase text-[10px] font-bold tracking-widest">Orders</Link>
              <Link to="/profile" className="hover:text-[#5C4D3C] transition-colors uppercase text-[10px] font-bold tracking-widest">My Profile</Link>
              <Link to="/cart" className="relative group">
                <span className="text-xl">🛍️</span>
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-[#A68F7A] text-white text-[10px] w-5 h-5 flex items-center justify-center rounded-full border-2 border-white font-bold group-hover:scale-110 transition-transform">
                    {cartCount}
                  </span>
                )}
              </Link>
            </div>
          )}
          <div className="flex items-center gap-4 pl-4 border-l border-[#EBE3D5]">
            <div className="text-right hidden sm:block">
              <p className="text-[10px] font-bold text-[#A68F7A] uppercase">{user.role}</p>
              <Link to="/profile" className="text-xs font-bold text-[#5C4D3C] hover:underline">{user.name}</Link>
            </div>
            <button onClick={onLogout} className="bg-[#EBE3D5] p-2 rounded-full hover:bg-[#D4C5B9] text-xs transition-colors">🚪</button>
          </div>
        </div>
      </div>
    </nav>
  );
};

const AdminSidebar: React.FC = () => {
  const location = useLocation();
  const sections = [
    { title: 'Overview', items: [
      { name: 'Dashboard', path: '/admin', icon: '📊' },
      { name: 'Reports', path: '/admin/reports', icon: '📈' }
    ] },
    { title: 'Studio Management', items: [
      { name: 'Order Desk', path: '/admin/orders', icon: '📋' },
      { name: 'Inventory', path: '/admin/products', icon: '🧵' },
      { name: 'Categories', path: '/admin/categories', icon: '🏷️' },
      { name: 'Promo Codes', path: '/admin/coupons', icon: '🎟️' },
    ] },
    { title: 'Documents', items: [
      { name: 'Invoices', path: '/admin/invoices', icon: '📄' },
      { name: 'Receipts', path: '/admin/receipts', icon: '🧾' },
      { name: 'Delivery Labels', path: '/admin/labels', icon: '🏷️' },
    ] },
    { title: 'Configuration', items: [
      { name: 'Payments', path: '/admin/payments', icon: '💳' },
      { name: 'Themes', path: '/admin/documents', icon: '🎨' },
      { name: 'Emails', path: '/admin/emails', icon: '✉️' },
      { name: 'Support', path: '/admin/care', icon: '🎧' },
      { name: 'Identity', path: '/admin/settings', icon: '⚙️' },
    ] }
  ];

  return (
    <div className="w-64 bg-white border-r border-[#EBE3D5] flex flex-col sticky top-16 h-[calc(100vh-64px)] overflow-y-auto">
      <div className="p-6 space-y-8">
        {sections.map(sec => (
          <div key={sec.title}>
            <h2 className="text-[9px] font-bold text-[#A68F7A] uppercase tracking-[3px] mb-4">{sec.title}</h2>
            <nav className="space-y-1">
              {sec.items.map(m => (
                <Link 
                  key={m.path} 
                  to={m.path}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all ${location.pathname === m.path ? 'bg-[#5C4D3C] text-white shadow-lg' : 'text-[#7C6A58] hover:bg-[#FDFBF7] hover:text-[#5C4D3C]'}`}
                >
                  <span>{m.icon}</span>
                  {m.name}
                </Link>
              ))}
            </nav>
          </div>
        ))}
      </div>
    </div>
  );
};

const App: React.FC = () => {
  // CORE INITIALIZATION - LOAD FROM PERSISTENCE OR EMPTY PRODUCTION DEFAULTS
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('embrovia_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('embrovia_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });
  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('embrovia_orders');
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('embrovia_cart');
    return saved ? JSON.parse(saved) : [];
  });
  const [adminSettings, setAdminSettings] = useState<AdminSettings>(() => {
    const saved = localStorage.getItem('embrovia_admin_settings');
    const baseTheme: DocumentTheme = {
      primaryColor: '#5C4D3C',
      secondaryColor: '#A68F7A',
      layout: 'premium',
      headerAlignment: 'left',
      showWatermark: true,
      watermarkOpacity: 0.05,
      fontFamily: 'serif',
      dividerStyle: 'solid',
      footerNote: 'Thank you for supporting handcrafted Indian art.',
      invoiceTitle: 'Tax Invoice',
      receiptTitle: 'Payment Receipt',
    };
    const defaults: AdminSettings = {
      qrCodeImage: 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=upi://pay?pa=embrovia@upi&pn=EmbroviaStudio',
      qrInstructions: 'Scan the QR code below and complete payment.',
      qrEnabled: true,
      businessName: 'Embrovia Studio',
      businessAddress: 'Sector 42, Art Guild Square, Jaipur, Rajasthan - 302001',
      businessContact: '+91 98765 43210',
      businessEmail: 'hello@embrovia.studio',
      businessLogo: 'https://picsum.photos/seed/embrovia-logo/200/200',
      watermarkImage: 'https://picsum.photos/seed/embrovia-logo/400/400',
      signatureImage: 'https://upload.wikimedia.org/wikipedia/commons/d/d4/Signature_of_A_K_Antony.png',
      supportPhone: '+91 98765 43210',
      supportWhatsApp: '+91 98765 43210',
      supportEmail: 'support@embrovia.studio',
      supportPhoneEnabled: true,
      supportWhatsAppEnabled: true,
      supportEmailEnabled: true,
      documentTheme: { ...baseTheme },
      invoiceTheme: { ...baseTheme, layout: 'premium' },
      receiptTheme: { ...baseTheme, layout: 'boxed', primaryColor: '#4A5568' },
      labelTheme: { ...baseTheme, layout: 'minimal', fontFamily: 'sans', primaryColor: '#000000' },
      emailTemplates: {
        'WELCOME_ACCOUNT': { type: 'WELCOME_ACCOUNT', subject: 'Welcome to {{business_name}}!', body: 'Hello {{customer_name}}, welcome!', isEnabled: true },
        'SECURITY_LOGIN': { type: 'SECURITY_LOGIN', subject: 'Security Login Alert', body: 'A new login detected.', isEnabled: true },
        'ORDER_CONFIRMED': { type: 'ORDER_CONFIRMED', subject: 'Order {{order_id}} Confirmed', body: 'Your order for {{product_name}} is confirmed.', isEnabled: true },
        'ORDER_SHIPPED': { type: 'ORDER_SHIPPED', subject: 'Your Order is on its Way!', body: 'Order {{order_id}} has been shipped.', isEnabled: true },
        'PAYMENT_RECEIPT': { type: 'PAYMENT_RECEIPT', subject: 'Payment Receipt', body: 'Payment for {{order_id}} verified.', isEnabled: true },
      },
      bankDetails: { accountHolder: 'Embrovia Studio', bankName: 'HDFC Bank', accountNumber: '50200012345678', ifscCode: 'HDFC0001234' },
      razorpayConfig: { keyId: 'rzp_test_mockKey123', isEnabled: true },
      categories: INITIAL_CATEGORIES,
      coupons: INITIAL_COUPONS
    };
    return saved ? { ...defaults, ...JSON.parse(saved) } : defaults;
  });
  const [isAIChatOpen, setIsAIChatOpen] = useState(false);

  useEffect(() => localStorage.setItem('embrovia_user', JSON.stringify(currentUser)), [currentUser]);
  useEffect(() => localStorage.setItem('embrovia_products', JSON.stringify(products)), [products]);
  useEffect(() => localStorage.setItem('embrovia_orders', JSON.stringify(orders)), [orders]);
  useEffect(() => localStorage.setItem('embrovia_cart', JSON.stringify(cart)), [cart]);
  useEffect(() => localStorage.setItem('embrovia_admin_settings', JSON.stringify(adminSettings)), [adminSettings]);

  const handleLogin = (user: User) => setCurrentUser(user);
  const handleLogout = () => { setCurrentUser(null); setCart([]); };
  
  const handleAddToCart = (productId: string, quantity: number) => {
    setCart(prev => {
      const existing = prev.find(item => item.productId === productId);
      if (existing) return prev.map(item => item.productId === productId ? { ...item, quantity: item.quantity + quantity } : item);
      return [...prev, { productId, quantity }];
    });
  };

  const handleUpdateQty = (productId: string, quantity: number) => {
    if (quantity <= 0) return handleRemoveFromCart(productId);
    setCart(prev => prev.map(item => item.productId === productId ? { ...item, quantity } : item));
  };

  const handleRemoveFromCart = (productId: string) => setCart(prev => prev.filter(item => item.productId !== productId));

  const handleCheckout = (address: Address, discount: number) => {
    if (!currentUser) return;
    const cartItems = cart.map(ci => {
      const p = products.find(prod => prod.id === ci.productId);
      return p ? { ...ci, name: p.name, price: p.price } : null;
    }).filter(Boolean) as (CartItem & { name: string; price: number })[];
    
    if (cartItems.length === 0) return;
    const subtotal = cartItems.reduce((acc, curr) => acc + (curr.price * curr.quantity), 0);
    const orderId = `ORD-${Date.now().toString().slice(-6)}`;
    
    const newOrder: Order = {
      id: orderId,
      userId: currentUser.id,
      userName: currentUser.name,
      userEmail: currentUser.email,
      userPhone: currentUser.phone,
      items: cartItems,
      subtotal,
      artisanCharges: 0,
      packagingCharges: 0,
      shippingCharge: 50,
      customCharges: 0,
      discount: discount,
      total: (subtotal + 50) - discount,
      status: OrderStatus.CUSTOMER_PAYMENT_PENDING,
      paymentVerified: false, 
      summaryConfirmed: true,
      deliveryAddress: JSON.parse(JSON.stringify(address)), 
      createdAt: new Date().toISOString(),
      history: [],
      packages: [],
      riskAlerts: [],
      checklist: { pricingFinalized: true, paymentVerified: false, invoiceLocked: false, labelsGenerated: false, trackingAdded: false, readyForDispatch: false }
    };
    
    setOrders(prev => [newOrder, ...prev]);
    setCart([]);
    return newOrder;
  };

  const updateOrder = useCallback((orderId: string, updates: Partial<Order>, log: string = "System Update") => {
    setOrders(prev => prev.map(o => {
      if (o.id !== orderId) return o;
      const snapshot: OrderSnapshot = { version: (o.history?.length || 0) + 1, timestamp: new Date().toISOString(), changeLog: log, orderData: JSON.stringify(o) };
      return { ...o, ...updates, history: [...(o.history || []), snapshot] };
    }));
  }, []);

  const handlePayOrder = (orderId: string, method: PaymentMethod, screenshot?: string, transactionId?: string, aiDetails?: any) => {
    const o = orders.find(ord => ord.id === orderId);
    if (!o) return;
    const isManual = method === PaymentMethod.QR_CODE || method === PaymentMethod.ONLINE;
    const milestoneStatus = isManual ? OrderStatus.CUSTOMER_PAYMENT_PENDING : OrderStatus.CONFIRMED;
    const finalPaymentState = isManual ? PaymentState.PENDING_VERIFICATION : PaymentState.VERIFIED;
    const isVerified = !isManual;
    
    updateOrder(orderId, {
      paymentMethod: method, paymentScreenshot: screenshot, transactionId: transactionId,
      status: milestoneStatus, paymentState: finalPaymentState, paymentVerified: isVerified, 
      verifiedPaymentDetails: aiDetails, checklist: { ...o.checklist, paymentVerified: isVerified },
      rejectionReason: undefined 
    }, `Payment action registered via ${method}.`);
    
    if (isVerified) runOrderAIVerification(o).then(res => updateOrder(orderId, { confirmationSource: 'AI_VERIFIED', verificationReason: res.reason }, "AI Audit Result Attached."));
  };

  const handleUpdateStatus = (id: string, status: OrderStatus) => updateOrder(id, { status }, `Status changed to ${status}`);
  const handleVerifyPayment = (id: string, verified: boolean) => verified && updateOrder(id, { paymentVerified: true, status: OrderStatus.CONFIRMED, paymentState: PaymentState.VERIFIED, checklist: { ...orders.find(o=>o.id===id)!.checklist, paymentVerified: true } }, "Admin manually verified payment.");
  
  const handleRejectPayment = (id: string, reason: string) => {
    updateOrder(id, { 
      paymentState: PaymentState.REJECTED, 
      paymentVerified: false,
      rejectionReason: reason,
      paymentScreenshot: undefined, 
      transactionId: undefined,
      checklist: { ...orders.find(o=>o.id===id)!.checklist, paymentVerified: false }
    }, `Payment proof rejected: ${reason}`);
  };

  const handleUpdateUserAddresses = (addresses: Address[]) => currentUser && setCurrentUser({ ...currentUser, addresses });
  
  const handleUpdateUserProfile = (name: string, email: string, phone: string) => {
    if (currentUser) {
      setCurrentUser({ ...currentUser, name, email, phone });
    }
  };

  const updateAdminSettings = (updates: Partial<AdminSettings>) => setAdminSettings(prev => ({ ...prev, ...updates }));

  const handleAddReview = (productId: string, orderId: string, rating: number, comment: string) => {
    if (!currentUser) return;
    const newReview: Review = {
      id: `rev-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      rating,
      comment,
      createdAt: new Date().toISOString(),
      orderId
    };
    
    setProducts(prev => prev.map(p => {
      if (p.id === productId) {
        return { ...p, reviews: [...(p.reviews || []), newReview] };
      }
      return p;
    }));

    setOrders(prev => prev.map(o => {
      if (o.id === orderId) {
        const reviewedIds = [...(o.reviewedProductIds || []), productId];
        return { ...o, reviewedProductIds: reviewedIds };
      }
      return o;
    }));
  };

  const isAdmin = currentUser?.role === UserRole.ADMIN;
  const unpaidFinalizedOrder = !isAdmin && currentUser ? orders.find(o => o.userId === currentUser.id && o.status === OrderStatus.CUSTOMER_PAYMENT_PENDING && !o.paymentVerified && o.paymentState !== PaymentState.PENDING_VERIFICATION) : null;

  return (
    <HashRouter>
      <div className="min-h-screen flex flex-col bg-[#FDFBF7]">
        {currentUser && !unpaidFinalizedOrder && <Navbar user={currentUser} cartCount={cart.length} onLogout={handleLogout} />}
        
        {unpaidFinalizedOrder && (
          <div className="fixed inset-0 z-[1000] bg-[#5C4D3C] flex items-center justify-center p-6 backdrop-blur-xl">
             <div className="bg-white w-full max-w-4xl rounded-[60px] shadow-2xl overflow-hidden animate-in zoom-in duration-500 flex flex-col md:flex-row">
                <div className="md:w-1/3 bg-[#FDFBF7] p-12 border-r border-[#EBE3D5] flex flex-col justify-between">
                   <div className="space-y-6">
                      <h2 className="text-3xl font-serif font-bold text-[#5C4D3C]">Payment Required</h2>
                      <p className="text-sm text-[#7C6A58] leading-relaxed italic">"Finalize your payment to secure this handcrafted piece."</p>
                      {unpaidFinalizedOrder.paymentState === PaymentState.REJECTED && (
                        <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl">
                          <p className="text-[10px] font-bold text-rose-700 uppercase tracking-widest mb-1">Previous Proof Declined</p>
                          <p className="text-xs text-rose-600 font-medium italic">"{unpaidFinalizedOrder.rejectionReason}"</p>
                        </div>
                      )}
                   </div>
                   <div className="pt-12 border-t border-[#EBE3D5]">
                      <p className="text-[10px] font-bold text-[#A68F7A] uppercase tracking-widest">ORDER REF</p>
                      <p className="text-lg font-bold text-[#5C4D3C] mt-1">#{unpaidFinalizedOrder.id}</p>
                   </div>
                </div>
                <div className="md:w-2/3 p-12 bg-white">
                   <CustomerOrders 
                    orders={[unpaidFinalizedOrder]} 
                    adminSettings={adminSettings} 
                    onPay={handlePayOrder} 
                    onAddReview={() => {}} 
                    products={products}
                    forceActive={true} 
                   />
                </div>
             </div>
          </div>
        )}

        <main className={`flex-grow ${isAdmin ? 'flex' : 'container mx-auto px-4 py-6'}`}>
          {isAdmin && <AdminSidebar />}
          <div className={`${isAdmin ? 'flex-grow p-8 overflow-y-auto max-h-[calc(100vh-64px)]' : ''}`}>
            <Routes>
              <Route path="/login" element={!currentUser ? <LoginView onLogin={handleLogin} /> : <Navigate to="/" />} />
              <Route path="/" element={isAdmin ? <Navigate to="/admin" /> : (currentUser ? <CustomerHome products={products.filter(p => p.isVisible)} adminSettings={adminSettings} /> : <Navigate to="/login" />)} />
              <Route path="/shop" element={currentUser ? <ProductList products={products.filter(p => p.isVisible)} /> : <Navigate to="/login" />} />
              <Route path="/product/:id" element={currentUser ? <ProductDetail products={products} onAddToCart={handleAddToCart} /> : <Navigate to="/login" />} />
              <Route path="/cart" element={currentUser ? <CartView cart={cart} products={products} adminSettings={adminSettings} userAddresses={currentUser.addresses} onUpdateQty={handleUpdateQty} onRemove={handleRemoveFromCart} onCheckout={handleCheckout} onAddAddress={(a) => handleUpdateUserAddresses([...currentUser.addresses, a])} /> : <Navigate to="/login" />} />
              
              <Route path="/profile" element={
                currentUser ? (
                  <ProfileView 
                    user={currentUser} 
                    adminSettings={adminSettings} 
                    orders={orders.filter(o => o.userId === currentUser.id)}
                    products={products}
                    onUpdateAddresses={handleUpdateUserAddresses} 
                    onUpdateProfile={handleUpdateUserProfile}
                    onPayOrder={handlePayOrder}
                    onAddReview={handleAddReview}
                  />
                ) : <Navigate to="/login" />
              } />
              
              <Route path="/admin" element={isAdmin ? <AdminDashboard orders={orders} products={products} /> : <Navigate to="/" />} />
              <Route path="/admin/reports" element={isAdmin ? <ReportManager orders={orders} /> : <Navigate to="/" />} />
              <Route path="/admin/orders" element={isAdmin ? <OrderManager orders={orders} adminSettings={adminSettings} onUpdateStatus={handleUpdateStatus} onVerifyPayment={handleVerifyPayment} onRejectPayment={handleRejectPayment} onTriggerEmail={()=>{}} onUpdateSummary={updateOrder} /> : <Navigate to="/" />} />
              <Route path="/admin/invoices" element={isAdmin ? <InvoiceManager orders={orders} adminSettings={adminSettings} onUpdateOrder={updateOrder} /> : <Navigate to="/" />} />
              <Route path="/admin/receipts" element={isAdmin ? <ReceiptManager orders={orders} adminSettings={adminSettings} onUpdateOrder={updateOrder} /> : <Navigate to="/" />} />
              <Route path="/admin/labels" element={isAdmin ? <LabelManager orders={orders} adminSettings={adminSettings} onUpdateOrder={updateOrder} /> : <Navigate to="/" />} />
              <Route path="/admin/products" element={isAdmin ? <ProductManager products={products} adminSettings={adminSettings} onUpsert={(p)=>setProducts(prev=>prev.find(x=>x.id===p.id)?[...prev.map(x=>x.id===p.id?p:x)]:[p,...prev])} onDelete={(id)=>setProducts(prev=>prev.filter(x=>x.id!==id))} /> : <Navigate to="/" />} />
              <Route path="/admin/payments" element={isAdmin ? <PaymentsMenu settings={adminSettings} onUpdate={updateAdminSettings} /> : <Navigate to="/" />} />
              <Route path="/admin/documents" element={isAdmin ? <DocumentsMenu settings={adminSettings} onUpdate={updateAdminSettings} /> : <Navigate to="/" />} />
              <Route path="/admin/emails" element={isAdmin ? <EmailTemplateManager settings={adminSettings} onUpdate={updateAdminSettings} /> : <Navigate to="/" />} />
              <Route path="/admin/care" element={isAdmin ? <CustomerCareMenu settings={adminSettings} onUpdate={updateAdminSettings} /> : <Navigate to="/" />} />
              <Route path="/admin/settings" element={isAdmin ? <AppSettingsMenu settings={adminSettings} onUpdate={updateAdminSettings} /> : <Navigate to="/" />} />
              <Route path="/admin/categories" element={isAdmin ? <CategoryManager settings={adminSettings} onUpdate={updateAdminSettings} /> : <Navigate to="/" />} />
              <Route path="/admin/coupons" element={isAdmin ? <CouponManager settings={adminSettings} onUpdate={updateAdminSettings} /> : <Navigate to="/" />} />
            </Routes>
          </div>
        </main>
        
        {currentUser && !isAdmin && (
          <>
            <button onClick={() => setIsAIChatOpen(true)} className="fixed bottom-8 right-8 bg-[#5C4D3C] text-white w-14 h-14 rounded-full shadow-2xl flex items-center justify-center text-2xl hover:scale-110 active:scale-95 transition-all z-[90]">🧵</button>
            <AIAssistant products={products} isOpen={isAIChatOpen} onClose={() => setIsAIChatOpen(false)} adminSettings={adminSettings} />
          </>
        )}
      </div>
    </HashRouter>
  );
};

export default App;
