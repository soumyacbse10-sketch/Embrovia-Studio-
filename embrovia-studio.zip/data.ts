
import { Product, User, UserRole, Order, Category, Coupon } from './types.ts';

// PRODUCTION INITIAL STATE: COMPLETELY EMPTY
export const INITIAL_CATEGORIES: Category[] = [];
export const INITIAL_COUPONS: Coupon[] = [];
export const INITIAL_PRODUCTS: Product[] = [];
export const INITIAL_ORDERS: Order[] = [];

// CORE PRODUCTION ADMIN ACCOUNTS
export const INITIAL_USERS: User[] = [
  {
    id: 'admin-soumya',
    name: 'Soumya',
    email: 'soumya@embroviastudo.com',
    phone: '',
    role: UserRole.ADMIN,
    addresses: []
  },
  {
    id: 'admin-sulagna',
    name: 'Sulagna',
    email: 'sulagna@embroviastudo.com',
    phone: '',
    role: UserRole.ADMIN,
    addresses: []
  }
];
